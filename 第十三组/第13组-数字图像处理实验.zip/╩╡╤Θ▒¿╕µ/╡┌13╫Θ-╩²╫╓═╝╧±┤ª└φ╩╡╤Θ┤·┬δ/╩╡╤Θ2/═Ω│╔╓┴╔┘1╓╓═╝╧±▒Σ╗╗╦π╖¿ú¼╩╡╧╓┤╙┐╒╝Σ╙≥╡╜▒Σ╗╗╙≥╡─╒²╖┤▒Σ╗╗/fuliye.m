A = imread('D:/picture.jpg');
A = rgb2gray(A);
A = im2double(A);
[m,n] = size(A);
%����Ҷ�任
for u=0:m-1
    for v=0:n-1
        sum = 0;
        for x=0:m-1
            e1 = exp(-1i*2*pi*u*x/m);
            for y=0:n-1
                e2 = exp(-1i*2*pi*v*y/n);
                sum = sum + A(x+1,y+1)*e1*e2;
            end
        end
        F(u+1,v+1) = sum;
    end
end
figure;
subplot(1,2,1);imshow(log(F),[]);title('����Ҷ�任')
%����Ҷ��任
for x=0:m-1
    for y=0:n-1
        sum = 0;
        for u=0:m-1
            e1 = exp(1i*2*pi*u*x/m);
            for v=0:n-1
                e2 = exp(1i*2*pi*v*y/n);
                sum = sum + F(u+1,v+1)*e1*e2;
            end
        end
        f(x+1,y+1) = real(sum/(m*n));
    end
end
subplot(1,2,2);imshow(f,[]);title('����Ҷ��任')
