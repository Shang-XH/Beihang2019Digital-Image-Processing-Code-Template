/*
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
先对图像进行高斯滤波，再边缘检测
*/
#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;

typedef struct
{
    unsigned char Red;
    unsigned char Green;
    unsigned char Blue;
} PixelData;

class ImageSharpen
{
private:
    double **GaussFilterWindow; //存储高斯滤波器
    int Laplace[3][3] = {
        {-1, -1, -1},
        {-1, 8, -1},
        {-1, -1, -1}};
    int Robert1[3][3] = {
        {0, 0, 0},
        {0, 1, 0},
        {0, 0, -1}};
    int Robert2[3][3] = {
        {0, 0, 0},
        {0, 0, 1},
        {0, -1, 0}};
    int Sobel1[3][3]={
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };
    int Sobel2[3][3]={
        {-1,-2,-1},
        {0,0,0},
        {1,2,1}
    };
    int ksize;                  //GaussFilter kernelsize
    PixelData **data;           //存储读取的图片数据
    PixelData **data_out_gauss; //存储处理过后的图片数据
    PixelData **data_out_laplace;
    PixelData **data_out_robert;
    PixelData **data_out_sobel;
    int rows; //存储读取后矩阵的行数
    int cols; //列数

public:
    bool ReadImage(const char *path);
    void GenerateGaussWindow(int kernelsize, double sigma); //生成高斯滤波器
    void PerformGaussFilter();                              //高斯滤波
    void ShowGaussWindow();
    void PerformImageSharpenCV();
    void ShowImageCV();
    void PerformImageSharpen(const char *filtername); //根据滤波器名字进行相应高通滤波
};

bool ImageSharpen::ReadImage(const char *path)
{
    cv::Mat image;
    image = cv::imread(path);
    if (image.empty())
    {
        cout << "Open File Error" << std::endl;
        return false;
    }
    rows = image.rows;
    cols = image.cols;
    data = new PixelData *[rows];
    for (int i = 0; i < rows; i++)
    {
        data[i] = new PixelData[cols];
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            data[i][j].Blue = image.at<cv::Vec3b>(i, j)[0];
            data[i][j].Green = image.at<cv::Vec3b>(i, j)[1];
            data[i][j].Red = image.at<cv::Vec3b>(i, j)[2];
        }
    }
    cout << "Successfully Read Image" << endl;
    return true;
}

void ImageSharpen::GenerateGaussWindow(int kernelsize, double sigma)
{
    if (kernelsize % 2 == 0)
    {
        cout << "Please enter an odd number" << endl;
        return;
    }
    ksize = kernelsize; //保存核的大小
    GaussFilterWindow = new double *[kernelsize];
    for (int i = 0; i < kernelsize; i++)
    {
        GaussFilterWindow[i] = new double[kernelsize];
    }
    const double pi = 3.1415926;
    int center = kernelsize / 2;
    double x2, y2;
    double sum = 0;
    for (int i = 0; i < kernelsize; i++)
    {
        x2 = pow(i - center, 2);
        for (int j = 0; j < kernelsize; j++)
        {
            y2 = pow(j - center, 2);
            double g = exp(-(x2 + y2) / (2 * sigma * sigma));
            g /= 2 * pi * sigma;
            GaussFilterWindow[i][j] = g;
            sum += g;
        }
    }
    for (int i = 0; i < ksize; i++)
    {
        for (int j = 0; j < ksize; j++)
        {
            GaussFilterWindow[i][j] /= sum;
        }
    }
}

void ImageSharpen::PerformGaussFilter()
{
    data_out_gauss = new PixelData *[rows];
    for (int i = 0; i < rows; i++)
    {
        data_out_gauss[i] = new PixelData[cols];
    }
    int center = ksize / 2; //模板中心的下标
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            int temp = 0;
            for (int m = 0; m < ksize; m++)
            {
                for (int n = 0; n < ksize; n++)
                {
                    if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                    { //相当于padding0
                        continue;
                    } //因在生成高斯窗的时候已经做了归一化，这里灰度值小于255
                    temp += data[i - center + m][j - center + m].Blue * GaussFilterWindow[m][n];
                }
            }
            data_out_gauss[i][j].Blue = temp;
        }
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            int temp = 0;
            for (int m = 0; m < ksize; m++)
            {
                for (int n = 0; n < ksize; n++)
                {
                    if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                    { //相当于padding0
                        continue;
                    }
                    temp += data[i - center + m][j - center + m].Green * GaussFilterWindow[m][n];
                }
            }
            data_out_gauss[i][j].Green = temp;
        }
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            int temp = 0;
            for (int m = 0; m < ksize; m++)
            {
                for (int n = 0; n < ksize; n++)
                {
                    if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                    { //相当于padding0
                        continue;
                    }
                    temp += data[i - center + m][j - center + m].Red * GaussFilterWindow[m][n];
                }
            }
            data_out_gauss[i][j].Red = temp;
        }
    }
}

void ImageSharpen::ShowGaussWindow()
{
    for (int i = 0; i < ksize; i++)
    {
        for (int j = 0; j < ksize; j++)
        {
            cout << GaussFilterWindow[i][j] << " ";
        }
        cout << endl;
    }
}

void ImageSharpen::PerformImageSharpen(const char *filtername)
{ //需要进行尺度变换
    if (strcmp(filtername, "Laplace") == 0)
    {
        data_out_laplace = new PixelData *[rows];
        for (int i = 0; i < rows; i++)
        {
            data_out_laplace[i] = new PixelData[cols];
        }
        int **filter_output = new int *[rows];
        for (int i = 0; i < rows; i++)
        {
            filter_output[i] = new int[cols];
        }
        int center = 1; //模板中心的下标
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                int temp = 0;
                for (int m = 0; m < 3; m++)
                {
                    for (int n = 0; n < 3; n++)
                    {
                        if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                        { //相当于padding0
                            continue;
                        }
                        temp += (data_out_gauss[i - center + m][j - center + m].Blue + data_out_gauss[i - center + m][j - center + m].Green + data_out_gauss[i - center + m][j - center + m].Red) / 3 * Laplace[m][n];
                    }
                }
                filter_output[i][j] = temp;
            }
        }
        int a = 10000000;
        int b = -10000000;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (filter_output[i][j] < a)
                {
                    a = filter_output[i][j];
                }
                if (filter_output[i][j] > b)
                {
                    b = filter_output[i][j];
                }
            }
        }
        cout << "a=" << a << " b=" << b << endl;
        int temp = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                temp = ((double)(filter_output[i][j] - a)) * (256.0 / (b - a));
                data_out_laplace[i][j].Blue = temp;
                data_out_laplace[i][j].Green = temp;
                data_out_laplace[i][j].Red = temp;
            }
        }
    }
    else if (strcmp(filtername, "Robert") == 0)
    {
        data_out_robert = new PixelData *[rows];
        for (int i = 0; i < rows; i++)
        {
            data_out_robert[i] = new PixelData[cols];
        }
        int **filter_output = new int *[rows];
        for (int i = 0; i < rows; i++)
        {
            filter_output[i] = new int[cols];
        }
        int center = 1; //模板中心的下标
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                int temp1 = 0;
                int temp2=0;
                for (int m = 0; m < 3; m++)
                {
                    for (int n = 0; n < 3; n++)
                    {
                        if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                        { //相当于padding0
                            continue;
                        }
                        temp1 += (data_out_gauss[i - center + m][j - center + m].Blue + data_out_gauss[i - center + m][j - center + m].Green + data_out_gauss[i - center + m][j - center + m].Red) / 3 * Robert1[m][n];
                        temp2 += (data_out_gauss[i - center + m][j - center + m].Blue + data_out_gauss[i - center + m][j - center + m].Green + data_out_gauss[i - center + m][j - center + m].Red) / 3 * Robert2[m][n];
                    }
                }
                filter_output[i][j] = abs(temp1)+abs(temp2);
            }
        }
        int a = 10000000;
        int b = -10000000;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (filter_output[i][j] < a)
                {
                    a = filter_output[i][j];
                }
                if (filter_output[i][j] > b)
                {
                    b = filter_output[i][j];
                }
            }
        }
        cout << "a=" << a << " b=" << b << endl;
        int temp = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                temp = ((double)(filter_output[i][j] - a)) * (256.0 / (b - a));
                data_out_robert[i][j].Blue = temp;
                data_out_robert[i][j].Green = temp;
                data_out_robert[i][j].Red = temp;
            }
        }
    }
    else if (strcmp(filtername, "Sobel") == 0)
    {
        data_out_sobel = new PixelData *[rows];
        for (int i = 0; i < rows; i++)
        {
            data_out_sobel[i] = new PixelData[cols];
        }
        int **filter_output = new int *[rows];
        for (int i = 0; i < rows; i++)
        {
            filter_output[i] = new int[cols];
        }
        int center = 1; //模板中心的下标
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                int temp1 = 0;
                int temp2=0;
                for (int m = 0; m < 3; m++)
                {
                    for (int n = 0; n < 3; n++)
                    {
                        if ((i - center + m) < 0 || (j - center + m) < 0 || (i - center + m) >= rows || (j - center + m) >= cols)
                        { //相当于padding0
                            continue;
                        }
                        temp1 += (data_out_gauss[i - center + m][j - center + m].Blue + data_out_gauss[i - center + m][j - center + m].Green + data_out_gauss[i - center + m][j - center + m].Red) / 3 * Sobel1[m][n];
                        temp2 += (data_out_gauss[i - center + m][j - center + m].Blue + data_out_gauss[i - center + m][j - center + m].Green + data_out_gauss[i - center + m][j - center + m].Red) / 3 * Sobel2[m][n];
                    }
                }
                filter_output[i][j] = pow(pow(temp1,2)+pow(temp2,2),0.5);
            }
        }
        int a = 10000000;
        int b = -10000000;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (filter_output[i][j] < a)
                {
                    a = filter_output[i][j];
                }
                if (filter_output[i][j] > b)
                {
                    b = filter_output[i][j];
                }
            }
        }
        cout << "a=" << a << " b=" << b << endl;
        int temp = 0;
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                temp = ((double)(filter_output[i][j] - a)) * (256.0 / (b - a));
                data_out_sobel[i][j].Blue = temp;
                data_out_sobel[i][j].Green = temp;
                data_out_sobel[i][j].Red = temp;
            }
        }
    }
    return;
}

void ImageSharpen::PerformImageSharpenCV(){//和OpenCV的效果对比，我的高斯模糊效果不对，拉普拉斯算子的结果也不一样
    cv::Mat image_0;
    image_0=cv::imread("./DIP/E1/lena.bmp");
    cv::Mat image_1(image_0.rows,image_0.cols,image_0.type()),image_2(image_0.rows,image_0.cols,image_0.type()),image_3(image_0.rows,image_0.cols,image_0.type());
    cv::GaussianBlur(image_0,image_1,cv::Size(7,7),5,5);
    cv::imshow("0",image_0);
    cv::imshow("1",image_1);
    cv::Mat kernel=(cv::Mat_<char>(3,3) <<  -1, -1 ,-1,
                                            -1, 8, -1,
                                            -1, -1, -1);
    cv::filter2D(image_1,image_2,-1,kernel);

    cv::imshow("2",image_2);
    cv::addWeighted(image_1,1,image_2,1,0,image_3);
    cv::imshow("3",image_3);
    cv::waitKey(0);
    return;
}

void ImageSharpen::ShowImageCV()
{
    cv::Mat image(cols, rows, CV_8UC3);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = data[i][j].Blue;
            image.at<cv::Vec3b>(i, j)[1] = data[i][j].Green;
            image.at<cv::Vec3b>(i, j)[2] = data[i][j].Red;
        }
    }
    cv::imshow("image_0", image);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = data_out_gauss[i][j].Blue;
            image.at<cv::Vec3b>(i, j)[1] = data_out_gauss[i][j].Green;
            image.at<cv::Vec3b>(i, j)[2] = data_out_gauss[i][j].Red;
        }
    }
    cv::imshow("image_guass", image);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = data_out_laplace[i][j].Blue;
            image.at<cv::Vec3b>(i, j)[1] = data_out_laplace[i][j].Green;
            image.at<cv::Vec3b>(i, j)[2] = data_out_laplace[i][j].Red;
        }
    }
    cv::imshow("image_laplace", image);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = data_out_robert[i][j].Blue;
            image.at<cv::Vec3b>(i, j)[1] = data_out_robert[i][j].Green;
            image.at<cv::Vec3b>(i, j)[2] = data_out_robert[i][j].Red;
        }
    }
    cv::imshow("image_robert", image);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < cols; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = data_out_sobel[i][j].Blue;
            image.at<cv::Vec3b>(i, j)[1] = data_out_sobel[i][j].Green;
            image.at<cv::Vec3b>(i, j)[2] = data_out_sobel[i][j].Red;
        }
    }
    cv::imshow("image_sobel", image);
    cv::waitKey(0);
    return;
}

int main()
{
    ImageSharpen imagesharpen;
    imagesharpen.PerformImageSharpenCV();
    imagesharpen.GenerateGaussWindow(7, 5);
    imagesharpen.ShowGaussWindow();
    imagesharpen.ReadImage("./DIP/E1/lena.bmp");
    imagesharpen.PerformGaussFilter();
    imagesharpen.PerformImageSharpen("Laplace");
    imagesharpen.PerformImageSharpen("Robert");
    imagesharpen.PerformImageSharpen("Sobel");
    imagesharpen.ShowImageCV();
}