'''
代码参考：
直线：https://github.com/alyssaq/hough_transform
圆：https://github.com/pranavgadekar/circle-detection-hough-transform
'''
import cv2
import numpy as np
import math
import random
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def edge_demo(image): # Canny边缘提取
    blurred = cv2.GaussianBlur(image, (3, 3), 0)
    gray = cv2.cvtColor(blurred, cv2.COLOR_RGB2GRAY)
    edge_output = cv2.Canny(gray, 50, 150)
    cv2.imshow("Canny Edge", edge_output)
    dst = cv2.bitwise_and(image, image, mask= edge_output)
    cv2.imshow("Color Edge", dst)
    return edge_output

def hough_change(img, angle_step = 1, value_threshold = 5):
    '''
    霍夫变换
    :param img: 待进行霍夫变换的图形，灰度图，要进行霍夫变换的点用白色线条表示
    :param angle_step: 打点步长
    :param value_threshold: 允许误差，当像素大于本值时认为是待检测/变换点
    :return: accumulator：次数记录, thetas：θ索引, rhos：ρ索引
    '''
    thetas = np.deg2rad(np.arange(-90.0, 90.0, angle_step)) # 生成打点对应索引
    [width, height] = img.shape
    diag_len = int(round(math.sqrt(width * width + height * height))) # 记录可能达到的最大距离ρ
    rhos = np.linspace(-diag_len, diag_len, diag_len * 2) # 生成ρ对应索引

    # 创建可重复使用的矩阵
    cos_t = np.cos(thetas)
    sin_t = np.sin(thetas)
    num_thetas = len(thetas)

    accumulator = np.zeros([2 * diag_len, num_thetas], dtype=np.int32) # 生成记录θ、ρ的矩阵
    are_edges = img > value_threshold # 生成边缘点（待变换点）矩阵
    y_idxs, x_idxs = np.nonzero(are_edges) # 获得边缘点索引

    for i in range(len(x_idxs)):
        x = x_idxs[i]
        y = y_idxs[i]
        # 生成第i个点对应的huogh曲线
        for t_idx in range(num_thetas):
            rho = diag_len + int(round(x * cos_t[t_idx] + y * sin_t[t_idx]))
            accumulator[rho, t_idx] += 1 # 记录在极坐标系空间中每个点数据数量，较大的数量处认为可能会有直线
    return accumulator, thetas, rhos

def show_hough_space(accumulator, thetas, rhos):
    '''
    三维显示霍夫空间
    :param accumulator: 霍夫空间中每个位置出现点的次数
    :param thetas: θ索引（x轴）
    :param rhos: ρ索引（y轴）
    '''
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')#建立3D显示图框
    height, width = accumulator.shape
    accu_show = np.zeros([3, width * height])#将ρ，θ，accumulator转换为plt库可识别散点形式
    for i in range(height):
        for j in range(width):
            accu_show[0, j + i * width] = rhos[i]
            accu_show[1, j + i * width] = thetas[j]
            accu_show[2, j + i * width] = accumulator[i, j]
    ax.scatter(accu_show[0], accu_show[1], accu_show[2])
    plt.show()

def fill_acc_array(img, x0, y0, radius, acc_array): # 对计数矩阵进行计数
    height, width = img.shape
    x = radius
    y = 0
    decision = 1 - x

    while (y < x):
        if (x + x0 < height and y + y0 < width):
            acc_array[x + x0, y + y0, radius] += 1;  # Octant 1
        if (y + x0 < height and x + y0 < width):
            acc_array[y + x0, x + y0, radius] += 1;  # Octant 2
        if (-x + x0 < height and y + y0 < width):
            acc_array[-x + x0, y + y0, radius] += 1;  # Octant 4
        if (-y + x0 < height and x + y0 < width):
            acc_array[-y + x0, x + y0, radius] += 1;  # Octant 3
        if (-x + x0 < height and -y + y0 < width):
            acc_array[-x + x0, -y + y0, radius] += 1;  # Octant 5
        if (-y + x0 < height and -x + y0 < width):
            acc_array[-y + x0, -x + y0, radius] += 1;  # Octant 6
        if (x + x0 < height and -y + y0 < width):
            acc_array[x + x0, -y + y0, radius] += 1;  # Octant 8
        if (y + x0 < height and -x + y0 < width):
            acc_array[y + x0, -x + y0, radius] += 1;  # Octant 7
        y += 1
        if (decision <= 0):
            decision += 2 * y + 1
        else:
            x = x - 1;
            decision += 2 * (y - x) + 1

def hough_circle_change(path, r_min = 20, r_max = 55, threshold = 70):
    '''
    霍夫圆检测
    代码主要来自参考网站2，本人对函数进行了一定调整
    :param path: 图片路径
    :param r_min: 检测圆半径最小值
    :param r_max: 检测圆半径最大值
    :param threshold: 园检测阈值，当在圆上的点数大于threshold时认为是一个圆
    :return: 
    '''
    original_image = cv2.imread(path,1)
    cv2.imshow('Original Image', original_image)
    output = original_image.copy() # 输出图片

    #边缘检测
    blur_image = cv2.GaussianBlur(original_image, (3, 3), 0)
    edged_image = cv2.Canny(blur_image, 75, 150)
    cv2.imshow('Edged Image', edged_image)

    height, width = edged_image.shape
    radii = 100 # z方向范围
    acc_array = np.zeros(((height, width, radii))) # 创建计数矩阵
    filter3D = np.zeros((30, 30, radii))
    filter3D[:, :, :] = 1
    edges = np.where(edged_image == 255)
    for i in range(0, len(edges[0])):
        x = edges[0][i]
        y = edges[1][i]
        for radius in range(r_min, r_max):
            fill_acc_array(edged_image, x, y, radius, acc_array)
    '''
    i = 0
    j = 0
    while (i < height - 30): # 分块检测该区域是否有圆存在，认为圆不重叠，可以将重复边界剔除，但无法检测出大圆内的小圆
        while (j < width - 30):
            filter3D = acc_array[i:i + 30, j:j + 30, :] * filter3D
            max_pt = np.where(filter3D == filter3D.max())
            a = max_pt[0]
            b = max_pt[1]
            c = max_pt[2]
            b = b + j
            a = a + i
            if (filter3D.max() > threshold): # 检测到圆
                cv2.circle(output, (b, a), c, (0, 255, 0), 2)
            j = j + 30
            filter3D[:, :, :] = 1
        j = 0
        i = i + 30
    '''
    for x in range(height): # 认为圆可以重叠，适合矢量图或者边缘光滑的图片，可检测出大圆内的小圆
        for y in range(width):
            for z in range(radii):
                if (acc_array[x, y, z] > threshold):  # 检测到圆
                    cv2.circle(output, (y, x), z, (0, 255, 0))
    cv2.imshow('circle', output)
    cv2.waitKey()
    return output

def show_string(img, accumulator, thetas, rhos, threshold = 0.5):
    '''
    在原图上找到直线
    :param img：原图像（方便输出）
    :param accumulator: 霍夫空间中每个位置出现点的次数
    :param thetas: θ索引（x轴）
    :param rhos: ρ索引（y轴）
    :param threshold: 阈值，在accumulator矩阵中与最大值比值大于threshold的点认为记录了直线信息
    :return: string: 直线对应的极坐标方程ρ、θ
    '''
    string = []
    max = np.max(accumulator) # 寻找最大的数量
    height, width = accumulator.shape
    for i in range(height): # 寻找是直线的霍夫空间中的点
        for j in range(width):
            if accumulator[i, j] / max > threshold:
                string.extend([[rhos[i], thetas[j]]])
    print(string)
    #plt.imshow(img)
    for i in string:  # 每点处理，在原图像绘制直线
        rho, theta = i
        if (abs(np.sin(theta)) < 0.00001): # 如果是垂直线，需要特殊处理,x = ρ
            y = np.linspace(0, img.shape[1], img.shape[1])
            x = np.ones(img.shape[1]) * rho
        else: # 如果不是垂直线，不用特殊处理，y = [ρ - x * cos(θ)] /  sin(θ)
            x = np.linspace(0, img.shape[0], img.shape[0])
            y = (rho - x * np.cos(theta)) / np.sin(theta)
        plt.plot(x, y)
    plt.xlim(0, img.shape[0])
    plt.ylim(img.shape[1], 0)
    plt.show()

# 绘制初始的图像（即初始化一个500*500的矩阵，并画上一条线）
img = np.zeros([300, 300]).astype(np.uint8)  # 创建一个矩阵
cv2.line(img, (20, 50), (200, 200), 255)  # 画直线
cv2.line(img, (200, 50), (50, 200), 255)
cv2.line(img, (50, 0), (200, 150), 255)
cv2.imshow('', img)

#src = cv2.imread('1.jpg')
#img = edge_demo(src)

accumulator, thetas, rhos = hough_change(img)
#show_hough_space(accumulator, thetas, rhos)
show_string(img, accumulator, thetas, rhos, threshold=0.6)

#hough_circle_change("circle.jpg" , r_min = 10, threshold=80)