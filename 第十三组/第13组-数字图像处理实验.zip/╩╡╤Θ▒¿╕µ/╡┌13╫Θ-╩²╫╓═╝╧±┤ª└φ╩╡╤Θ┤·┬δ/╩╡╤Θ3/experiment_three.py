'''
调用plt库用以读取和显示图片，显示直方图等
调用numpy库用以实现基本的矩阵操作
'''
import matplotlib.pyplot as plt
import numpy as np
import random
import copy

global WINDOW_X
global WINDOW_Y
WINDOW_Y = 3
WINDOW_X = 3

def show_image(img, place, name):  #显示图片
    plt.subplot(WINDOW_X, WINDOW_Y, place)
    plt.imshow(img, cmap = 'gray', vmin = 0, vmax = 255)
    plt.title(name)
    plt.axis("off")

def show_histogram(darry, place, name, color):  #显示直方图
    plt.subplot(WINDOW_X, WINDOW_Y, place)
    plt.bar(np.arange(256), darry, 0.8, color = color)
    plt.title(name)
    plt.xlabel('level')
    plt.ylabel('count')
    plt.xlim(0, 255)

def create_histogram(img, level_count = 1):  #生成直方图
    histogram = np.zeros(256 // level_count, "int32")
    for i in img:
        for j in i:
            histogram[j // level_count] += 1
    return histogram

def global_linear_transmation(gray, g_min, g_max): #全局灰度变换，将灰度范围设为g_min - g_max
    maxV = gray.max()
    minV = gray.min()
    img = np.zeros(gray.shape)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i, j] = ((gray[i, j] - minV) * (g_max - g_min))/(float)(maxV - minV) + g_min
    return img

def histeq(gray_level = 16):  #直方图均衡化，参数为灰度级
    level_count = 256 // gray_level  #每个灰度级中包含的灰度值数量
    hist = create_histogram(gray_global_transmation, level_count) / (gray_global_transmation.shape[0] * gray_global_transmation.shape[1])
    histp = np.zeros(gray_level)
    for i in range(gray_level):
        histp[i] = sum(hist[0: i + 1])
    s = (gray_level - 1) * histp + 0.5
    s = s.astype("int32")
    img = np.zeros(gray_global_transmation.shape)
    for i in range(gray_global_transmation.shape[0]):
        for j in range(gray_global_transmation.shape[1]):
            img[i, j] = s[gray_global_transmation[i, j] // level_count] * level_count
    img = img.astype("int32")
    return img

def create_gaussian_noise(img, sigma, means = 0):  #生成高斯白噪声，调用random库中生成高斯分布随机数的函数，参考网址  https://blog.csdn.net/kaikai______/article/details/53535909
    noise_img = copy.deepcopy(img)
    rows = noise_img.shape[0]
    cols = noise_img.shape[1]
    for i in range(rows):
        for j in range(cols):
            noise_img[i, j] = noise_img[i, j] + random.gauss(means, sigma)
            if noise_img[i,j] < 0:
                noise_img[i,j] = 0
            elif noise_img[i,j] > 255:
                noise_img[i,j] = 255
    return noise_img

def create_repper_and_salt(img, percetage):    #生成椒盐噪声，参考网址同生成高斯噪声
    noise_img = copy.deepcopy(img)
    noise_num=int(percetage * img.shape[0] * img.shape[1])
    for i in range(noise_num):
        randX = np.random.random_integers(0, img.shape[0] - 1)
        randY = np.random.random_integers(0, img.shape[1] - 1)
        if np.random.random_integers(0,1)<=0.5:
            noise_img[randX,randY]=0
        else:
            noise_img[randX,randY]=255
    return noise_img

def change_size(img, size_of_kernel):  #改变图片大小以适应滤波，返回图片起始点的位置和填充图片。代码参考网址https://blog.csdn.net/luojie140/article/details/79778234
    img_h = img.shape[0]
    img_w = img.shape[1]
    kernel_h = size_of_kernel[0]
    kernel_w = size_of_kernel[1]
    padding_h = int((kernel_h - 1) / 2)
    padding_w = int((kernel_w - 1) / 2)
    convolve_h = int(img_h + 2 * padding_h)
    convolve_W = int(img_w + 2 * padding_w)
    img_padding = np.zeros((convolve_h, convolve_W), "int32")
    # 中心填充图片
    img_padding[padding_h:padding_h + img_h, padding_w:padding_w + img_w] = img[:, :]
    return padding_h, padding_w, img_padding

def middle_filter(img, size_of_kernel = [3, 3]):  #中值滤波器，size of kernel为滤波时取中值的核的大小
    h, w, changed_img = change_size(img, size_of_kernel)
    result = np.zeros(img.shape, "int32")
    for i in range(h, h + img.shape[0]):
        for j in range(w, w + img.shape[1]):
            data = np.zeros(size_of_kernel[0] * size_of_kernel[1], "int32")
            n = 0
            for k in range(i - h, i + h + 1):
                for m in range(j - w, j + w + 1):
                    data[n] = changed_img[k, m]
                    n = n + 1
            result[i - h, j - w] = np.median(data)
    return result

def gauss_filter(img, size_of_kernel = [3, 3], sigma = 1):
    '''
    高斯滤波，img为带滤波图像，sigam为生成高斯核时高斯核的标准差。
    代码参考网址https://blog.csdn.net/luojie140/article/details/79778234
    '''
    gauss_mat_h = gauss_mat_w = 2 * sigma + 1
    gauss_mat = np.zeros((gauss_mat_h, gauss_mat_w))
    for x in range(-sigma, sigma + 1):
        for y in range(-sigma, sigma + 1):
            gauss_mat[x + sigma][y + sigma] = np.exp(-0.5 * (x ** 2 + y ** 2)/(sigma ** 2))
    h, w, changed_img = change_size(img, size_of_kernel)
    result = np.zeros(img.shape, "int32")
    for i in range(h, h + img.shape[0]):
        for j in range(y, y + img.shape[1]):
            result[i - h][j - w] = int(
                np.sum(changed_img[i - h : i + h + 1, j - w : j + w + 1] * gauss_mat))
    result = global_linear_transmation(result, 0, 255)
    return result

def show_experiment_one():
    show_image(img, 1, "origin")
    show_image(gray, 2, "gray")
    show_histogram(gray_histogram, 3, "gray_histogram", "black")
    show_image(r, 4, "r")
    show_histogram(r_histogram, 7, "r_histogram", "red")
    show_image(g, 5, "g")
    show_histogram(g_histogram, 8, "g_histogram", "green")
    show_image(b, 6, "b")
    show_histogram(b_histogram, 9, "b_histogram", "blue")

def show_experiment_two_and_three():
    show_image(img, 1, "origin")
    show_image(gray, 2, "gray")
    show_histogram(gray_histogram, 3, "gray_histogram", "black")
    show_image(gray_global_transmation, 4, "gray_global_transmation")
    show_histogram(gray_changed_histogram, 5, "gray_changed_histogram", "black")
    show_image(gray_histeq, 7, "gray_histeq")
    show_histogram(gray_histeq_histogram, 8, "gray_histeq_histogram", "black")

def show_experiment_four():
    show_image(img, 1, "origin")
    show_image(gray, 2, "gray")
    show_image(noise_gauss, 4, "add_gauss_noise")
    show_image(gauss_middle_filtered_img, 5, "middle_filtered_gauss_image")
    show_image(gauss_gauss_filtered_img, 6, "gauss_filtered_gauss_image")
    show_image(noise_PAS, 7, "add_pepper_and_salt_noise")
    show_image(PAS_middle_filtered_img, 8, "middle_filtered_PAS_image")
    show_image(PAS_gauss_filtered_img, 9, "gauss_filtered_PAS_image")

img = plt.imread("1.jpg")

r = img[:, :, 0]
g = img[:, :, 1]
b = img[:, :, 2]
gray = r * 0.299 + g * 0.587 + b * 0.114
gray = gray.astype("int32")

r_histogram = create_histogram(r)
g_histogram = create_histogram(g)
b_histogram = create_histogram(b)
gray_histogram = create_histogram(gray)

gray_global_transmation = global_linear_transmation(gray, 0, 128)
gray_global_transmation = gray_global_transmation.astype("int32")
gray_changed_histogram = create_histogram(gray_global_transmation)

gray_histeq = histeq(256)
gray_histeq_histogram = create_histogram(gray_histeq)

noise_gauss = create_gaussian_noise(gray, 20)
gauss_middle_filtered_img = middle_filter(noise_gauss)
gauss_gauss_filtered_img = gauss_filter(noise_gauss, [5, 5], 2)
noise_PAS = create_repper_and_salt(gray, 0.1)
PAS_middle_filtered_img = middle_filter(noise_PAS)
PAS_gauss_filtered_img = gauss_filter(noise_PAS)

figure = plt.figure(figsize=(WINDOW_X * 10, WINDOW_Y * 6))
plt.subplots_adjust(hspace=0.5, wspace=0.5)

#show_experiment_one()
#show_experiment_two_and_three()
show_experiment_four()

plt.show()