#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;
using namespace cv;

double CalMSE(Mat &image_0, Mat &image_1)
{ //计算MSE，对灰度图像操作
    double h, w;
    h = image_0.rows;
    w = image_0.cols;
    double temp = 0;
    for (int i = 0; i < h; i++)
    {
        for (int j = 0; j < w; j++)
        {
            temp += pow(image_0.at<uchar>(i, j) - image_1.at<uchar>(i, j), 2);
        }
    }
    return temp / (h * w);
}

double CalPSNR(double MSE, int bit)
{
    return 10 * log10(pow((pow(2, bit) - 1), 2) / MSE);
}

void PerformMotionBlur(cv::Mat &DFTImage, cv::Mat &MotionBlurOutput)
{
    double pi = 3.14159265;
    int u, v;
    std::complex<double> z, temp;
    z.real(0);
    z.imag(-1);
    double T = 2;
    double n = 50; //采样点数
    for (u = 0; u < DFTImage.rows; u++)
    {
        for (v = 0; v < DFTImage.cols; v++)
        {
            temp = 0;
            for (int i = 0; i < n; i++)
            {
                double t = i / n * T;
                temp += exp(z * 2.0 * pi * (u * 0.01 * t + v * 0.02 * t)) * 1.0 / n; //                                             为什么需要到两位小数的尺度才可以正常显示？
            }
            MotionBlurOutput.at<float>(u, v) = DFTImage.at<float>(u, v) * pow(pow(temp.real(), 2) + pow(temp.imag(), 2), 0.5);
        }
    }
    return;
}

void RestoreImage(cv::Mat &MotionBlurOutput, cv::Mat &RestoredOutput)
{
    double pi = 3.14159265;
    int u, v;
    std::complex<double> z, temp;
    z.real(0);
    z.imag(-1);
    double T = 2.00;
    double n = 50; //采样点数(当动态模糊函数中的值过小(比如10)这里的值就不能大于动态模糊的，否则只会出现斑马纹。为什么？是否是积分误差？)
    for (u = 0; u < MotionBlurOutput.rows; u++)
    {
        for (v = 0; v < MotionBlurOutput.cols; v++)
        {
            temp = 0;
            for (int i = 0; i < n; i++)
            {
                double t = i / n * T;
                temp += exp(z * 2.0 * pi * (u * 0.0100 * t + v * 0.01999 * t)) * 1.0 / n;
            }
            RestoredOutput.at<float>(u, v) = MotionBlurOutput.at<float>(u, v) / pow(pow(temp.real(), 2) + pow(temp.imag(), 2), 0.5);
        }
    }
    return;
}

int main()
{

    cv::Mat inputImage = cv::imread("./DIP/E1/lena.bmp", cv::IMREAD_GRAYSCALE); // 以灰度形式读取图片
    cv::imshow("Input", inputImage);

    cv::Mat FloatImage; // 浮点化，便于进行dft
    inputImage.convertTo(FloatImage, CV_32F);

    // DFT
    cv::Mat DFTImage;
    cv::dft(FloatImage, DFTImage, cv::DFT_SCALE); //scale进行归一化
//    cv::imshow("DFT", DFTImage);

    // 进行频域处理
    cv::Mat MotionBlurOutput(DFTImage.rows, DFTImage.cols, CV_32FC1),RestoredOutput(DFTImage.rows, DFTImage.cols, CV_32FC1);
    PerformMotionBlur(DFTImage, MotionBlurOutput);
    RestoreImage(MotionBlurOutput,RestoredOutput);
    // IDFT
    cv::Mat inverseTransform0, inverseTransform1,inverseTransform2;
    cv::dft(DFTImage, inverseTransform0, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT);
    cv::dft(MotionBlurOutput, inverseTransform1, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT);
    cv::dft(RestoredOutput, inverseTransform2, cv::DFT_INVERSE | cv::DFT_REAL_OUTPUT);

    // 转化为灰度图像，imshow
    cv::Mat OutImage_0, OutImage_1,OutImage_2;
    inverseTransform0.convertTo(OutImage_0, CV_8U);
    inverseTransform1.convertTo(OutImage_1, CV_8U);
    inverseTransform2.convertTo(OutImage_2, CV_8U);
//    cv::imshow("IDFT", OutImage_0);
    cv::imshow("MotionBlur", OutImage_1);
    cv::imshow("Restored",OutImage_2);
    double MSE;
    MSE=CalMSE(inputImage,OutImage_2);
    cout<<"MSE= "<<MSE<<endl;
    cout<<"PSNR= "<<CalPSNR(MSE,8);
    cv::waitKey(0);
}