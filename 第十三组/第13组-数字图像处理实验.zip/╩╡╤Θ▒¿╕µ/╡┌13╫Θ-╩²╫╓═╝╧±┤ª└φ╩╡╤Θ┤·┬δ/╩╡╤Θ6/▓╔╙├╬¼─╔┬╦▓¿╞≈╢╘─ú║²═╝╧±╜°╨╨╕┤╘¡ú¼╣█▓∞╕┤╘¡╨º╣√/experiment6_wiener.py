'''
代码参考网址：https://github.com/lvxiaoxin/Wiener-filter
'''
import cv2
import matplotlib.pyplot as plt
import numpy as np

def show_image(img, place, name):  #显示图片,输入图片、位置、名字
    plt.subplot(4, 2, place)
    plt.imshow(img, cmap = 'gray')
    plt.title(name)
    plt.axis("off")


def motion_process(img, len):
    '''
    生成运动模糊变化矩阵（退化函数）
    :param img: 待模糊的图像 
    :param len: 运动长度
    :return: 归一化后的亮度变化矩阵
    '''
    sx, sy = img.shape
    PSF = np.zeros((sy, sx))
    PSF[int(sy / 2):int(sy /2 + 1), int(sx / 2 - len / 2):int(sx / 2 + len / 2)] = 1
    return PSF / PSF.sum() # 归一化亮度

def make_blurred(img, PSF, EPS):
    '''
    根据运动亮度变化与噪声叠加矩阵矩阵进行图像运动模糊（退化）
    :param img: 原图
    :param PSF: 运动退化矩阵
    :param ESP: 噪声矩阵
    :return: 模糊后的图形
    '''
    img_fft = np.fft.fft2(img)
    PSF_fft = np.fft.fft2(PSF) + EPS
    blurred = np.fft.ifft2(img_fft * PSF_fft)
    blurred = np.abs(np.fft.fftshift(blurred))
    return blurred

def wiener(img, PSF, K):
    '''
    维纳滤波
    :param img: 模糊图像 
    :param PSF: 运动退化矩阵
    :param K: 维纳滤波中信噪比
    :return: 维纳滤波后的图像
    '''
    img_fft = np.fft.fft2(img)
    PSF_fft = np.fft.fft2(PSF) #退化函数
    PSF_fft_H = np.matrix.getH(PSF_fft)
    DET = PSF_fft * PSF_fft_H
    H = DET / (DET + K + 1e-10) #防止0/0的情况
    result = np.fft.ifft2(img_fft / (PSF_fft + 1e-10) * H) #计算F(u,v)的傅里叶反变换,防止分母为零在分母加上一个极小偏移量
    result = np.abs(np.fft.fftshift(result))
    return result

def MSE(img1, img2):
    '''
    计算MSE
    :param img1: 图像1
    :param img2: 图像2
    :return: MSE值
    '''
    dif = img1 - img2
    dif = dif ** 2
    mse = dif.sum() / (dif.shape[0] * dif.shape[1])
    return mse

img = cv2.imread("1.jpg", 0)
fig = plt.figure()
show_image(img, 1, "ori")

# 长度为30像素的运动退化
PSF1 = motion_process(img, 30)
changed_img1 = np.abs(make_blurred(img, PSF1, 0))
show_image(changed_img1, 3, "montion")
wiener_img1 = wiener(changed_img1, PSF1, 0)
mse1 = MSE(wiener_img1 ,img)
show_image(wiener_img1, 4, "wiener1,mse:%3f"%mse1)

# 在退化图形上添加一个随机高斯噪声
changed_img2 = changed_img1 + 10 * np.random.standard_normal(changed_img1.shape)
show_image(changed_img2, 5, "montion + noise")
wiener_img2 = wiener(changed_img2, PSF1, 0.089)
mse1 = MSE(wiener_img2 ,img)
show_image(wiener_img2, 6, "wiener2,mse:%3f"%mse1)

# K值为零可认为是逆滤波
show_image(changed_img2, 7, "montion + noise")
wiener_img3 = wiener(changed_img2, PSF1, 0)
mse1 = MSE(wiener_img3 ,img)
show_image(wiener_img3, 8, "wiener3,mse:%3f"%mse1)
plt.show()

