/*
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
对灰度图像伪彩色增强
增强选用的映射来自https://www.cnblogs.com/xianglan/archive/2010/12/29/1920727.html
*/
#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;

int Palette[16][3]={
    {0,51,0},
    {0,51,102},
    {51,51,102},
    {51,102,51},
    {51,51,153},
    {102,51,102},
    {153,153,0},
    {51,102,153},
    {153,102,51},
    {153,204,102},
    {204,153,102},
    {102,204,102},
    {153,204,153},
    {204,204,102},
    {204,255,204},
    {255,255,204}
};

int GetR(int gray)
{
    if (gray < 127)
    {
        return 0;
    }
    else if (gray > 191)
    {
        return 255;
    }
    else
    {
        return (gray - 127) * 4 - 1;
    }
}

int GetG(int gray)
{
    if (gray < 64)
    {
        return 4*gray;
    }
    else if (gray > 191)
    {
        return 256-(gray-191)*4;
    }
    else
    {
        return 255;
    }
}

int GetB(int gray)
{
    if (gray < 64)
    {
        return 255;
    }
    else if (gray > 127)
    {
        return 0;
    }
    else
    {
        return 256-(gray-63)*4;
    }
}

int main(){
    cv::Mat image_0=cv::imread("./DIP/E1/lena_gray.bmp");
    cv::Mat image_1(image_0.rows,image_0.cols,CV_8UC3);
    cv::Mat image_2(image_0.rows,image_0.cols,CV_8UC3);
    int gray=0;
    for(int i=0;i<image_0.rows;i++){
        for(int j=0;j<image_0.cols;j++){
            gray=image_0.at<cv::Vec3b>(i,j)[0];//注意< >的数据类型
            image_1.at<cv::Vec3b>(i,j)[0]=GetB(gray);
            image_1.at<cv::Vec3b>(i,j)[1]=GetG(gray);
            image_1.at<cv::Vec3b>(i,j)[2]=GetR(gray);
            image_2.at<cv::Vec3b>(i,j)[0]=Palette[gray/16][1];
            image_2.at<cv::Vec3b>(i,j)[1]=Palette[gray/16][0];
            image_2.at<cv::Vec3b>(i,j)[2]=Palette[gray/16][2];
        }
    }
    cv::imshow("image_0",image_0);
    cv::imshow("image_1",image_1);
    cv::imshow("image_2",image_2);
    cv::waitKey(0);
    return 0;
}