/*
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
拖动三个进度条改变HSI的偏移量
*/

#include <iostream>
#include <opencv.hpp>

using namespace std;
using namespace cv;

bool FlagStop = false;     //判断是否停止显示
bool FlagOutRange = false; //判断HSI的值是否越界，并输出警告

const double pi = 3.14159265;

typedef struct
{
  double H;
  double S;
  double I;
} HSI;

int main()
{

  Mat image_0 = imread("./DIP/E1/lena.bmp");
  if (image_0.empty())
    cerr << "Open File Error" << endl;
  Mat image_1(image_0.rows, image_0.cols, image_0.type());
  HSI **hsi = new HSI *[image_0.rows];
  for (int i = 0; i < image_0.rows; i++)
  {
    hsi[i] = new HSI[image_0.cols];
  }
  double r, g, b, H, S, I, num, den, theta, sum, min_RGB;

  for (int i = 0; i < image_0.rows; i++)
  {
    for (int j = 0; j < image_0.cols; j++)
    {
      b = image_0.at<Vec3b>(i, j)[0];
      g = image_0.at<Vec3b>(i, j)[1];
      r = image_0.at<Vec3b>(i, j)[2];
      // 归一化
      b = b / 255.0;
      g = g / 255.0;
      r = r / 255.0;
      num = 0.5 * ((r - g) + (r - b));                   //分子
      den = sqrt((r - g) * (r - g) + (r - b) * (g - b)); //分母
      theta = acos(num / den);

      if (den == 0)
      {
        H = 0; // S=0时，对应无色，此时H没有意义，定义为0
      }
      else
      {
        if (b <= g)
        {
          H = theta;
        }
        else
        {
          H = (2 * pi - theta);
        }
      }
      min_RGB = min(min(b, g), r);
      sum = b + g + r;
      if (sum == 0)
      {
        S = 0;
      }
      else
      {
        S = 1 - 3 * min_RGB / sum;
      }
      I = sum / 3.0;
      hsi[i][j].H = H; //保存变换完成的HSI
      hsi[i][j].S = S;
      hsi[i][j].I = I;
    }
  }
  namedWindow("image_0", WINDOW_AUTOSIZE);
  namedWindow("image_1", WINDOW_AUTOSIZE);
  int OffsetH200 = 100;
  int OffsetS200 = 100;
  int OffsetI200 = 100;
  double OffsetH = 0;
  double OffsetS = 0;
  double OffsetI = 0;
  createTrackbar("OffsetH%", "image_1", &OffsetH200, 200); //100是初始值，向左滑减小，向右滑增大
  createTrackbar("OffsetS%", "image_1", &OffsetS200, 200);
  createTrackbar("OffsetI%", "image_1", &OffsetI200, 200);
  while (!FlagStop)
  {
    OffsetH = (OffsetH200 - 100) / 100.0 * 2 * pi;
    OffsetS = (OffsetS200 - 100) / 100.0;
    OffsetI = (OffsetI200 - 100) / 100.0;
    for (int i = 0; i < image_0.rows; i++)
    {
      for (int j = 0; j < image_0.cols; j++)
      {
        H = hsi[i][j].H + OffsetH;
        S = hsi[i][j].S + OffsetS;
        I = hsi[i][j].I + OffsetI;
        if (H > 2 * pi)
        {
          H = 2 * pi;
          FlagOutRange = true;
        }
        else if (H < 0)
        {
          H = 0;
          FlagOutRange = true;
        }
        if (S > 1)
        {
          S = 1;
          FlagOutRange = true;
        }
        else if (S < 0)
        {
          S = 0;
          FlagOutRange = true;
        }
        if (I > 1)
        {
          I = 1;
          FlagOutRange = true;
        }
        else if (I < 0)
        {
          I = 0;
          FlagOutRange = true;
        }
        if (H >= 0 && H < 2 * pi / 3)
        {
          b = I * (1 - S);
          r = I * (1 + (S * cos(H)) / cos(pi / 3 - H));
          g = 3 * I - (b + r);
        }
        else if (H >= 2 * pi / 3 && H < 4 * pi / 3)
        {
          r = I * (1 - S);
          g = I * (1 + (S * cos(H - 2 * pi / 3)) / (cos(pi - H)));
          b = 3 * I - (g + r);
        }
        else
        {
          g = I * (1 - S);
          b = I * (1 + (S * cos(H - 4 * pi / 3)) / cos(5 * pi / 3 - H));
          r = 3 * I - (g + b);
        }
        if(r<0){
          r=0;
        }
        else if(r>1){
          r=1;
        }
        if(g<0){
          g=0;
        }
        else if(g>1){
          g=1;
        }
        if(b<0){
          b=0;
        }
        else if(b>1){
          b=1;
        }
        image_1.at<Vec3b>(i, j)[0] = b * 255;
        image_1.at<Vec3b>(i, j)[1] = g * 255;
        image_1.at<Vec3b>(i, j)[2] = r * 255;
      }
    }//调整I时，若要全白，需先将饱和度调整至0，因当I=1时，R=G=B=255，S应为0
    imshow("image_0", image_0);
    imshow("image_1", image_1);
    char key = waitKey(40);
    if (key == 'q' || key == 'Q' || key == 27)
    {
      FlagStop = true;
    }
  }
  return 0;
}