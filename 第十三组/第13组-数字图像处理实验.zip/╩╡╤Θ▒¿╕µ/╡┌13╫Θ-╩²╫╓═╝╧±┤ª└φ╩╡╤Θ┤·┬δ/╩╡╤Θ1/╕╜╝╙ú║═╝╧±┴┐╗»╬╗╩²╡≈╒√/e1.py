import cv2
import numpy as np
import matplotlib.pyplot as plt

def valueAtBit(num, bit):        #按二进制位取数
    return (num >> bit) & 1

img = cv2.imread("1.jpg")
img = img[:, :, :: -1]          #由bgt转换为rgb存储格式
height = img.shape[0]
weight = img.shape[1]
channels = img.shape[2]
image = np.empty([8, height, weight, channels])     #建立数组存储各通道
for i in range(8):
    for row in range(height):            #遍历高
        for col in range(weight):         #遍历宽
            for c in range(channels):     #便利通道
                pv = img[row, col, c]
                image[i, row, col, c] = valueAtBit(pv, i)

plt.figure()

for i in range(8):    #显示每一位对应图像
    plt.subplot(3, 3, i + 1)
    plt.title("{}".format(i))
    plt.imshow(image[i] * 2**i)
    plt.xticks([])
    plt.yticks([])

new_image = np.empty([height, weight, channels])
for i in range(4):      #将高四位图像信息合并，并将其映射到【0，255】空间上（由于显示图片调用plt库，只能通过这种伪转换的方式显示4位深度图）
    new_image = new_image + image[4 + i] * (2**i) * 16
new_image.astype(float)
plt.subplot(3, 3, 9)
plt.title("deep:four")
plt.imshow(new_image / 255)
plt.xticks([])
plt.yticks([])

plt.show()