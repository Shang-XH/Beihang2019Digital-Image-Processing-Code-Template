/*  
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
24bit full color BMP
参考链接：
    https://www.cnblogs.com/xiekeli/archive/2012/05/09/2491191.html
    https://github.com/edimetia3d/simpleBMP/blob/master/simpleBMP.h
*/
#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;

typedef unsigned short WORD; //2byte
typedef unsigned long DWORD; //4byte
typedef long LONG;           //4byte
typedef unsigned char BYTE;  //1byte

#pragma pack(1) //让结构体按照1byte对齐，防止文件读取及保存出错

typedef struct
{                     //bitmap file header,BMP文件头，一共14byte
    WORD bfType;      //如果是BMP图像就是'BM'
    DWORD bfSize;     //以字节为单位的BMP文件大小
    WORD bfReserved1; //设置为0
    WORD bfReserved2; //设置为0
    DWORD bfOffBits;  //从文件头到图像数据的偏移量，如果为54byte则没有调色板
} BITMAPFILEHEADER;

typedef struct
{                         //bitmap info header,BMP位图信息段，一共40byte
    DWORD biSize;         //BITMAPINFOHEADER结构占用的字节数
    LONG biWidth;         //图像的宽度像素
    LONG biHeight;        //图像的高度像素
    WORD biPlanes;        //平面数，设置为1
    WORD biBitCount;      //一个像素占的比特数，1，4，8，16，24，32
    DWORD biCompression;  //图像压缩类型，0为不压缩
    DWORD biSizeImage;    //不压缩时设置为0
    LONG biXPelsPerMeter; //水平分辨率，像素/米
    LONG biYPelsPerMeter; //垂直分辨率
    DWORD biClrUsed;      //设为0的话，则说明使用所有调色板项
    DWORD biClrImportant; //说明对图象显示有重要影响的颜色索引的数目，如果是0，表示都重要
} BITMAPINFOHEADER;

typedef struct
{
    BYTE Red;
    BYTE Green;
    BYTE Blue;
} PixData24;

class BITMAP //建立一个BITMAP类方便操作
{
private:
    BITMAPFILEHEADER BMFHData;
    BITMAPINFOHEADER BMIHData;
    PixData24 *Data24;
    bool flag = 0;

public:
    bool LoadImage(const char *path);
    bool SaveImage(const char *path);
    void ShowBMPCV();
};
#pragma pack() //恢复默认对齐方式

bool BITMAP::LoadImage(const char *path)
{
    FILE *pFile;
    pFile = fopen(path, "rb");
    if (pFile==0)//如果空指针
    {
        cout << "Open File Error" << endl;
        return false;
    }
    fread(&BMFHData, sizeof(BITMAPFILEHEADER), 1, pFile);//先读取文件头
    if (BMFHData.bfType != 0x4D42) //bfType不为"BM"
    {
        cout << "Not A BMP File" << endl;
        fclose(pFile);
        return false;
    }
    int channels = 0; //图片通道数
    fread(&BMIHData, sizeof(BITMAPINFOHEADER), 1, pFile);//再读取信息头
    cout << "Height,Width= " << BMIHData.biHeight << " , " << BMIHData.biWidth << endl;
    cout << "bitCount= " << BMIHData.biBitCount << endl;
    if (BMIHData.biBitCount == 24) //真彩色图片，无调色板
    {
        flag = 1;                                                     //flag=1说明成功读取文件
        Data24 = new PixData24[BMIHData.biWidth * BMIHData.biHeight]; //申请空间存储图像数据
        int offset = (BMIHData.biWidth * channels) % 4;               //计算每行为了凑4的倍数而添加的0值
        if (offset > 0)
        {
            offset = 4 - offset;
        }
        BYTE PixelChannelData;
        int temp = 0;
        for (int i = 0; i < BMIHData.biHeight; i++) //逐行读取文件，跳过每行最后凑4倍数填的0
        {
            for (int j = 0; j < BMIHData.biWidth; j++) //以像素为单位，temp代表第几个像素
            {
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Blue = PixelChannelData;
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Green = PixelChannelData;
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Red = PixelChannelData;
                temp++;
            }
            fseek(pFile, offset * sizeof(BYTE), SEEK_CUR); //跳过偏移量
        }
    }
    else
    {
        cout << "bitCount=" << BMIHData.biBitCount << " Sorry Format Not Supported" << endl;
        fclose(pFile);
        return false;
    }
    fclose(pFile);
    return true;
}

bool BITMAP::SaveImage(const char *path)
{
    if (flag == 0)//如果flag=0说明未成功读取图片
    {
        cout << "Please Load An Image First" << endl;
        return false;
    }
    FILE *pFile = fopen(path, "wb");
    if (!pFile)
    {
        cout << "Open File Error" << endl;
        return false;
    }
    fwrite(&BMFHData, sizeof(BMFHData), 1, pFile);
    fwrite(&BMIHData, sizeof(BMIHData), 1, pFile);
    if (BMIHData.biBitCount == 24)
    {
        int channels = 3;
        int offset = (BMIHData.biWidth * channels) % 4;
        if (offset > 0)
        {
            offset = 4 - offset;
        }
        int temp = 0;
        const int padding = 0; //将偏移量部分填充为0
        for (int i = 0; i < BMIHData.biHeight; i++)
        {
            for (int j = 0; j < BMIHData.biWidth; j++)
            {
                fwrite(&Data24[temp].Blue, sizeof(BYTE), 1, pFile);
                fwrite(&Data24[temp].Green, sizeof(BYTE), 1, pFile);
                fwrite(&Data24[temp].Red, sizeof(BYTE), 1, pFile);
                temp++;
            }
            fwrite(&padding, 1, offset, pFile);//填充偏移量
        }
        fclose(pFile);
        return true;
    }
    cout << "Save Failed" << endl;
    return false;
}

void BITMAP::ShowBMPCV()
{
    if (BMIHData.biBitCount == 24)
    {
        cv::Mat image(BMIHData.biWidth, BMIHData.biHeight, CV_8UC3);
        int temp = 0;
        for (int i = BMIHData.biHeight - 1; i >= 0; i--) //注意opencv的行列排序与bmp不一样
            for (int j = 0; j < BMIHData.biWidth; j++)
            {
                image.at<cv::Vec3b>(i, j)[0] = Data24[temp].Blue;
                image.at<cv::Vec3b>(i, j)[1] = Data24[temp].Green;
                image.at<cv::Vec3b>(i, j)[2] = Data24[temp].Red;
                temp++;
            }
        cv::imshow("lena", image);
        cv::waitKey(0);
    }
    else
    {
        cout << "Sorry Format Not Supported" << endl;
    }
    return;
}

int main()
{
    BITMAP bmp;
    if (bmp.LoadImage("./DIP/lena.bmp") == true)
    {
        bmp.ShowBMPCV();
    }
    bmp.SaveImage("./DIP/lena_saved.bmp");
    return 0;
}