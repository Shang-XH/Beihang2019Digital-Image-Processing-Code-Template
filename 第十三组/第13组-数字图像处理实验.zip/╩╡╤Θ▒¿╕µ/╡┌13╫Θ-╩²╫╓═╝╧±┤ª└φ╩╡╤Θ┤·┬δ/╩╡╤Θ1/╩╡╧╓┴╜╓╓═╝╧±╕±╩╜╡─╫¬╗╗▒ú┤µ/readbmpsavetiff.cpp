/*
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
Based on readsavebmp.cpp
24bit bmp to 24bit uncompressed tif
*/
#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;

typedef unsigned short WORD; //2byte
typedef unsigned long DWORD; //4byte
typedef long LONG;           //4byte
typedef unsigned char BYTE;  //1byte

#pragma pack(1) //让结构体按照1byte对齐，防止文件读取及保存出错

typedef struct
{                   //文件头
    WORD ByteOrder; //MM or II ,为windows方便只支持II
    WORD N42;       //就是42
    DWORD Offset;   //从文件开头到第一个IFD的偏移量
} HEADER;

typedef struct
{                        //目录入口，存在IFD里面
    WORD Tag;            //DE的标签，说明目录里存储的信息是什么
    WORD FieldType;      //值的数据类型
    DWORD Count;         //值的数量
    DWORD ValueOrOffset; //如果数据类型乘以数量小于4byte，这个就是值。否则就是DE存储数据地址的偏移量
} DE;                    //IFD Entry

typedef struct
{                    //目录，一张图片就是一个目录
    WORD NumberOfDE; //IFD中DE的数量
    DE *pDE;         //DE数据类型的指针，根据DE的数量new一个数组
    DWORD Offset;    //指向下一个IFD的偏移量。如果没有下一个，就是0
} IFD;

typedef struct
{                     //bitmap file header,BMP文件头，一共14byte
    WORD bfType;      //如果是BMP图像就是'BM'
    DWORD bfSize;     //以字节为单位的BMP文件大小
    WORD bfReserved1; //设置为0
    WORD bfReserved2; //设置为0
    DWORD bfOffBits;  //从文件头到图像数据的偏移量，如果为54byte则没有调色板
} BITMAPFILEHEADER;

typedef struct
{                         //bitmap info header,BMP位图信息段，一共40byte
    DWORD biSize;         //BITMAPINFOHEADER结构占用的字节数
    LONG biWidth;         //图像的宽度像素
    LONG biHeight;        //图像的高度像素
    WORD biPlanes;        //平面数，设置为1
    WORD biBitCount;      //一个像素占的比特数，1，4，8，16，24，32
    DWORD biCompression;  //图像压缩类型，0为不压缩
    DWORD biSizeImage;    //不压缩时设置为0
    LONG biXPelsPerMeter; //水平分辨率，像素/米
    LONG biYPelsPerMeter; //垂直分辨率
    DWORD biClrUsed;      //设为0的话，则说明使用所有调色板项
    DWORD biClrImportant; //说明对图象显示有重要影响的颜色索引的数目，如果是0，表示都重要
} BITMAPINFOHEADER;

typedef struct
{
    BYTE Red;
    BYTE Green;
    BYTE Blue;
} PixData24;

class BITMAP //建立一个BITMAP类方便操作
{
private:
    HEADER header;
    IFD ifd;
    BITMAPFILEHEADER BMFHData;
    BITMAPINFOHEADER BMIHData;
    PixData24 *Data24;
    bool flag = 0;

public:
    bool LoadImage(const char *path);
    bool SaveTIFFImage(const char *path);
    void ShowBMPCV();
};
#pragma pack() //恢复默认对齐方式

bool BITMAP::LoadImage(const char *path)
{
    FILE *pFile;
    pFile = fopen(path, "rb");
    if (pFile==0)//如果空指针
    {
        cout << "Open File Error" << endl;
        return false;
    }
    fread(&BMFHData, sizeof(BITMAPFILEHEADER), 1, pFile);//先读取文件头
    if (BMFHData.bfType != 0x4D42) //bfType不为"BM"
    {
        cout << "Not A BMP File" << endl;
        fclose(pFile);
        return false;
    }
    int channels = 0; //图片通道数
    fread(&BMIHData, sizeof(BITMAPINFOHEADER), 1, pFile);//再读取信息头
    cout << "Height,Width= " << BMIHData.biHeight << " , " << BMIHData.biWidth << endl;
    cout << "bitCount= " << BMIHData.biBitCount << endl;
    if (BMIHData.biBitCount == 24) //真彩色图片，无调色板
    {
        flag = 1;                                                     //flag=1说明成功读取文件
        Data24 = new PixData24[BMIHData.biWidth * BMIHData.biHeight]; //申请空间存储图像数据
        int offset = (BMIHData.biWidth * channels) % 4;               //计算每行为了凑4的倍数而添加的0值
        if (offset > 0)
        {
            offset = 4 - offset;
        }
        BYTE PixelChannelData;
        int temp = 0;
        for (int i = 0; i < BMIHData.biHeight; i++) //逐行读取文件，跳过每行最后凑4倍数填的0
        {
            for (int j = 0; j < BMIHData.biWidth; j++) //以像素为单位，temp代表第几个像素
            {
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Blue = PixelChannelData;
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Green = PixelChannelData;
                fread(&PixelChannelData, sizeof(BYTE), 1, pFile);
                Data24[temp].Red = PixelChannelData;
                temp++;
            }
            fseek(pFile, offset * sizeof(BYTE), SEEK_CUR); //跳过偏移量
        }
    }
    else
    {
        cout << "bitCount=" << BMIHData.biBitCount << " Sorry Format Not Supported" << endl;
        fclose(pFile);
        return false;
    }
    fclose(pFile);
    return true;
}

bool BITMAP::SaveTIFFImage(const char *path)
{
    if (flag == 0)//如果flag=0说明未成功读取图片
    {
        cout << "Please Load An Image First" << endl;
        return false;
    }
    FILE *pFile = fopen(path, "wb");
    if (!pFile)
    {
        cout << "Open File Error" << endl;
        return false;
    }
    header.ByteOrder=0x4949;
    header.N42=42;
    fwrite(&header,sizeof(HEADER),1,pFile);//写入文件头
    int temp = 0;
    for (int i = BMIHData.biHeight-1; i>=0; i--)//bmp与tiff像素存储顺序不同
    {   
        temp=i*BMIHData.biWidth;
        for (int j = 0; j < BMIHData.biWidth; j++)
        {
            fwrite(&Data24[temp].Red, sizeof(BYTE), 1, pFile);
            fwrite(&Data24[temp].Green, sizeof(BYTE), 1, pFile);
            fwrite(&Data24[temp].Blue, sizeof(BYTE), 1, pFile);
            temp++;
        }
    }
    header.Offset=ftell(pFile);//在header中记录ifd的偏移量
    ifd.NumberOfDE=7;//记录ifd与de
    ifd.pDE=new DE[ifd.NumberOfDE];
    ifd.pDE[0].Tag=256;//width
    ifd.pDE[0].FieldType=3;
    ifd.pDE[0].Count=1;
    ifd.pDE[0].ValueOrOffset=BMIHData.biHeight;
    ifd.pDE[1].Tag=257;//length
    ifd.pDE[1].FieldType=3;
    ifd.pDE[1].Count=1;
    ifd.pDE[1].ValueOrOffset=BMIHData.biWidth;
    ifd.pDE[2].Tag=258;//bits per sample
    ifd.pDE[2].FieldType=3;
    ifd.pDE[2].Count=3;
    ifd.pDE[2].ValueOrOffset=header.Offset+sizeof(WORD)+ifd.NumberOfDE*sizeof(DE)+sizeof(DWORD);//写在数据末尾。
    ifd.pDE[3].Tag=259;//compression
    ifd.pDE[3].FieldType=3;
    ifd.pDE[3].Count=1;
    ifd.pDE[3].ValueOrOffset=1;
    ifd.pDE[4].Tag=262;//PhotometricInterpretation, 2
    ifd.pDE[4].FieldType=3;
    ifd.pDE[4].Count=1;
    ifd.pDE[4].ValueOrOffset=2;
    ifd.pDE[5].Tag=273;//strip offset
    ifd.pDE[5].FieldType=4;
    ifd.pDE[5].Count=1;
    ifd.pDE[5].ValueOrOffset=8;
    ifd.pDE[6].Tag=277;//sample per pixel
    ifd.pDE[6].FieldType=3;
    ifd.pDE[6].Count=1;
    ifd.pDE[6].ValueOrOffset=3;
    ifd.Offset=0;
    fwrite(&ifd.NumberOfDE,sizeof(WORD),1,pFile);//写入ifd与de
    fwrite(ifd.pDE,sizeof(DE),ifd.NumberOfDE,pFile);//pDE本身就是指针
    fwrite(&ifd.Offset,sizeof(DWORD),1,pFile);
    WORD bitspersample=8;
    fwrite(&bitspersample,sizeof(WORD),1,pFile);
    fwrite(&bitspersample,sizeof(WORD),1,pFile);
    fwrite(&bitspersample,sizeof(WORD),1,pFile);
    fseek(pFile,sizeof(DWORD),SEEK_SET);//写入ifd的偏移量
    fwrite(&header.Offset,sizeof(DWORD),1,pFile);
    fclose(pFile);
    return true;
}

void BITMAP::ShowBMPCV()
{
    if (BMIHData.biBitCount == 24)
    {
        cv::Mat image(BMIHData.biWidth, BMIHData.biHeight, CV_8UC3);
        int temp = 0;
        for (int i = BMIHData.biHeight - 1; i >= 0; i--) //注意opencv的行列排序与bmp不一样
            for (int j = 0; j < BMIHData.biWidth; j++)
            {
                image.at<cv::Vec3b>(i, j)[0] = Data24[temp].Blue;
                image.at<cv::Vec3b>(i, j)[1] = Data24[temp].Green;
                image.at<cv::Vec3b>(i, j)[2] = Data24[temp].Red;
                temp++;
            }
        cv::imshow("lena", image);
        cv::waitKey(0);
    }
    else
    {
        cout << "Sorry Format Not Supported" << endl;
    }
    return;
}

int main()
{
    BITMAP bmp;
    if (bmp.LoadImage("./DIP/lena.bmp") == true)
    {
        bmp.ShowBMPCV();
    }
    bmp.SaveTIFFImage("./DIP/lena_converted.tif");
    return 0;
}