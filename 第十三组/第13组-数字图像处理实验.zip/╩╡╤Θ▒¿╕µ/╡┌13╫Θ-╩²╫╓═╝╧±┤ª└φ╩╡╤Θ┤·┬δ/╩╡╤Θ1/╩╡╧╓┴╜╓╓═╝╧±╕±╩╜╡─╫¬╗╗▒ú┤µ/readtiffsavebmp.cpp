/*
运行环境：Win10x64  Mingw-w64-8.1.0  OpenCV-MinGW-Build-4.1.1-x64  c11  c++17
Based on readsavetiff.cpp
24bit uncompressed tif to 24bit bmp
*/
#include <iostream>
#include <opencv.hpp>
using std::cin;
using std::cout;
using std::endl;

typedef unsigned short WORD; //2byte
typedef unsigned long DWORD; //4byte
typedef long LONG;           //4byte
typedef unsigned char BYTE;  //1byte

#pragma pack(1) //让结构体按照1byte对齐，防止文件读取及保存出错

typedef struct
{                     //bitmap file header,BMP文件头，一共14byte
    WORD bfType;      //如果是BMP图像就是'BM'
    DWORD bfSize;     //以字节为单位的BMP文件大小
    WORD bfReserved1; //设置为0
    WORD bfReserved2; //设置为0
    DWORD bfOffBits;  //从文件头到图像数据的偏移量，如果为54byte则没有调色板
} BITMAPFILEHEADER;

typedef struct
{                         //bitmap info header,BMP位图信息段，一共40byte
    DWORD biSize;         //BITMAPINFOHEADER结构占用的字节数
    LONG biWidth;         //图像的宽度像素
    LONG biHeight;        //图像的高度像素
    WORD biPlanes;        //平面数，设置为1
    WORD biBitCount;      //一个像素占的比特数，1，4，8，16，24，32
    DWORD biCompression;  //图像压缩类型，0为不压缩
    DWORD biSizeImage;    //不压缩时设置为0
    LONG biXPelsPerMeter; //水平分辨率，像素/米
    LONG biYPelsPerMeter; //垂直分辨率
    DWORD biClrUsed;      //设为0的话，则说明使用所有调色板项
    DWORD biClrImportant; //说明对图象显示有重要影响的颜色索引的数目，如果是0，表示都重要
} BITMAPINFOHEADER;

typedef struct
{ //为了方便后续调用，将DE中对应数据存入ImageInfo中
    //WORD ImageWidthShort;//根据tiff定义，有的量可能是short，也可能是long，需要根据DE中的type判断
    LONG ImageWidthLong; //tag256，图像宽度
    //WORD ImageLengthShort;
    LONG ImageLengthLong;           //tag257，图像长度
    WORD BitsPerSample;             //tag258，每像素的占用的bit数，真彩色应该是8
    WORD Compression;               //tag259，压缩，无压缩为1
    WORD PhotometricInterpretation; //tag262，值为2，代表RGB
    //WORD StripOffsetsShort;
    LONG StripOffsetsLong; //tag273，像素数据位置的偏移量
    WORD SamplesPerPixel;  //tag277，一个像素的sample数量，这里值为3（应该是通道数）
    //WORD RowsPerStripShort;
    LONG RowsPerStripLong; //tag278，每一个strip所包含的像素数据的行数，ImageLength除以RowsPerStrip向上取整就是strip的数量
    //WORD StripByteCountsShort;
    LONG StripByteCountsLong; //tag279，strip的字节数
    long long XResolution;    //tag282，下面这三个对图像显示无影响，就不读取
    long long YResolution;    //tag283
    WORD ResolutionUnit;      //tag296
} ImageInfo;

typedef struct
{                   //文件头
    WORD ByteOrder; //MM or II ,为windows方便只支持II
    WORD N42;       //就是42
    DWORD Offset;   //从文件开头到第一个IFD的偏移量
} HEADER;

typedef struct
{                        //目录入口，存在IFD里面
    WORD Tag;            //DE的标签，说明目录里存储的信息是什么
    WORD FieldType;      //值的数据类型
    DWORD Count;         //值的数量
    DWORD ValueOrOffset; //如果数据类型乘以数量小于4byte，这个就是值。否则就是DE存储数据地址的偏移量
} DE;                    //IFD Entry

typedef struct
{                    //目录，一张图片就是一个目录
    WORD NumberOfDE; //IFD中DE的数量
    DE *pDE;         //DE数据类型的指针，根据DE的数量new一个数组
    DWORD Offset;    //指向下一个IFD的偏移量。如果没有下一个，就是0
} IFD;

typedef struct
{ //储存像素的结构
    BYTE Red;
    BYTE Green;
    BYTE Blue;
} PixData24;

class TIFF
{
private:
    BITMAPFILEHEADER BMFHData;
    BITMAPINFOHEADER BMIHData;
    ImageInfo imageinfo;
    HEADER header;
    IFD ifd;
    PixData24 *Data24; //储存像素数据的指针，使用时new一个数组
    bool flag=0;
public:
    bool LoadImage(const char *path);
    bool SaveBMPImage(const char *path);
    void ShowTIFFCV();
};

#pragma pack()

bool TIFF::LoadImage(const char *path)
{
    FILE *pFile;
    pFile = fopen(path, "rb");
    if (pFile == 0)
    {
        cout << "Open File Error" << endl;
        return false;
    }
    fread(&header, sizeof(HEADER), 1, pFile); //读入文件头
    if (header.ByteOrder != 0x4949 or header.N42 != 42)
    {
        cout << "Sorry Format Not Supported" << endl;
        return false;
    }
    fseek(pFile, header.Offset, SEEK_SET);             //将指针移动到第一个IFD处
    fread(&ifd.NumberOfDE, sizeof(WORD), 1, pFile);    //将DE数量读入，方便读DE
    ifd.pDE = new DE[ifd.NumberOfDE];                  //new DE个空间
    fread(ifd.pDE, sizeof(DE), ifd.NumberOfDE, pFile); //读入所有的DE
    fread(&ifd.Offset, sizeof(DWORD), 1, pFile);
    for (int i = 0; i < ifd.NumberOfDE; i++)
    { //遍历所有的DE，根据标签读取数据
        WORD tag = ifd.pDE[i].Tag;
        cout << "tag is " << tag << ", ";
        switch (tag)
        {
        case 0x0100: //tag256图像宽度
            cout << "Read Image Width" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            imageinfo.ImageWidthLong = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0101: //tag257图像长度
            cout << "Read Image Length" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            imageinfo.ImageLengthLong = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0102: //tag258每像素的占用的bit数，真彩色应该是8,8,8，为offset，需要到offset处进行读取(count*fieldtype>4)
            cout << "Read BitsPerSample" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            fseek(pFile, ifd.pDE[i].ValueOrOffset, SEEK_SET);
            fread(&imageinfo.BitsPerSample, sizeof(WORD), 1, pFile); //因三个数均为8，只读取一个数保存
            cout << imageinfo.BitsPerSample << endl;
            break;
        case 0x0103: //tag259压缩，无压缩为1
            cout << "Read Compression" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            imageinfo.Compression = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0106: //tag262,值为2，代表RGB
            cout << "Read PhotometricInterpretation" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            imageinfo.PhotometricInterpretation = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0111: //tag273像素数据位置偏移量，为offset，需要到offset处进行读取。rrggbbcount为3，rgbrgbcount为1
            cout << "Read StripOffset" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            //fseek(pFile, ifd.pDE[i].ValueOrOffset, SEEK_SET);
            //fread(&imageinfo.StripOffsetsLong, sizeof(LONG), 1, pFile);
            imageinfo.StripOffsetsLong = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0115: //tag277，一个像素的sample数量，这里值为3（应该是通道数）
            cout << "Read SamplesPerPixel" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            imageinfo.SamplesPerPixel = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0116: //tag278每一个strip包含的row数，我的图片只有一个strip
            cout << "Read RowsPerStrip" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            imageinfo.RowsPerStripLong = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x0117: //tag279，StripByteCounts
            cout << "Read StripByteCounts" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            imageinfo.StripByteCountsLong = ifd.pDE[i].ValueOrOffset;
            break;
        case 0x011C: //tag284,PlanarConfiguration，short，1是rgbrgb，2是rrrgggbbb
            cout << "Read PlanarConfiguration" << endl;
            cout << "FieldType is " << ifd.pDE[i].FieldType << endl;
            cout << "count is " << ifd.pDE[i].Count << endl;
            cout << "Offset is " << ifd.pDE[i].ValueOrOffset << endl;
            break;
        };
    }
    cout << endl;
    cout << "Number of DE is " << ifd.NumberOfDE << endl;
    cout << "Next ifd offset is " << ifd.Offset << endl;
    cout << "Image Length is " << imageinfo.ImageLengthLong << endl;
    cout << "Image Width is " << imageinfo.ImageWidthLong << endl;
    cout << "BitsPerSample is " << imageinfo.BitsPerSample << endl;
    cout << "Compression is " << imageinfo.Compression << endl;
    cout << "PhotometricInterpretation is " << imageinfo.PhotometricInterpretation << endl;
    cout << "StripOffset is " << imageinfo.StripOffsetsLong << endl;
    cout << "RowsPerStrip is " << imageinfo.RowsPerStripLong << endl;
    if (imageinfo.BitsPerSample != 8)
    {
        cout << "Sorry Format Not Supported" << endl;
        return false;
    }
    Data24 = new PixData24[imageinfo.ImageLengthLong * imageinfo.ImageWidthLong];
    fseek(pFile, imageinfo.StripOffsetsLong, SEEK_SET); //将指针定位到strip处
    int temp = 0;
    /*    for (int i = 0; i < imageinfo.ImageWidthLong; i++)  //以rrrgggbbb存储，三次循环来读入三个通道
    {
        for (int j = 0; j < imageinfo.ImageLengthLong; j++)
        {
            fread(&Data24[temp].Red, sizeof(BYTE), 1, pFile);
            temp++;
        }
    }
    temp = 0;
    for (int i = 0; i < imageinfo.ImageWidthLong; i++)
    {
        for (int j = 0; j < imageinfo.ImageLengthLong; j++)
        {
            fread(&Data24[temp].Green, sizeof(BYTE), 1, pFile);
            temp++;
        }
    }
    temp = 0;
    for (int i = 0; i < imageinfo.ImageWidthLong; i++)
    {
        for (int j = 0; j < imageinfo.ImageLengthLong; j++)
        {
            fread(&Data24[temp].Blue, sizeof(BYTE), 1, pFile);
            temp++;
        }
    }*/
    temp = 0;
    for (int i = 0; i < imageinfo.ImageWidthLong; i++)
    {
        for (int j = 0; j < imageinfo.ImageLengthLong; j++)
        {
            fread(&Data24[temp].Red, sizeof(BYTE), 1, pFile);
            fread(&Data24[temp].Green, sizeof(BYTE), 1, pFile);
            fread(&Data24[temp].Blue, sizeof(BYTE), 1, pFile);
            temp++;
        }
    }
    cout << "temp is " << temp << endl;
    flag=1;
    fclose(pFile);
    return true;
}

bool TIFF::SaveBMPImage(const char *path)
{
    if (flag == 0)//如果flag=0说明未成功读取图片
    {
        cout << "Please Load An Image First" << endl;
        return false;
    }
    FILE *pFile = fopen(path, "wb");
    if (!pFile)
    {
        cout << "Open File Error" << endl;
        return false;
    }
    BMIHData.biClrUsed = 0;
    BMIHData.biClrImportant = 0;
    BMIHData.biBitCount = 24;
    BMIHData.biCompression=0;
    BMIHData.biPlanes=1;
    BMIHData.biSizeImage=0;
    BMIHData.biHeight=imageinfo.ImageWidthLong;
    BMIHData.biWidth=imageinfo.ImageLengthLong;
    BMIHData.biSize=40;
    BMIHData.biXPelsPerMeter=96;
    BMIHData.biYPelsPerMeter=96;
    BMFHData.bfType = 0x4D42;
    BMFHData.bfReserved1=0;
    BMFHData.bfReserved2=0;
    int channels = 3;
    int offset = (BMIHData.biWidth * channels) % 4;
    if (offset > 0)
    {
        offset = 4 - offset;
    }
    BMFHData.bfSize=sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+BMIHData.biHeight*BMIHData.biWidth*3+offset*BMIHData.biHeight;
    fwrite(&BMFHData, sizeof(BMFHData), 1, pFile);
    fwrite(&BMIHData, sizeof(BMIHData), 1, pFile);
    int temp = 0;
    const int padding = 0; //将偏移量部分填充为0
    for (int i = BMIHData.biHeight-1; i >=0 ; i--)//注意bmp与tiff像素顺序不同
    {
        temp=i*BMIHData.biWidth;
        for (int j = 0; j < BMIHData.biWidth; j++)
        {
            fwrite(&Data24[temp].Blue, sizeof(BYTE), 1, pFile);
            fwrite(&Data24[temp].Green, sizeof(BYTE), 1, pFile);
            fwrite(&Data24[temp].Red, sizeof(BYTE), 1, pFile);
            temp++;
        }
        fwrite(&padding, 1, offset, pFile); //填充偏移量
    }
    fclose(pFile);
    return true;
    cout << "Save Failed" << endl;
    return false;
}

void TIFF::ShowTIFFCV()
{
    cv::Mat image(imageinfo.ImageLengthLong, imageinfo.ImageWidthLong, CV_8UC3);
    int temp = 0;
    for (int i = 0; i < imageinfo.ImageWidthLong; i++) //tiff与opencv的原点均在左上角，x为row，y为column
        for (int j = 0; j < imageinfo.ImageLengthLong; j++)
        {
            image.at<cv::Vec3b>(i, j)[0] = Data24[temp].Blue;
            image.at<cv::Vec3b>(i, j)[1] = Data24[temp].Green;
            image.at<cv::Vec3b>(i, j)[2] = Data24[temp].Red;
            temp++;
        }
    cv::imshow("lena", image);
    cv::waitKey(0);
    return;
}

int main()
{
    TIFF tif;
    if (tif.LoadImage("./DIP/lena1.tif"))
    {
        tif.ShowTIFFCV();
        tif.SaveBMPImage("./DIP/lena1_converted.bmp");
    }
    return 0;
}