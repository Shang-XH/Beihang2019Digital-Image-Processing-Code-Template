clc,
clear all,
close all;
img=imread('origin.jpg');
I_out=HoughLineDetect(img,150);