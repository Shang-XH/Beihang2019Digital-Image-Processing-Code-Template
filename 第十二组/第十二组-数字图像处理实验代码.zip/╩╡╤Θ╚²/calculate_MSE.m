%���������MSE
function mse=calculate_MSE(img,newimg)
    f1=double(img);
    f2=double(newimg);
    [row,col]=size(f1);%ͼ�񳤿�
    sse=0;
    mse=0;
    for i=1:row
        for j=1:col
            sse=sse+(f1(i,j)-f2(i,j))^2;
        end
    end
    mse=sse/(row*col);
end