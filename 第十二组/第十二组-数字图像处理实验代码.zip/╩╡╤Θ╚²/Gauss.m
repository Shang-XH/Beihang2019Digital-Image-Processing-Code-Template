%��˹�˲�
function newimg = Gauss(f,sigma,SIZE)
    Gauss_Temp=zeros(SIZE);
    %weight=2*pi*sigma*sigma;
    sum=0;
    for i=1:SIZE
        for j=1:SIZE
            Gauss_Temp(i,j)=exp(-((i-SIZE/2)*(i-SIZE/2)+(j-SIZE/2)*(j-SIZE/2))/(2.0*sigma*sigma));
            sum=sum+Gauss_Temp(i,j);
        end
    end
    for i=1:SIZE
        for j=1:SIZE
            Gauss_Temp(i,j)=Gauss_Temp(i,j)/sum;
        end
    end
   newimg=uint8(conv2(f,Gauss_Temp,'same'));
end
            
