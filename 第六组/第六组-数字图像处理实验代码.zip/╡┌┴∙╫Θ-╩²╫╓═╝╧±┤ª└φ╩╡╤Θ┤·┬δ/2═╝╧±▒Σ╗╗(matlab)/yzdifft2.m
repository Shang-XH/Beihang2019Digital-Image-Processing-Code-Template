function f = yzdifft2(A)
    %ifft���任ֻ��Ҫ�����任��w���ӸĶ���Ȼ�����ճ���M*N���ɣ�ע��ͬ��yzdfft2
    [M,N]=size(A);
    A=double(A);
    Wm2=exp(1j*2*pi/M);
    Wn2=exp(1j*2*pi/N);
    
    butterx=log2(M);
    buttery=log2(N);
    if rem(butterx,1)~=0
        butterx=fix(butterx)+1;
    end
    if rem(buttery,1)~=0
        buttery=fix(buttery)+1;
    end
    
    extrax=2^butterx-M;
    extray=2^buttery-N;
    if extrax~=0
        r1=zeros(extrax,N);
        A=[A;r1];
    end
    if extray~=0
        r1=zeros(extrax+M,extray);
        A=[A r1];
    end
    M=M+extrax;
    N=N+extray;
    
    for x=1:M
        per_x=A(x,:);
        butter=buttery;
        half=round(N/2);
        half2=half;
        n=N-2;
        for m=1:n
            if m<half2
                t=per_x(m+1);
                per_x(m+1)=per_x(half2+1);
                per_x(half2+1)=t;
            end
            k=half;
            while(half2>=k)
                half2=half2-k;
                k=round(k/2);
            end
            half2=half2+k;
        end
        for butter_num=1:butter
            butter_size=2^(butter_num-1);
            for t=0:butter_size-1
                w=t*(2^(butter-butter_num));
                for k=t:2^butter_num:N-1
                    xnext=per_x(k+1)+per_x(k+1+butter_size)*Wn2^w;
                    xnext2=per_x(k+1)-per_x(k+1+butter_size)*Wn2^w;
                    per_x(k+1)=xnext;
                    per_x(k+1+butter_size)=xnext2;
                end
            end
        end
        A(x,:)=per_x;
    end

    for y=1:N
        src_img_y=A(:,y);
        butter=butterx;
        half=round(M/2);
        half2=half;
        n=M-2;
        for m=1:n
            if m<half2
                t=src_img_y(m+1);
                src_img_y(m+1)=src_img_y(half2+1);
                src_img_y(half2+1)=t;
            end
            k=half;
            while(half2>=k)
                half2=half2-k;
                k=round(k/2);
            end
            half2=half2+k;
        end
        for butter_num=1:butter
            butter_size=2^(butter_num-1);
            for t=0:butter_size-1
                w=t*(2^(butter-butter_num));
                for k=t:2^butter_num:N-1
                    xnext=src_img_y(k+1)+src_img_y(k+1+butter_size)*Wm2^w;
                    xnext2=src_img_y(k+1)-src_img_y(k+1+butter_size)*Wm2^w;
                    src_img_y(k+1)=xnext;
                    src_img_y(k+1+butter_size)=xnext2;
                end
            end
        end
        A(:,y)=src_img_y;
    end
    f=A/N;
    f=f/M;
end