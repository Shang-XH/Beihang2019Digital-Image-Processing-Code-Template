function img = move(A,num)
    %�˺�������ƽ��ͼƬ
    [M,N]=size(A);
    img=A;
    for x=1:M%�ȶ�y��ƽ��
        for y=1:N
            if y>num
               img(x,y)=A(x,y-num);
            else
                img(x,y)=A(x,N-num+y);
            end
        end
    end
    A=img;
    for x=1:M%�ٶ�x��ƽ��
        for y=1:N
            if x>num
               img(x,y)=A(x-num,y);
            else
                img(x,y)=A(N-num+x,y);
            end
        end
    end
end

