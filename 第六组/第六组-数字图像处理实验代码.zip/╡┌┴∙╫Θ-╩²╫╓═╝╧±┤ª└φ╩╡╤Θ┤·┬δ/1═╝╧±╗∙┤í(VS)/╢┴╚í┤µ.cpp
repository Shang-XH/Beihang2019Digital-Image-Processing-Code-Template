﻿// 数字图像实验.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#include <iostream>
#include<Windows.h>
#include<math.h>
#include<fstream>
#include<sstream>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<opencv2/opencv.hpp>
using namespace std;
using namespace cv;

void yzdbmp(char* filename) {
	FILE* fp;
	fopen_s(&fp, filename, "rb+");//读入图片
	if (fp == 0) return;
	BITMAPFILEHEADER head1;
	fread(&head1, 14, 1, fp);//读bmp图片的文件头

	BITMAPINFOHEADER head2;
	fread(&head2, 40, 1, fp);//读bmp图片的信息头
	printf_s("%d\n", head2.biWidth);
	printf_s("%d\n", head2.biHeight);//显示行列数，以便matlab建立矩阵显示图片
	int digit = (int)pow(2, head2.biBitCount);
	int datasize = (head2.biBitCount * head2.biWidth + 31) / 8;
	datasize = datasize / 4 * 4*head2.biHeight;//计算图片像素字节数
	printf_s("%d\n", datasize);
	int x = head2.biBitCount;//读每个像素需要的位数
	BYTE* bmpbuff = new BYTE[datasize];
	RGBQUAD* color = new RGBQUAD[digit];
	if (x != 24) {
		fread(color, 4, digit, fp);//判断是否用到了调色板
	}
	fread(bmpbuff, 1, datasize, fp);//读像素数据
	fseek(fp, -datasize, 1);//偏移指针，再将像素信息读入，用来改变进制
	unsigned char* b = new unsigned char[datasize];
	fread(b, 1, datasize, fp);
	fclose(fp);
	
	ofstream os;
	os.open("位图字符.txt");
	for (int i = 0; i < datasize; i++) {
		string str = to_string((int)b[i]);
		if (i % 3 == 0 && i != 0) os << "\n";
		os << str + " ";//将二进制像素信息转换为字符，以便matlab阅读建立矩阵
	}
	os.close();

	FILE* information;
	fopen_s(&information, "bmp信息.txt", "wb");
	if (information == 0) return;
	fwrite(&head1, 14, 1, information);
	fwrite(&head2, 40, 1, information);
	if (x != 24) fwrite(color, 3, digit,information);
	fwrite(bmpbuff, 1, datasize,information);//将图片的所有数据写成二进制文本

	FILE* information2;
	fopen_s(&information2, "bmp的rgb像素信息.txt", "wb");
	if (information2 == 0) return;
	if (x != 24) fwrite(color, 3, digit, information2);
	fwrite(bmpbuff, 1, datasize, information2);//将图片的像素信息写成二进制文本

	FILE* newbmp;
	fopen_s(&newbmp, "新bmp图.bmp", "wb");
	if (newbmp == 0) return;
	fwrite(&head1, 14, 1, newbmp);
	fwrite(&head2, 40, 1, newbmp);
	if(x!=24) fwrite(color, 3, digit, newbmp);
	fwrite(bmpbuff, 1,datasize, newbmp);//将图片另存为一张bmp图片
}

void yzdpng(char *filename) {
	FILE* fp;
	fopen_s(&fp, filename, "rb");//以二进制读取png图片
	if (fp == 0) return;
	fseek(fp, 0, SEEK_END);//偏移指针到末尾
	long size = ftell(fp);//计算png图片字节大小
	printf_s("%d\n", size);
	fseek(fp, 0, SEEK_SET);//偏移到头
	BYTE* data = new BYTE[size];
	fread(data, 1, size, fp);//读入文件信息

	BYTE chunk[4];
	fseek(fp, 33, SEEK_SET);//偏移指针到IDAT的chunk
	fread(chunk, 1, 4, fp);//读入文件信息
	int length = (int)(chunk[0]*pow(16,6)+ chunk[1] * pow(16, 4)+ chunk[2] * pow(16, 2)+ chunk[3]);
	printf_s("%d\n", length);
	fseek(fp, 4, SEEK_CUR);//偏移指针到IDAT的chunk
	unsigned char* datapng = new unsigned char[length];
	fread(datapng, 1, length, fp);

	FILE* information2;
	fopen_s(&information2, "png像素信息.txt", "wb");
	if (information2 == 0) return;
	fwrite(datapng, 1, length, information2);//将png像素信息转换成二进制文本
	
	FILE* newpng;
	fopen_s(&newpng, "新png图.png", "wb");
	if (newpng == 0) return;
	fwrite(data, 1, size, newpng);//以所有信息另存一张新的png图片

	FILE* information;
	fopen_s(&information, "png信息.txt", "wb");
	if (information == 0) return;
	fwrite(data, 1, size, information);//将png所有信息转换成二进制文本

	fclose(fp);
}

int main()
{
	char filename[] = "psbbmp.bmp";
	char filename2[] = "psbpng.png";
	yzdbmp(filename);
	yzdpng(filename2);
	Mat a = imread("psbbmp.bmp");
	Mat b = imread("psbpng.png");
	imshow("bmp图", a);
	imshow("png图", b);
	waitKey(3000);

	return 0;
}




