﻿// 转码.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
#include<Windows.h>
#include <iostream>
#include"jconfig.h"
#include"jmorecfg.h"
#include"jpeglib.h"
#include<opencv2/opencv.hpp>
extern "C" {
	#include<jconfig.h>
	#include<jmorecfg.h>
	#include<jpeglib.h>
	#include<setjmp.h>
}
using namespace std;
using namespace cv;


void BmpToJpg(char* BmpName, char* JpgName, int QUALITY_FACTOR)

{
	FILE* fbmp;//bmp文件的指针
	FILE* fjpg;//目标jpeg文件的指针
	fopen_s(&fbmp, BmpName, "rb");
	if (fbmp == 0) return;
	
	BITMAPFILEHEADER header;//bmp文件头
	fread(&header, sizeof(unsigned char), sizeof(header), fbmp);//读取头文件

	BITMAPINFOHEADER infoheader;//bmp信息头
	fread(&infoheader, sizeof(unsigned char), sizeof(infoheader), fbmp);//读取位图信息头文件
	
	struct jpeg_compress_struct cinfo;//申请并初始化jpeg压缩对象
	struct jpeg_error_mgr jerr;
	JSAMPROW row_pointer[1];// 一行位图
	cinfo.err = jpeg_std_error(&jerr);

	LONG ImageWidth = infoheader.biWidth;
	LONG ImageHeight = infoheader.biHeight;//4字节LONG文件,记录图像宽高

	WORD BitCount = infoheader.biBitCount;//颜色位数，此代码处理的是24位，没有调色板
	WORD BytesPerPixel =BitCount / 8;//表示一个像素需要的字节数

	int PerLineByteCount = (ImageWidth * BitCount + 31) / 8;
	PerLineByteCount = PerLineByteCount /4 * 4;//调整每行的字节数为4的整数倍
	int ImageDataSize = PerLineByteCount * ImageHeight;//图像总的字节数

	unsigned char *PerLineData = new unsigned char[PerLineByteCount];//存储每行图像数据
	unsigned char *ImageData = new unsigned char[ImageDataSize];//存储所有图像数据
	cout << PerLineByteCount<<endl;
	for (int i = 1; i <=ImageHeight; i++){
		fread(PerLineData, sizeof(unsigned char), PerLineByteCount, fbmp);//从图像最下面一行开始读
		for (int j = 0; j < ImageWidth; j++){
				ImageData[(ImageHeight - i) * PerLineByteCount + j * 3 + 0] = PerLineData[j * 3 + 2];
				ImageData[(ImageHeight - i) * PerLineByteCount + j * 3 + 1] = PerLineData[j * 3 + 1];
				ImageData[(ImageHeight - i) * PerLineByteCount + j * 3 + 2] = PerLineData[j * 3 + 0];//由于Bmp读取是最下面一排先读，故需要倒置，且读取顺序是BGR，改为RGB
		}
	}
	
	fopen_s(&fjpg,JpgName, "wb");
	if (fjpg == 0) return;
	
	jpeg_create_compress(&cinfo);// 初始化jpeg压缩对象
	jpeg_stdio_dest(&cinfo, fjpg);  //指定压缩后的图像所存放的目标文件 ，二进制打开
	cinfo.image_width = ImageWidth; 
	cinfo.image_height = ImageHeight;//压缩后图像的宽和高
	cinfo.input_components = 3;// 彩色图为3 
	cinfo.in_color_space = JCS_RGB;//JCS_GRAYSCALE表示灰度图，JCS_RGB表示彩色图像 
	jpeg_set_defaults(&cinfo);   // jpeglib库采用默认的设置对图像进行压缩 
	jpeg_set_quality(&cinfo, QUALITY_FACTOR, TRUE); // 压缩比由QUALITY_FACTOR决定，手动输入
	jpeg_start_compress(&cinfo, TRUE);
	for (int i = 0; i < cinfo.image_height;i++) {
		for (int j = 0; j < PerLineByteCount; j++){
			PerLineData[j] = ImageData[i* PerLineByteCount + j];
		}
		row_pointer[0] = PerLineData;
		jpeg_write_scanlines(&cinfo, row_pointer, 1);//写一行数据进去新的jpg
	}
	jpeg_finish_compress(&cinfo);
	fclose(fjpg);
	fclose(fbmp);
	return  ;//返回存储RGB的数据的指针
}

void JpgToBmp(char* JpgName, char* BmpName, int QUALITY_FACTOR) {//本代码处理的均是24位真彩色图，不存在调色板
	FILE* fbmp;//bmp文件的指针
	FILE* fjpg;//目标jpeg文件的指针
	fopen_s(&fjpg, JpgName, "rb");//打开jpg文件
	if (fjpg == 0) return;
	
	BITMAPFILEHEADER header;//bmp文件头
	memset(&header, 0, sizeof(header));//初始化全为0
	BITMAPINFOHEADER infoheader;//bmp信息头
	memset(&infoheader, 0, sizeof(infoheader));//初始化全为0
	header.bfType = 0x4D42;
	header.bfOffBits = 54;//文件固定字节大小的部分

	infoheader.biSize = sizeof(infoheader);
	infoheader.biBitCount = 24;
	infoheader.biPlanes = 1;//信息头固定字节大小的部分

	struct jpeg_decompress_struct cinfo;//申请并初始化jpeg压缩对象
	struct jpeg_error_mgr jerr;
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_decompress(&cinfo);
	jpeg_stdio_src(&cinfo, fjpg);//指定要解压的文件
	jpeg_read_header(&cinfo, TRUE);//读取信息
	jpeg_start_decompress(&cinfo);
	
	infoheader.biWidth = cinfo.output_width;
	infoheader.biHeight = cinfo.output_height;//确定输出Bmp的高和宽
	printf_s("%d\n", cinfo.output_width);
	printf_s("%d\n", cinfo.output_height);

	int PerLineByteCount = cinfo.output_components * cinfo.output_width;//图像每一行的字节数
	int x = PerLineByteCount + 3;
	x = x / 4 * 4;//调整每一行的字节数为4的整数倍，这是实际Bmp文件每一行字节数
	int ImageDataSize = x * cinfo.output_height;//图像总的字节数
	unsigned char* ImageData = new unsigned char[ImageDataSize];//申请空间，储存每一行数据
	memset(ImageData, 0, ImageDataSize);//初始化
	unsigned char* PerLineData = new unsigned char[x];//储存所有数据
	memset(PerLineData, 0, x);//初始化
	printf_s("%d\n", x);
	printf_s("%d\n", ImageDataSize);
	for (int i = 1; i <= cinfo.output_height; i++) {
		jpeg_read_scanlines(&cinfo, &PerLineData, 1);//从图像最下面一行开始读
		for (int j = 0; j <= cinfo.output_width; j++) {
			if (j == cinfo.output_width) {
				for (int temp = 0; temp < x - 3 * j; temp++)//给为了凑4的整数倍而增添的字节赋值，均为0，不需要更改读取顺序
					ImageData[(cinfo.image_height - i) * x + j * 3 + temp] = PerLineData[j * 3 + temp];
			}
			else {
				ImageData[(cinfo.image_height - i) * x + j * 3 + 0] = PerLineData[j * 3 + 2];
				ImageData[(cinfo.image_height - i) * x + j * 3 + 1] = PerLineData[j * 3 + 1];
				ImageData[(cinfo.image_height - i) * x + j * 3 + 2] = PerLineData[j * 3 + 0];
			}//由于Bmp是最下面一排先开始，故读取jpg后需要倒置，且读取顺序是RGB，改为BGR
		}
	}
	header.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + ImageDataSize;//文件大小，至此24位bmp信息已经完善
	
	fopen_s(&fbmp, BmpName, "wb");
	if (fbmp == 0) return;
	fwrite(&header, sizeof(header), 1, fbmp);
	fwrite(&infoheader, sizeof(infoheader),1 , fbmp);
	fwrite(ImageData, 1, ImageDataSize, fbmp);//存bmp文件
	
	jpeg_finish_decompress(&cinfo);//完成解压过程
	jpeg_destroy_decompress(&cinfo);//释放cinfo

	fclose(fbmp);
	fclose(fjpg);
	return;
}

int main() {
	char filename[] = "psbbmp.bmp";
	char filename2[] = "bmp2jpg.jpg";
	BmpToJpg(filename, filename2, 90);
	char filename3[] = "psbjpg.jpg";
	char filename4[] = "jpg2bmp.bmp";
	JpgToBmp(filename3, filename4, 90);
	return 0;//https://blog.csdn.net/u012372584/article/details/50618739
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
