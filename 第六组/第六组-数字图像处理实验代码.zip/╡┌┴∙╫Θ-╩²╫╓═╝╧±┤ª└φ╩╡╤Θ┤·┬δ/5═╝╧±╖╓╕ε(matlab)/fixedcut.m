function B= fixedcut(A,value)
    %�˺������ڹ̶���ֵ�ָ�
    [M,N]=size(A);
    B=zeros(M,N);
    for i=1:M
        for j=1:N
            if A(i,j) > value
                B(i,j)=255;
            else
                B(i,j)=0;
            end
        end
    end
end

