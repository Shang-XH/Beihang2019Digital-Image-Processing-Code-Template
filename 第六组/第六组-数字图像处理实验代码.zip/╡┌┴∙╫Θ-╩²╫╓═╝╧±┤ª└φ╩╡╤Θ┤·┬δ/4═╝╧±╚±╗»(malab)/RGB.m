function [R,G,B] = RGB(H,S,I)
    %�˺�������hsi2rgb
    [M,N]=size(H);
    R=H;
    G=H;
    B=H;
    for x=1:M
        for y=1:N
            h=H(x,y);
            s=S(x,y);
            i=I(x,y);
            if 0<=h && h<120%��ʽ�����пɻ�ȡ
                B(x,y)=i*(1-s);
                R(x,y)=i*(1+s*cosd(h)/cosd(60-h));
                G(x,y)=3*i-R(x,y)-B(x,y);
            elseif 120<=h && h<240
                h=h-120;
                R(x,y)=i*(1-s);
                G(x,y)=i*(1+s*cosd(h)/cosd(60-h));
                B(x,y)=3*i-R(x,y)-G(x,y);
            else
                h=h-240;
                G(x,y)=i*(1-s);
                B(x,y)=i*(1+s*cosd(h)/cosd(60-h));
                R(x,y)=3*i-B(x,y)-G(x,y);
            end
        end
    end
end

