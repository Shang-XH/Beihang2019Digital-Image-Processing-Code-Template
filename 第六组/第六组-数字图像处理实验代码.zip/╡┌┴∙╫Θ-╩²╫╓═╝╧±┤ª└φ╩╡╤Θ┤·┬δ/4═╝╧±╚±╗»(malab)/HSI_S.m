function S = HSI_S(R,G,B)
    %�˺������㱥�Ͷ�
    [M,N]=size(R);
    S=R;
    for x=1:M
        for y=1:N
            r=R(x,y);
            g=G(x,y);
            b=B(x,y);
            S(x,y)=1-3*min([r,g,b])/(r+g+b);
        end
    end
end

