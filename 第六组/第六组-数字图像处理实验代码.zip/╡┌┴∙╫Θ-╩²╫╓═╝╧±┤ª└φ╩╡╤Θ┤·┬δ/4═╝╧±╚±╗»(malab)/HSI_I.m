function I = HSI_I(R,G,B)
    %�˺�������ǿ��
    [M,N]=size(R);
    I=R;
    for x=1:M
        for y=1:N
            r=R(x,y);
            g=G(x,y);
            b=B(x,y);
            I(x,y)=(r+g+b)/3;
        end
    end
end

