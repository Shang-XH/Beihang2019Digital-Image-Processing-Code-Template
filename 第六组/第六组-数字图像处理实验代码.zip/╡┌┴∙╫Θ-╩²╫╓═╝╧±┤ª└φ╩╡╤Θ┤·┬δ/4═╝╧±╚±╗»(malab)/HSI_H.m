function H = HSI_H(R,G,B)
    %�δ˺������ڼ���ɫ��
    [M,N]=size(R);
    H=R;
    for x=1:M
        for y=1:N
            r=R(x,y);
            g=G(x,y);
            b=B(x,y);
            value=(2*r-g-b)/sqrt((r-g)^2+(r-b)*(g-b))/2;
            theta=acos(value);
            theta=theta*180/pi;
            if b<=g
                H(x,y)=theta;
            else
                H(x,y)=360-theta;
            end
        end
    end
end

