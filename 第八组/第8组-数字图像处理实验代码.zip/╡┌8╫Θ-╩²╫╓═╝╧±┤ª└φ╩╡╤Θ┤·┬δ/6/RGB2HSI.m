function out = RGB2HSI( in )
    in = double(in);
    in = in/255;
    % ����ͼƬ��RGBͨ��
    R = in(:,:,1);
    G = in(:,:,2);
    B = in(:,:,3);
    % ת��ΪHSI
    sum_RGB = R+G+B;
    S = 1.*(1-(3*min(min(R,G),B))./(sum_RGB+eps));   
    H = acos((0.5*(R-G+R-B))./sqrt((R-G).*(R-G)+(R-B).*(G-B)+eps));
    H(B>G) = 2*pi-H(B>G);
    H = H/(2*pi);
    H(S==0) = 0;
    I = 1.*sum_RGB/3;
    % ������ͼ
    out = cat(3,H,S,I);
