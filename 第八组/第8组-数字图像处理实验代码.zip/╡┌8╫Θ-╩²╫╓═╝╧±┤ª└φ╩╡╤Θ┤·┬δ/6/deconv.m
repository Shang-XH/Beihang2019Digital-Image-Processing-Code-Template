function I_new = deconv(I, H, thresh)

if size(I, 3) == 3,
    I = rgb2gray(I);
end
I = im2double(I);
G = fftshift(fft2(I));
[M, N] = size(G);
F = G;
[x, y] = meshgrid(1:N, 1:M);
if thresh > M/2,
    F = G./(H+eps);
else
    idx = (x-N/2).^2 + (y-M/2).^2 < thresh^2;
    F(idx) = G(idx)./(H(idx)+eps);
end
I_new = ifft2(ifftshift(F));
I_new = uint8(abs(I_new)*255);