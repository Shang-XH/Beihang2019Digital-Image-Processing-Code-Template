﻿#include <iostream>  
#include <string.h>
#include <opencv2/core/core.hpp>  
#include <opencv2/highgui/highgui.hpp>  
#include <opencv2/core/mat.hpp>
#include<opencv2/opencv.hpp>
#define PI 3.1415926
using namespace cv;
using namespace std;

//将mat类型转换为二维数组的类型
void DCT(Mat& A, Mat& B, int M, int N){
	int p, q;
	int m, n;
	double ap, aq;
	double num;
	double max;
	int i, j;
	for (p = 0; p < M; p++){
		cout << p << endl;
		for (q = 0; q < N; q++){
			if (p == 0){
				ap = sqrt(1.0 / M);
			}
			else{
				ap = sqrt(2.0 / M);
			}
			if (q == 0){
				aq = sqrt(1.0 / N);
			}
			else{
				aq = sqrt(2.0 / N);
			}
			double tmp = 0.0;
			for (m = 0; m < M; m++){
				for (n = 0; n < N; n++){
					tmp += A.at<double>(m, n) * cos((2 * m + 1) * p * PI / (2.0 * M)) * cos((2 * n + 1) * q * PI / (2.0 * N));//每个像素对应的tmp值即累加式计算完毕
				}
			}
			B.at<double>(p, q) = ap * aq * tmp;
			//cout << "p:" << p << " q:" << q << "  p*N+q:" << p * N + q << " tmp:" << tmp << " mutiply:" << ap * aq * tmp << "  B.data:" << B.at<double>(p, q) << "\n";
		}
	}
}

void IDCT(Mat& B, Mat& C, int M, int N){
	int p = 0, q = 0, m = 0, n = 0;
	double ap = 0.0, aq = 0.0;
	for (m = 0; m < M; m++){
		cout << m << endl;
		for (n = 0; n < N; n++){
			double tmp1 = 0.0;
			for (p = 0; p < M; p++){
				for (q = 0; q < N; q++){
					if (p == 0){
						ap = 1.0 / sqrt(M);
					}
					else{
						ap = sqrt(2.0 / M);
					}
					if (q == 0){
						aq = 1.0 / sqrt(N);
					}
					else{
						aq = sqrt(2.0 / N);
					}
					tmp1 += ap * aq * B.at<double>(p, q) * cos(PI * (2 * m + 1) * p / (2 * M)) * cos(PI * (2 * n + 1) * q / (2 * N));
				}
			}
			C.data[m * N + n] = uchar(tmp1);
			//cout << "m:" << p << " n:" << q << "  m*N+n:" << m * N + n << " tmp1:" << tmp1 << "  C.data:" << C.data[m * N + n] << "\n";
		}
	}
}

Mat angleRectify(Mat img, float angle){//旋转角度
	Mat retMat = Mat::zeros(550, 850, CV_8UC3);
	float anglePI = (float)(angle * CV_PI / 180);
	int x, y, w, h;
	for (int i = 0; i < retMat.rows; i++) {
		for (int j = 0; j < retMat.cols; j++) {
			x = (int)((i - retMat.rows / 2) * cos(anglePI) - (j - retMat.cols / 2) * sin(anglePI) + 0.5);
			y = (int)((i - retMat.rows / 2) * sin(anglePI) + (j - retMat.cols / 2) * cos(anglePI) + 0.5);
			x += img.rows / 2;
			y += img.cols / 2;
			if (x >= img.rows || y >= img.cols || x <= 0 || y <= 0) {
				retMat.at<Vec3b>(i, j) = Vec3b(0, 0);
			}
			else {
				retMat.at<Vec3b>(i, j) = img.at<Vec3b>(x, y);
			}
		}
	}
	//从中心裁剪
	w = (retMat.rows - img.rows) / 2;
	h = (retMat.cols - img.cols) / 2;
	//cout << w << " " << h << endl;
	Rect rect(h, w, img.cols, img.rows);
	retMat = retMat(rect);
	return retMat;
}

int main()
{
	Mat img = imread("E:\\y.png");//读取图像img。0表示转换为灰度图像读入
	Mat dst;
	dst = angleRectify(img, 45);
	//imshow("dst", dst);
	
	cout << "DCT Start" << endl;
	int rows = img.rows;
	int cols = img.cols;
	//imshow("原图", img);
	//waitKey(0);

	//灰度变换
	Mat grayimage;
	cvtColor(img, grayimage, CV_BGR2GRAY);
	//浮点变换
	Mat fgrayimage(img.rows, img.cols, CV_64FC1);
	grayimage.convertTo(fgrayimage, CV_64FC1);
	//c++ dct函数实现
	Mat B(rows, cols, CV_64FC1);
	DCT(fgrayimage, B, rows, cols);
	//imshow("dct后图像", B);
	//waitKey(0);
	
	//旋转性质
	//灰度变换
	Mat graydst;
	cvtColor(dst, graydst, CV_BGR2GRAY);
	//浮点变换
	Mat fdst(dst.rows, dst.cols, CV_64FC1);
	graydst.convertTo(fdst, CV_64FC1);
	//c++ dct函数实现
	Mat D(dst.rows, dst.cols, CV_64FC1);
	DCT(fdst, D, dst.rows, dst.cols);
	
	//idct实现
	cout << "IDCT Start" << endl;
	//Mat C(rows, cols, CV_64FC1);
	Mat C(rows, cols, CV_8UC1);;
	IDCT(B, C, rows, cols);
	imshow("原图(灰度)", grayimage);
	imshow("旋转图像", dst);
	imshow("dct后图像", B);
	imshow("idct后图像", C);
	imshow("dct旋转", D);
	
	imwrite("原图(灰度).jpg", grayimage);
	imwrite("旋转图像.jpg", dst);
	imwrite("dct后图像.jpg", B);
	imwrite("idct后图像.jpg", C);
	imwrite("dct旋转.jpg", D);

	waitKey(0);
	return 0;
}