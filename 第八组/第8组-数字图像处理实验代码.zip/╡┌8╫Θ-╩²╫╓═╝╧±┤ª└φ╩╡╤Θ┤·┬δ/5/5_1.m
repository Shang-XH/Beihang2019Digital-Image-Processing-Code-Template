>> I=imread('cat.jpg');
>> gray=rgb2gray(I);%将图像变为灰度图
>> imshow(gray);%显示灰度图一
imhist(gray);%显示图像的直方图
>> newI=im2bw(gray,130/255);%
>> imshow(newI);