%Robert算子：

>> I=imread('edge.jpg');
gray=rgb2gray(I);
Hro=[1 0 ;0 -1];%卷积核1
>> Ir1=imfilter(gray,Hro);
>> imshow(Ir1);%图五
>> Hro2=[0 1; -1 0];%卷积核2
>> Ir2=imfilter(gray,Hro2);
>> imshow(Ir2)%图六
>> Iba=(Ir1+Ir2)/2;
>> imshow(Iba)%平均后的图七

%Prewitt算子

>> Hprw=[-1 0 1; -1 0 1; -1 0 1];%卷积核1
>> imfilter(gray,Hprw);
>> Ip1=imfilter(gray,Hprw);
>> imshow(Ip1);%图五
>> Hprw2=[1 1 1 ;0 0 0 ;-1 -1 -1];卷积核2
>> Ip2=imfilter(gray,Hprw2);
>> imshow(Ip2);%图六
