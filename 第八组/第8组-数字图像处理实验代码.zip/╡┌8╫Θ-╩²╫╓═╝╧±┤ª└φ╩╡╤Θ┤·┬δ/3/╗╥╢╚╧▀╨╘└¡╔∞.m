clc;
clear;
close all;

% �ԻҶ�ͼ���лҶ����Ա任
ori_img = imread('D:/gongqijun.jpg');
ori_img1 = rgb2gray(ori_img);
[oriHist,oriX] = imhist(ori_img1);

pt0 = [0,0];
pt1 = [100,50];
pt2 = [150,160];
pt3 = [255,200];

[width,height] = size( ori_img1);
gray1 = ori_img1;
for i=1:1:width
    for j = 1:1:height
        if (gray1(i,j)<pt1(1))
            gray1(i,j) = pt0(2) + (gray1(i,j)-pt0(1)) * ((pt1(2)-pt0(2))/(pt1(1)-pt0(1)));
        else if(gray1(i,j)>=pt1(1)&&gray1(i,j)<pt2(1))
                gray1(i,j) = pt1(2) + (gray1(i,j)-pt1(1)) * ((pt2(2)-pt1(2))/(pt2(1)-pt1(1)));
            else
                gray1(i,j) = pt2(2) + (gray1(i,j)-pt2(1)) * ((pt3(2)-pt2(2))/(pt3(1)-pt2(1)));
            end
        end
    end
end
[g1Hist,g1X] = imhist(gray1);
figure(1),subplot(1,2,1),imshow(ori_img1),title('ԭͼ');subplot(1,2,2),imshow(gray1),title('�Ҷ���������');
figure(2),subplot(2,1,1),stem(oriX,oriHist),title('ԭͼֱ��ͼ');subplot(2,1,2),stem(g1X,g1Hist),title('�Ҷ���������ֱ��ͼ');

