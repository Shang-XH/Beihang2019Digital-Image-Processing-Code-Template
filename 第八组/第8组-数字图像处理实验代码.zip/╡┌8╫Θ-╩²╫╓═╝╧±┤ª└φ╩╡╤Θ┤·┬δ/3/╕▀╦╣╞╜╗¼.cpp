
#include<cxcore.h>
#include<cmath>
#include<math.h>
#include<cv.h>
#include<highgui.h>
#include<opencv2\opencv.hpp>

using namespace std;
using namespace cv;

void Gaussian(const Mat &input, Mat &output, double sigma)
{
	int row = input.rows, col = input.cols;
	int window = (int)((6 * sigma - 1) / 2) * 2 + 1;
	double *temp = new double[window];

	//����߽�
	Mat INPUT;
	copyMakeBorder(input, INPUT, window / 2, window / 2, window / 2, window / 2, BORDER_REFLECT_101);

	double sum = 0;
	for (int w = 0; w < window; w++)
	{
		int mid = w - window / 2;
		temp[w] = exp(-(mid*mid) / (2 * sigma*sigma));
		sum += temp[w];
	}

	//��һ���˲��ˣ���Ϊ1
	for (int w = 0; w < window; w++)
	{
		temp[w] = temp[w] / sum;
	}

	//����߽�֮��ĳ���
	int rows = row + window - 1;
	int cols = col + window - 1;

	//�ȶ�ÿ�н���һά��˹�˲�
	for (int y = window / 2; y < row + window / 2; y++)//��
	{
		for (int x = window / 2; x < col + window / 2; x++) //��
		{
			int num = 0;
			double pix[3] = { 0 };
			for (int k = x - window / 2; k < x + window / 2; k++)
			{
				for (int c = 0; c < INPUT.channels(); c++)
				{
					pix[c] += (INPUT.at<Vec3b>(y, k)[c])*temp[num];   //������<��������
				}
				num++;
			}
			for (int c = 0; c < INPUT.channels(); c++)
			{
				INPUT.at<Vec3b>(y, x)[c] = pix[c];
			}
		}
	}

	//�ٶ�ÿ�н���һά��˹�˲�
	for (int x = window / 2; x < col + window / 2; x++) //��
	{
		for (int y = window / 2; y < row + window / 2; y++) //��
		{
			int num = 0;
			double pix[3] = { 0 };
			for (int k = y - window / 2; k < y + window / 2; k++)
			{
				for (int c = 0; c < INPUT.channels(); c++)
				{
					pix[c] += (INPUT.at<Vec3b>(k, x)[c])*temp[num];
				}
				num++;
			}
			for (int c = 0; c < INPUT.channels(); c++)
			{
				INPUT.at<Vec3b>(y, x)[c] = pix[c];
			}
		}
	}
	for (int y = 0; y < row; y++)
	{
		for (int x = 0; x < col; x++)
		{
			output.at<Vec3b>(y, x) = INPUT.at<Vec3b>(y + window / 2, x + window / 2);
		}
	}
}

int main()
{
	double sig = 1.5;
	Mat image = imread("D:\\gaosi.png");
	Mat dst = Mat::zeros(image.rows, image.cols, image.type());
	imshow("��˹����", image);
	Gaussian(image, dst, sig);
	imshow("ƽ������", dst);
	//system("pause");
	waitKey(0);
	return 0;
}