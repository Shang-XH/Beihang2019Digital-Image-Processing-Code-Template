#对图像加高斯噪声
import cv2
import numpy as np
#import matplotlib.pyplot as plt
fn="C:/Users/Public/Pictures/Sample Pictures/1.jpg"
img=cv2.imread(fn)

param=30
#�ҽ׷�Χ
grayscale=256
w=img.shape[1]
h=img.shape[0]
newimg=np.zeros((h,w,3),np.uint8)
img_mean=np.zeros((h,w,3),np.uint8)
for x in range(0,h):
    for y in range(0,w,2):
        r1=np.random.random_sample()
        r2=np.random.random_sample()
        z1=param*np.cos(2*np.pi*r2)*np.sqrt((-2)*np.log(r1))
        z2=param*np.sin(2*np.pi*r2)*np.sqrt((-2)*np.log(r1))
        
        fxy = [0 if int(i)<0 else grayscale-1 if int(i)>grayscale-1 else int(i) for i in img[x,y]+[z1, z1, z1]]
        fxy1 = [0 if int(i)<0 else grayscale-1 if int(i)>grayscale-1 else int(i) for i in img[x,y+1]+[z2, z2, z2]]

        newimg[x,y]=fxy
        newimg[x,y+1]=fxy1
    
cv2.imshow('yuantu',img)
cv2.imshow('GUASS',newimg)
cv2.imwrite('d:/1.jpg', newimg)
cv2.waitKey()
cv2.destroyAllWindows()