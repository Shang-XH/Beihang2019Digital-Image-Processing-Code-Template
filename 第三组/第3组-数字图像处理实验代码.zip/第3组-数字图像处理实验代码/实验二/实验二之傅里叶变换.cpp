#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "opencv2/core/core.hpp"
#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include  <iostream>
#include<time.h>
#include<Windows.h>
#include<winbase.h>
#define _CRT_SECURE_NO_WARNINGS
#define intsize sizeof(int)
#define complexsize sizeof(complex)
#define PI 3.1415926
#define ch 2

using namespace cv;

int *a, *b;
int nLen, init_nLen, mLen, init_mLen, N, M;
FILE *dataFile;

typedef struct {
	float real;
	float image;
}complex;
complex *A_In, *W;
complex Add(complex, complex);
complex Sub(complex, complex);
complex Mul(complex, complex);
int calculate_M(int);
void reverse(int, int);
void fft(int, int);
//һά���ٸ���Ҷ�任
void fft(complex *Z, complex *A, int fft_nLen, int fft_M)
{
	int i;
	int lev, dist, p, t;
	complex B;
	Z = (complex *)malloc(complexsize*fft_nLen / 2);
	for (lev = 1; lev <= fft_M; lev++)
	{
		dist = (int)pow(2, lev - 1);
		for (t = 0; t<dist; t++)
		{
			p = t*(int)pow(2, fft_M - lev);
			Z[p].real = (float)cos(2 * PI*p / fft_nLen);
			Z[p].image = (float)(-1 * sin(2 * PI*p / fft_nLen));
			for (i = t; i<fft_nLen; i = i + (int)pow(2, lev))
			{
				B = Add(A[i], Mul(A[i + dist], Z[p]));
				A[i + dist] = Sub(A[i], Mul(A[i + dist], Z[p]));
				A[i].real = B.real;
				A[i].image = B.image;
			}
		}
	}
	free(Z);
}
int calculate_M(int len)
{
	int i;
	int k;
	i = 0;
	k = 1;
	while (k < len)
	{
		k = k * 2;
		i++;
	}
	return i;
}
void reverse(int len, int M)
{
	int i, j;
	a = (int *)malloc(intsize*M);
	b = (int *)malloc(intsize*len);
	for (i = 0; i<M; i++)
	{
		a[i] = 0;
	}
	b[0] = 0;
	for (i = 1; i<len; i++)
	{
		j = 0;
		while (a[j] != 0)
		{
			a[j] = 0;
			j++;
		}
		a[j] = 1;
		b[i] = 0;
		for (j = 0; j<M; j++)
		{
			b[i] = b[i] + a[j] * (int)pow(2, M - 1 - j);
		}
	}
}
complex Add(complex c1, complex c2)
{
	complex c;
	c.real = c1.real + c2.real;
	c.image = c1.image + c2.image;
	return c;
}
complex Sub(complex c1, complex c2)
{
	complex c;
	c.real = c1.real - c2.real;
	c.image = c1.image - c2.image;
	return c;
}
complex Mul(complex c1, complex c2)
{
	complex c;
	c.real = c1.real*c2.real - c1.image*c2.image;
	c.image = c1.real*c2.image + c2.real*c1.image;
	return c;
}

//��άFFT
Mat DFT_trans(Mat img, Mat out)
{
	complex *A;
	resize(img, img, Size(img.cols, img.cols));
	if (ch == 1)
	{
		fft(W, A, out.rows, out.rows);
		fft(W, A, out.cols, out.cols);// FFT�任,��Ҫһ��2ͨ����Mat
	}
	else
	{
		init_mLen = img.rows;
		init_nLen = img.cols;
		/*���沽���ǽ������������չ�������2���ݴΣ����пɲ�ͬ��FFT��Ԥ����*/
		M = calculate_M(init_mLen);
		N = calculate_M(init_nLen);
		mLen = (int)pow(2, M);
		nLen = (int)pow(2, N);
		//mLen = M_;
		//nLen = N_;
		A_In = (complex *)malloc(complexsize*nLen*mLen);
		/*ͼ�����Ԫ�ش洢��complex�ṹ����*/
		for (int i = 0; i < init_mLen; i++)
		{
			//uchar *data = img.ptr<uchar>(i);
			for (int j = 0; j < init_nLen; j++)
			{
				A_In[i*nLen + j].real = (int)img.at<uchar>(i, j);
				A_In[i*nLen + j].image = 0.0;
			}
		}
		/*��������forѭ�����ǳ�ʼ���� ����չ����ķ�Ԫ�ز������0 */
		for (int i = 0; i < mLen; i++)
		{
			for (int j = init_nLen; j < nLen; j++)
			{
				A_In[i*nLen + j].real = 0.0;
				A_In[i*nLen + j].image = 0.0;
			}
		}
		for (int i = init_mLen; i < mLen; i++)
		{
			for (int j = 0; j < init_nLen; j++)
			{
				A_In[i*nLen + j].real = 0.0;
				A_In[i*nLen + j].image = 0.0;
			}
		}
		/*����һάDFT*/
		A = (complex *)malloc(complexsize*nLen);
		reverse(nLen, N);
		for (int i = 0; i < mLen; i++)
		{
			for (int j = 0; j < nLen; j++)
			{
				A[j].real = A_In[i*nLen + b[j]].real;
				A[j].image = A_In[i*nLen + b[j]].image;
			}
			fft(W, A, nLen, N);
			for (int j = 0; j < nLen; j++)
			{
				A_In[i*nLen + j].real = A[j].real;
				A_In[i*nLen + j].image = A[j].image;
			}
		}
		free(A);
		A = (complex *)malloc(complexsize*mLen);
		reverse(mLen, M);
		for (int i = 0; i < nLen; i++)
		{
			for (int j = 0; j < mLen; j++)
			{
				A[j].real = A_In[b[j] * nLen + i].real;
				A[j].image = A_In[b[j] * nLen + i].image;
			}
			fft(W, A, mLen, M);
			for (int j = 0; j < mLen; j++)
			{
				A_In[j*nLen + i].real = A[j].real;
				A_In[j*nLen + i].image = A[j].image;
			}
		}
		free(A);
		for (int i = 0; i < img.rows; i++)
		{
			for (int j = 0; j < img.cols; j++)
			{
				out.at<Vec2f>(i, j)[0] = (float)A_In[i*nLen + j].real;
				out.at<Vec2f>(i, j)[1] = (float)A_In[i*nLen + j].image;
			}
		}
		free(A_In);
	}
	return out;
}

//������������������FFT����
int main(int argc, const char ** argv)
{
	DWORD start1 = GetTickCount();//�������任����ʱ��
	Mat img = imread("C:\\Users\\ASUS\\Desktop\\lena.jpg", 0); //�ԻҶ�ͼ�����
	imshow("ԭͼ", img);
	Mat planes[] = { Mat_<float>(img), Mat::zeros(img.size(), CV_32F) };// Mat ���飬��һ��Ϊ��չ���ͼ��һ��Ϊ��ͼ��
	Mat complexImg;
	merge(planes, 2, complexImg);// �ϲ���һ��Mat
	DFT_trans(img, complexImg);												// compute log(1 + sqrt(Re(DFT(img))**2 + Im(DFT(img))**2))
	split(complexImg, planes);//����ͨ���� planes[0] Ϊʵ�����֣�planes[1]Ϊ��������
	magnitude(planes[0], planes[1], planes[0]);// ��ģ
	Mat mag = planes[0];
	mag += Scalar::all(1);
	log(mag, mag);// ģ�Ķ���
	mag = mag(Rect(0, 0, mag.cols & (-2), mag.rows & (-2)));//��֤ż���ı߳�
	int cx = mag.cols / 2;
	int cy = mag.rows / 2;
	//�Ը���Ҷ�任��ͼ��������ţ�4�����飬�����ң����ϵ��� �ֱ�Ϊq0, q1, q2, q3
	//�Ե�q0��q3, q1��q2
	Mat tmp;
	Mat q0(mag, Rect(0, 0, cx, cy));
	Mat q1(mag, Rect(cx, 0, cx, cy));
	Mat q2(mag, Rect(0, cy, cx, cy));
	Mat q3(mag, Rect(cx, cy, cx, cy));
	q0.copyTo(tmp);
	q3.copyTo(q0);
	tmp.copyTo(q3);
	q1.copyTo(tmp);
	q2.copyTo(q1);
	tmp.copyTo(q2);
	normalize(mag, mag, 0, 1, CV_MINMAX);//�淶��ֵ�� 0~1 ��ʾͼƬ����Ҫ
	imshow("DFT", mag);
	DWORD end1 = GetTickCount();
	std::cout << "ԭͼ���ٸ���Ҷ���任��������ʱ��Ϊ��" << (end1 - start1) << "ms" << std::endl;
	DWORD start2 = GetTickCount();
	Mat img2;
	dft(complexImg, img2, DFT_INVERSE + DFT_REAL_OUTPUT + DFT_SCALE);//���и���Ҷ��任
	img2 = img2(Rect(0, 0, img.cols, img.rows));
	img2.convertTo(img2, CV_8UC1);
	imshow("IDFT", img2);
	DWORD end2 = GetTickCount();
	std::cout << "ԭͼ���ٸ���Ҷ��任��������ʱ��Ϊ��" << (end2 - start2) << "ms" << std::endl;
	waitKey(0);
	return 0;
}