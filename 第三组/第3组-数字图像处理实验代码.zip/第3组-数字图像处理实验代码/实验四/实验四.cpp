﻿#include <iostream>
#include <fstream>
#include <stdlib.h> 
#include <time.h> 
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/ml/ml.hpp>
#include <opencv2/opencv.hpp>
#include <Windows.h>
#include <highgui.h>
#include <cv.h>
#include <math.h>
using namespace std;
using namespace cv;
double D0 = 35;

void ILPF(CvMat* src, const double D0, int tool)
{
	int i, j;
	int state = -1;
	double tempD;
	long width, height;
	width = src->width;
	height = src->height;
	long x, y;
	x = width / 2;
	y = height / 2;
	CvMat* H_mat;
	H_mat = cvCreateMat(src->height, src->width, CV_64FC2);
	for (i = 0; i < height; i++)
	{
		for (j = 0; j < width; j++)
		{
			if (i > y && j > x)
			{
				state = 3;
			}
			else if (i > y)
			{
				state = 1;
			}
			else if (j > x)
			{
				state = 2;
			}
			else
			{
				state = 0;
			}
			switch (state)
			{
			case 0:
				tempD = (double)(i * i + j * j); tempD = sqrt(tempD); break;
			case 1:
				tempD = (double)((height - i) * (height - i) + j * j); tempD = sqrt(tempD); break;
			case 2:
				tempD = (double)(i * i + (width - j) * (width - j)); tempD = sqrt(tempD); break;
			case 3:
				tempD = (double)((height - i) * (height - i) + (width - j) * (width - j)); 			tempD = sqrt(tempD);
				break;
			default:
				break;
			}
			//1.二维高斯高通滤波器
			if (tool == 1) {
				tempD = 1 - exp(-0.5 * pow(tempD / D0, 2));
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2] = tempD;
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2 + 1] = 0.0;
			}
			//2.二维理想高通滤波器
			if (tool == 2) {
				if (tempD <= D0)
				{
					((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2] = 0.0;
					((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2 + 1] = 0.0;
				}
				else
				{
					((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2] = 1.0;
					((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2 + 1] = 0.0;
				}
			}
			//3.二阶巴特沃思高通滤波器
			if (tool == 3) {
				tempD = 1 / (1 + pow(D0 / tempD, 2 * 2));
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2] = tempD;
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2 + 1] = 0.0;
			}
			//4.增长率为2二维指数高通滤波器
			if (tool == 4) {
				tempD = exp(-pow(D0 / tempD, 2));
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2] = tempD;
				((double*)(H_mat->data.ptr + H_mat->step * i))[j * 2 + 1] = 0.0;
			}
		}
	}
	cvMulSpectrums(src, H_mat, src, CV_DXT_ROWS);
	cvReleaseMat(&H_mat);
}
//RGB转化为HSI
Mat RGBtoHSI(Mat LeafBGRImage, double hh, double ss, double ii)
{
	Mat LeafHSIImage = Mat(Size(LeafBGRImage.cols, LeafBGRImage.rows), CV_8UC3);
	vector <Mat> channels;
	split(LeafHSIImage, channels);
	Mat Hvalue = channels.at(0);
	Mat Svalue = channels.at(1);
	Mat Ivalue = channels.at(2);
	for (int i = 0; i < LeafBGRImage.rows; ++i)
		for (int j = 0; j < LeafBGRImage.cols; ++j)
		{
			double H, S, I;
			int Bvalue = LeafBGRImage.at<Vec3b>(i, j)(0);
			int Gvalue = LeafBGRImage.at<Vec3b>(i, j)(1);
			int Rvalue = LeafBGRImage.at<Vec3b>(i, j)(2);
			//求Theta =acos((((Rvalue - Gvalue) + (Rvalue - Bvalue)) / 2) / sqrt(pow((Rvalue - Gvalue), 2) + (Rvalue - Bvalue)*(Gvalue - Bvalue)));
			double numerator = ((Rvalue - Gvalue) + (Rvalue - Bvalue)) / 2;
			double denominator = sqrt(pow((Rvalue - Gvalue), 2) + (Rvalue - Bvalue)*(Gvalue - Bvalue));
			if (denominator == 0) H = 0;
			else {
				double Theta = acos(numerator / denominator) * 180 / 3.14;
				if (Bvalue <= Gvalue)
					H = Theta;
				else  H = 360 - Theta;
			}
			H += hh;
			Hvalue.at<uchar>(i, j) = (int)(H * 255 / 360); //为了显示将[0~360]映射到[0~255]
														   //求S = 1-3*min(Bvalue,Gvalue,Rvalue)/(Rvalue+Gvalue+Bvalue);
			int minvalue = Bvalue;
			if (minvalue > Gvalue) minvalue = Gvalue;
			if (minvalue > Rvalue) minvalue = Rvalue;
			numerator = 3 * minvalue;
			denominator = Rvalue + Gvalue + Bvalue;
			if (denominator == 0)  S = 0;
			else {
				S = 1 - numerator / denominator;
			}
			S += ss;
			Svalue.at<uchar>(i, j) = (int)(S * 255);//为了显示将[0~1]映射到[0~255]
			I = (Rvalue + Gvalue + Bvalue) / 3;
			I += ii;
			Ivalue.at<uchar>(i, j) = (int)(I);
		}
	merge(channels, LeafHSIImage);
	return LeafHSIImage;
}

//利用不同高通模板进行图像增强
Mat ruihua(Mat image1, int i)
{
	IplImage imgTmp = image1;
	IplImage *im = cvCloneImage(&imgTmp);
	IplImage * realInput;
	IplImage * imaginaryInput;
	IplImage * complexInput;
	int dft_M, dft_N;
	CvMat* dft_A, tmp, *dft_B;
	IplImage * image_Re;
	IplImage * image_Im;
	double m, M;

	//做DFT变换的尺寸不一样
	dft_M = cvGetOptimalDFTSize(im->height - 1);
	dft_N = cvGetOptimalDFTSize(im->width - 1);
	dft_B = cvCreateMat(dft_M, dft_N, CV_64FC2);
	dft_A = cvCreateMat(dft_M, dft_N, CV_64FC2);
	cvZero(dft_A);
	cvZero(dft_B);

	//先把im扩充，之后赋值就不需要扩充。根据图的需要，这里扩充白色边界，在im中也就是cvScalar(255)
	//扩充的颜色值应该与背景颜色一致，否则会在背景与前景相接的位置检测到多余的轮廓。
	IplImage* large_img = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_8U, 1);//IPL_DEPTH_8U-----uchar
	cvCopyMakeBorder(im, large_img, cvPoint((dft_N - im->width) / 2, (dft_M - im->height) / 2), IPL_BORDER_CONSTANT, cvScalar(125));
	realInput = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_64F, 1);
	imaginaryInput = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_64F, 1);
	complexInput = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_64F, 2);
	//高通滤波之前，需要转化成double，实部输入就是灰度图本身，虚部是空，合并为复变量complexInput，这时尺寸已经满足要求
	cvScale(large_img, realInput, 1.0, 0.0);
	cvZero(imaginaryInput);
	cvMerge(realInput, imaginaryInput, NULL, NULL, complexInput);
	//把数据直接裁剪到中心位置
	cvGetSubRect(dft_A, &tmp, cvRect(0, 0, complexInput->width, complexInput->height));
	//cvGetSubRect(dft_A, &tmp, cvRect(0，0，im->width,im->height));
	cvCopy(complexInput, &tmp, NULL);
	//DFT变换，高通滤波，DFT反变换
	cvDFT(dft_A, dft_A, CV_DXT_FORWARD, complexInput->height);
	ILPF(dft_A, D0, i);
	cvDFT(dft_A, dft_A, CV_DXT_INVERSE, complexInput->height);
	//取出实部
	image_Re = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_64F, 1);
	image_Im = cvCreateImage(cvSize(dft_N, dft_M), IPL_DEPTH_64F, 1);
	cvSplit(dft_A, image_Re, image_Im, 0, 0);
	IplImage *uint8image = cvCreateImage(cvGetSize(image_Re), IPL_DEPTH_8U, 1);
	cvMinMaxLoc(image_Re, &m, &M, NULL, NULL, NULL);
	cvConvertScale(image_Re, uint8image, 255 / (M - m), 255 * (-m) / (M - m));//0-255之间
																			  //cvMinMaxLoc(uint8image, &m, &M, NULL, NULL, NULL);//此时的n,M [0-1]
																			  //二值化
	IplImage *bwimage = cvCreateImage(cvGetSize(uint8image), IPL_DEPTH_8U, 1);//二值图像
	cvAdaptiveThreshold(uint8image, bwimage, 255, CV_ADAPTIVE_THRESH_MEAN_C, 1, 11, 10.0);
	Mat beimage1 = cvarrToMat(bwimage, true);
	return beimage1;
}

int main() {
	Mat image = imread("C:\\Users\\ASUS\\Desktop\\lena.jpg");
	Mat im1 = imread("C:\\Users\\ASUS\\Desktop\\lena.jpg", 0);
	imshow("原图", im1);

	//二维高斯高通滤波器
	Mat beimage1 = ruihua(im1, 1);
	imshow("高斯滤波", beimage1);
	double alphaValue = 0.8;
	double betaValue;
	betaValue = 1.0 - alphaValue;
	Mat output;
	addWeighted(im1, alphaValue, beimage1, betaValue, 0.0, output);
	namedWindow("边缘增强图像1");
	imshow("边缘增强图像1", output);
	waitKey(0);

	//二阶巴特沃思高通滤波
	Mat beimage2 = ruihua(im1, 3);
	imshow("巴特沃斯滤波", beimage2);
	Mat output2;
	addWeighted(im1, alphaValue, beimage2, betaValue, 0.0, output2);
	namedWindow("边缘增强图像2");
	imshow("边缘增强图像2", output2);
	waitKey(0);

	//进行RGB和HSI转换
	imshow("RGB", image);
	imshow("HSI原图", RGBtoHSI(image, 0, 0, 0));
	Mat HHH = RGBtoHSI(image, 30, 0, 0);
	Mat SSS = RGBtoHSI(image, 0, 0.3, 0);
	Mat III = RGBtoHSI(image, 0, 0, 110.3);
	imshow("调整H分量", HHH);
	imshow("调整S分量", SSS);
	imshow("调整I分量", III);
	waitKey(0);
	return 0;
}