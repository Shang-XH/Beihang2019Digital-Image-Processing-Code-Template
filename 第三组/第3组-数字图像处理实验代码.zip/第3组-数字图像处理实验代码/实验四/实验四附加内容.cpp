#include<opencv2/opencv.hpp>
using namespace cv;
using namespace std;

Mat scaleGray(const Mat& inputGray)
{
	Mat outputGray(inputGray.size(), CV_8U);
	unsigned char grayValue, maxValue = 1;
	for (int y = 0; y < inputGray.rows; y++)
	{
		for (int x = 0; x < inputGray.cols; x++)
		{
			grayValue = inputGray.at<uchar>(y, x);
			maxValue = max(maxValue, grayValue);
		}
	}
	float scale = 255.0 / maxValue;
	for (int y = 0; y < inputGray.rows; y++)
	{
		for (int x = 0; x < inputGray.cols; x++)
		{
			outputGray.at<uchar>(y, x) = static_cast<unsigned char>(inputGray.at<uchar>(y, x)*scale + 0.5);
		}
	}
	return outputGray;
}

//ת��Ϊα��ɫͼ��
Mat gray2pseudocolor(const Mat& scaledGray)
{
	Mat outputPseudocolor(scaledGray.size(), CV_8UC3);
	unsigned char grayValue;
	for (int y = 0; y < scaledGray.rows; y++)
	{
		for (int x = 0; x < scaledGray.cols; x++)
		{
			grayValue = scaledGray.at<uchar>(y, x);
			Vec3b & pixel = outputPseudocolor.at<Vec3b>(y, x);
			pixel[0] = abs(255 - grayValue);
			pixel[1] = abs(127 - grayValue);
			pixel[2] = abs(0 - grayValue);
		}
	}
	return outputPseudocolor;
}

int main()
{
	//����Ҷ�ͼ��
	Mat inputGray = imread("image11.jpg", 0);
	Mat scaledGray = scaleGray(inputGray);
	Mat pseudocolor = gray2pseudocolor(scaledGray);
	//���α��ɫͼ��
	imshow("ԭͼ", inputGray);
	imshow("α��ɫͼ��", pseudocolor);
	waitKey(0);
	return 0;
}