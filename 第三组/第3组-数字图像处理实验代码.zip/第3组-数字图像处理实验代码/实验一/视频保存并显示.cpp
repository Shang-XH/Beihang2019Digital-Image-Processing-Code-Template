#include"opencv2/highgui/highgui.hpp"
#include"opencv2/imgproc/imgproc.hpp"
#include<iostream>
#include<fstream>
#include<cv.h>
#include<highgui.h>

using namespace std;
using namespace cv;

int g_slider_position = 0;
int g_run = 1, g_dontset = 0;
cv::VideoCapture g_cap;
// �ص�������ʵ�ִ��ڹ�����
void onTrackbarSlide(int pos, void*) {

	g_cap.set(cv::CAP_PROP_POS_FRAMES, pos);

	if (!g_dontset)
		g_run = 1;
	g_dontset = 0;
}

int main(int argc, char** argv) {
	cv::namedWindow("example2_4", cv::WINDOW_AUTOSIZE);//�������ڣ����ڴ�С������Ƶ�����С���仯
	g_cap.open("C:\\Users\\Public\\Videos\\Sample Videos\\animals.wmv");
	int frames = (int)g_cap.get(cv::CAP_PROP_FRAME_COUNT);//��ȡ��Ƶ���ĸ�������
	int tmpw = (int)g_cap.get(cv::CAP_PROP_FRAME_WIDTH);
	int tmph = (int)g_cap.get(cv::CAP_PROP_FRAME_HEIGHT);
	int a = tmph;
	int b = tmpw;
	cout << a << b << endl;
	cout << "Video has " << frames << " frames of dimensions(" << tmpw << "," << tmph << ")." << endl;

	cv::createTrackbar("Position", "example2_4", &g_slider_position, frames, onTrackbarSlide);

	cv::Mat frame;
	while (1)
	{
		if (g_run != 0) {
			g_cap >> frame; if (frame.empty())break;
			int current_pos = (int)g_cap.get(cv::CAP_PROP_POS_FRAMES);
			g_dontset = 1;

			cv::setTrackbarPos("Position", "example2_4", current_pos);
			cv::imshow("example2_4", frame);

			g_run = g_run - 1;
		}

		char c = (char)cv::waitKey(10);
		if (c == 'r')//����r��Ƶ����
		{
			g_run = -1; cout << "Run mode,run=" << g_run << endl;
		}
		if (c == 27 || c == 'q')//����q��esc�˳�����
			break;
	}
	return 0;
}