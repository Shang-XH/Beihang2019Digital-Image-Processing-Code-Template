#include <iostream>
#include <stdlib.h>
#include <Windows.h>
#include "tiffio.h"

using namespace std;

void CreatTiffFile(const char *FileName, unsigned char *Buf, uint32 width, uint32 height);

int main()
{
	TIFF *tifFile = TIFFOpen("example.tif", "r");   //��ǰ�ڹ���Ŀ¼�·����ļ�����r����ʾ��дȨ��Ϊ������
	int width, height;
	TIFFGetField(tifFile, TIFFTAG_IMAGEWIDTH, &width);
	TIFFGetField(tifFile, TIFFTAG_IMAGELENGTH, &height);
	int pixelCount = width * height;
	unsigned int *image = new unsigned int[pixelCount];
	TIFFReadRGBAImage(tifFile, width, height, image, 1);
	unsigned char *R = new unsigned char[pixelCount];
	unsigned char *G = new unsigned char[pixelCount];
	unsigned char *B = new unsigned char[pixelCount];
	unsigned char *A = new unsigned char[pixelCount];
	for (int i = 0; i < pixelCount; i++)
	{
		R[i] = 0x00;
		G[i] = 0x00;
		B[i] = 0x00;
		A[i] = 0x00;
	}
	unsigned int *rowPointerToSrc = image + width * (height - 1);
	unsigned char *rowPointerToR = R;
	unsigned char *rowPointerToG = G;
	unsigned char *rowPointerToB = B;
	unsigned char *rowPointerToA = A;
	for (int y = 0; y < height; y++)
	{
		unsigned int *colPointerToSrc = rowPointerToSrc;
		unsigned char *colPointerToR = rowPointerToR;
		unsigned char *colPointerToG = rowPointerToG;
		unsigned char *colPointerToB = rowPointerToB;
		unsigned char *colPointerToA = rowPointerToA;
		//cout << "�� " << y+1 << " �У�" << endl;
		for (int x = 0; x < width; x++)
		{
			colPointerToR[0] = (unsigned char)TIFFGetR(colPointerToSrc[0]);
			colPointerToG[0] = (unsigned char)TIFFGetG(colPointerToSrc[0]);
			colPointerToB[0] = (unsigned char)TIFFGetB(colPointerToSrc[0]);
			colPointerToA[0] = (unsigned char)TIFFGetA(colPointerToSrc[0]);
			//cout << "\tR:" << (int)colPointerToR[0] << "\tG:" << (int)colPointerToG[0] << "\tB:" << (int)colPointerToB[0] << "\tA:" << (int)colPointerToA[0] << endl;
			colPointerToSrc++;
			colPointerToR++;
			colPointerToG++;
			colPointerToB++;
			colPointerToA++;
		}
		rowPointerToSrc -= width;
		rowPointerToR += width;
		rowPointerToG += width;
		rowPointerToB += width;
		rowPointerToA += width;
	}
	delete image;

	uint32 pixel = height * width * 3;
	BYTE *pic = new BYTE[pixel];
	for (uint32 i = 0; i < pixelCount; i++)
	{
		pic[i * 3] = R[i];
		pic[i * 3 + 1] = G[i];
		pic[i * 3 + 2] = B[i];
	}
	delete R;
	delete G;
	delete B;
	delete A;

	const char *fileName = "test.tif";
	CreatTiffFile(fileName, pic, width, height);
	system("pause");
	return 0;
}

void CreatTiffFile(const char *FileName, unsigned char *Buf, uint32 width, uint32 height)
{
	TIFF *imageTest = TIFFOpen(FileName, "w");
	if (imageTest == NULL) {
		printf("Could not open output.tif for writing\n");
		cout << "open is failed.\n";
		system("pause");
		exit(1);
	}
	TIFFSetField(imageTest, TIFFTAG_IMAGEWIDTH, width);
	TIFFSetField(imageTest, TIFFTAG_IMAGELENGTH, height);
	TIFFSetField(imageTest, TIFFTAG_BITSPERSAMPLE, 8);// bits per channel (sample) ÿ��ͨ����������
	TIFFSetField(imageTest, TIFFTAG_SAMPLESPERPIXEL, 3);// samples per pixel ÿ���ز���
	TIFFSetField(imageTest, TIFFTAG_ROWSPERSTRIP, height);//of data ÿ�������У�д�����صĸ߶����ƣ�
																	 //TIFFSetField(imageTest, TIFFTAG_COMPRESSION, COMPRESSION_CCITTFAX4);
	TIFFSetField(imageTest, TIFFTAG_PHOTOMETRIC, PHOTOMETRIC_RGB);
	TIFFSetField(imageTest, TIFFTAG_FILLORDER, FILLORDER_MSB2LSB);
	TIFFSetField(imageTest, TIFFTAG_PLANARCONFIG, PLANARCONFIG_CONTIG);
	TIFFSetField(imageTest, TIFFTAG_XRESOLUTION, 600.0);
	TIFFSetField(imageTest, TIFFTAG_YRESOLUTION, 600.0);
	TIFFSetField(imageTest, TIFFTAG_RESOLUTIONUNIT, RESUNIT_INCH);
	//Write the information to the file
	TIFFWriteEncodedStrip(imageTest, 0, Buf, width * height * 3);

	TIFFClose(imageTest);
	//return true;
	waitKey(0);
}
