clear;
close all;
A = imread('C:\Users\Lenovo\Desktop\image\lenna2.jpg');
A = rgb2gray(A);
A = im2double(A);

[m,n] = size(A);
%ע��ͼ�����Ķ�ά�±궼��1��ʼ
F=zeros(m,n);G=F;f=F;H=F;C=F;
% %����Ҷ�任
for u=1:m
    for v=1:n
        sum = 0;
        sum2 = 0;
        for x=1:m
            e1 = exp(-i*2*pi*u*x/m);
            for y=1:n
                e2 = exp(-i*2*pi*v*y/n);
                sum = sum + A(x,y)*e1*e2;
                sum2 = sum2 + A(x,y)*((-1)^(x+y))*e1*e2;
            end
        end
        F(u,v) = sum;%ԭͼ�ĸ���Ҷ�任
        G(u,v) = sum2;%ƽ�ƺ�ĸ���Ҷ�任
    end
end
figure;
subplot(2,3,1);
imshow(abs(F));title('����Ҷ�任ͼ')


% %����Ҷ��任
for x=1:m
    for y=1:n
        sum = 0;
        for u=1:m
            e1 = exp(i*2*pi*u*x/m);
            for v=1:n
                e2 = exp(i*2*pi*v*y/n);
                sum = sum + F(u,v)*e1*e2;
            end
        end
        f(x,y) = real(sum/(m*n));
    end
end
subplot(2,3,2);imshow(f);title('����Ҷ��任ͼ')
subplot(2,3,3);imshow(abs(G));title('ͼ��ƽ�ƺ�������Ҷ�任')

g=zeros(m,2*n);
%ͼ��չ��
for x=1:m
    for y=1:2*n
      g(x,y)=A(x,ceil(y/2));
    end
end
subplot(2,3,4);imshow(g);title('ͼ��չ��')

%ͼ��չ����������Ҷ�任
for u=1:m
    for v=1:2*n
        sum = 0;
        for x=1:m
            e1 = exp(-i*2*pi*u*x/m);
            for y=1:2*n
                e2 = exp(-i*2*pi*v*y/(2*n));
                sum = sum + g(x,y)*((-1)^(x+y))*e1*e2;
            end
        end
        H(u,v) = sum;
    end
end
subplot(2,3,5);imshow(abs(H));title('ͼ��չ����������Ҷ�任')

%���ұ任
for u=1:m
    if u==0
        a=sqrt(1/m);
        else
        a=sqrt(2/m);
    end
    for v=1:n
        if v==0
        b=sqrt(1/n);
        else
        b=sqrt(2/n);
        end
    sum=0;
        for x=1:m
            e1=cos((2*x+1)*u*pi/(2*m));
            for y=1:n
                e2=cos((2*y+1)*v*pi/(2*n));
                sum=sum+A(x,y)*e1*e2;
            end
        end
        C(u,v)=sum*a*b;
    end
end
subplot(2,3,6);imshow(abs(C));title('���ұ任')




