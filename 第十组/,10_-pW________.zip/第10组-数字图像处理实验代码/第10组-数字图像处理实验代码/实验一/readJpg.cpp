// ConsoleApplication1.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
/*
*This program will open a image,and output to another file
*/

#include  <cstdio>
#include <iostream>
#include<stdio.h>
#include<stdlib.h>
#include <windows.h>
#include <wingdi.h>
#include <opencv2/opencv.hpp>

#define H 256 
#define W 256
using namespace std;

#define   __FILENAME  "in.jpg"  

int main()
{

	FILE *fp, *out, *dstFile;

	long int size;

	unsigned char ch, ch1, ch2;
	unsigned char high, low;

	char pic_name[30] = "in.jpg";

	printf_s("The filename is:%s\n", pic_name);

	fopen_s(&fp, pic_name, "rb");

	fopen_s(&out, "res.txt", "wb+");

	fopen_s(&dstFile, "res.jpg", "wb+");

	{
		if (!fp || !out || !dstFile) {
			printf_s("Can not open the file you input,check the filename and re-try\n");
			//exit(EXIT_FAILURE);
		}
	}
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);

	printf("get the size is: %d\n", size);

	rewind(fp);

	long int i;
	for (i = 0; i < size; i++)
	{
		ch = fgetc(fp);
		high = ch >> 4;
		low = ch & 0x0f;
		if (high < 10)
			high += '0';
		else
			high += 55;
		if (low < 10)
			low += '0';
		else
			low += 55;

		fputc(high, out);
		fputc(low, out);
		fputc(' ', out);

		if (i % 16 == 0)
			fprintf(out, "\r\n");
	}

	rewind(fp);
	bool FormatRight = false;
	for (i = 0; i < size; i++)
	{
		ch1 = fgetc(fp);
		if (ch1 == 0xff)
		{
			ch2 = fgetc(fp);
			if (ch2 == 0xd8)
			{
				fputc(ch1, dstFile);
				fputc(ch2, dstFile);
				FormatRight = true;
				break;
			}
		}
	}
	if (FormatRight)
	{
		for (; i < size; i++)
		{
			ch1 = fgetc(fp);
			fputc(ch1, dstFile);
			if (ch1 == 0xff)
			{
				ch2 = fgetc(fp);
				if (ch2 == 0xd9)
					break;
				else
					fputc(ch2, dstFile);
			}
		}
		fclose(fp);
		fclose(out);
		fclose(dstFile);
		cv::Mat img = cv::imread("res.jpg");
		cv::namedWindow("res.jpg", cv::WINDOW_AUTOSIZE);
		cv::imshow("res.jpg", img);
		cv::waitKey(0);

		return 0;
	}
}
