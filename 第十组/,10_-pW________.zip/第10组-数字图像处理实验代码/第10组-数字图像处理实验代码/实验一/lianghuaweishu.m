a=imread('C:\Users\lh\Desktop\lena.bmp');
figure;
imshow(uint8(a));
b=double(a);
c=round(b/64);
d=c*64;
figure;
imshow(uint8(d));