﻿#include <iostream>
#include "opencv2/imgproc.hpp"
#include "opencv2/imgcodecs.hpp"
#include <opencv2/opencv.hpp>

using namespace cv;
using namespace std;



/*
* @brief motionBlur   去除运动模糊
* @param srcImg       原图
* @param destImg      去模糊后图片
* @param x            水平方向移动的距离
* @param y            垂直方向移动距离
* @param T            曝光时间
* param s             曝光系数

*/
void motionBlur(cv::Mat srcImg, cv::Mat &destImg, double x, double y, int T, double s) {
	int width;
	int height;
	width = srcImg.cols;
	height = srcImg.rows;
	if (srcImg.empty()) {
		std::cout << "image is empty!!";
		return;
	}
	double tempX;
	double tempY;
	int sumValue;
	int tempValue;
	destImg = cv::Mat::zeros(height, width, CV_64FC1);
	srcImg.convertTo(srcImg, CV_64FC1);
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			tempX = 0;
			tempY = 0;
			sumValue = 0;
			tempValue = 0;
			for (int t = 0; t < T; t++) {
				tempY = (double)i - (double)t / (double)T * x;  // 水平
				tempX = (double)j - (double)t / (double)T * y; // 垂直
				tempX = (tempX - (int)tempX) >= 0.5 ? ceil(tempX) : floor(tempX);
				tempY = (tempY - (int)tempY) >= 0.5 ? ceil(tempY) : floor(tempY);
				tempX = tempX < 0 ? 0 : tempX;
				tempY = tempY < 0 ? 0 : tempY;
				tempX = tempX >= width ? width - 1 : tempX;
				tempY = tempY >= height ? height - 1 : tempY;
				tempValue = (int)(srcImg.at<double>((int)tempY, (int)tempX)*s); // 模糊后的像素值
																				// std::cout << tempX <<" "<<tempY << " "<<tempValue<< std::endl;
				sumValue += tempValue; // 积分累加
			}
			sumValue = sumValue > 255 ? 255 : sumValue;
			// std::cout << sumValue << std::endl;
			destImg.at<double>(i, j) = (double)sumValue;
		}
	}
	destImg.convertTo(destImg, CV_8UC1);
}


void main() {
	cv::Mat img = cv::imread("1.png");
	cv::Mat result;
	cv::Mat grayImage;
	Mat filter;
	cv::cvtColor(img, grayImage, CV_BGR2GRAY);
	motionBlur(grayImage, result, -1, 0, 10, 0.2);

	cv::imshow("gray", grayImage);
	cv::imshow("motionBlur Image", result);
	cv::waitKey(0);
}