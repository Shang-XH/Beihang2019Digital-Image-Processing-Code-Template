#include "stdio.h"


int main()
{
	int m, n;
	FILE *fp;
	fopen_s(&fp, "3.raw", "rb");
	m = 621, n = 1000;
	unsigned char *bufOut = new unsigned char[m * n];
	fread(bufOut, sizeof(unsigned char), m*n, fp);
	fopen_s(&fp, "rr.raw", "wb");
	fwrite(bufOut, sizeof(unsigned char), m * n, fp);
	fclose(fp);
}