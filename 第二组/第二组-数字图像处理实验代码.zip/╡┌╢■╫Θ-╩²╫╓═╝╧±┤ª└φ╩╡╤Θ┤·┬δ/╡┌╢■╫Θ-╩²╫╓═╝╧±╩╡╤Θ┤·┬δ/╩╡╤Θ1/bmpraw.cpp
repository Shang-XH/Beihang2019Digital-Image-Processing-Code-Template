#include <stdio.h>
#include<stdlib.h>
static unsigned char ii[350][500];
int Row = 350 ,Col = 500;
char file_name[40];
 void Load_data_file()
{
	int f1;
	int i, n;
	unsigned long offbits;
	FILE *fp;
	printf("Please input original file name :");
	scanf("%s", file_name);
	f1 = Col*Row;
	if ((fp = fopen(file_name, "rb")) == 0)
	{
		printf("Cannot open file,push any key!\n");
		putchar(0x07);
		getchar();
		exit(0);
	}
	fseek(fp, 10L, 0);
	fread(&offbits, 4, 1, fp);
	printf("offBits=%ld\n", offbits);
	printf("press any key to continue\n");
	putchar(0x07);
	getchar();
	fseek(fp, offbits, 0);
	if (fread(ii, 1, f1, fp) != f1)
	{
		printf("File read error\n");
		putchar(0x07);
		getchar();
		exit(0);
	}
	fclose(fp);
};
void main()
{
	FILE * fp;
	unsigned char oi[350][500];
	int f2 = Col*Row, i, j;
	Load_data_file();
	for (i = 0; i<Row; i++)
		for (j = 0; j<Col; j++)
		{
			oi[i][j] = ii[Row - i - 1][j];
			printf("%d ", oi[i][j]);
		}
	printf("\n");
	printf("Input save file name:");
	scanf("%s", file_name);
	if ((fp = fopen(file_name, "wb")) == 0)
	{
		printf("Cannot open file\n");
		return;
	}
	if (fwrite(oi, 1, f2, fp) != f2)
		printf("File write error\n");
	fclose(fp);
	getchar();
	return;
}