#pragma once
#ifndef DATA_
#define DATA_
#include <vector>
#include<deque>
#include"memory.h"
using namespace std;


typedef  unsigned char PIXUC1;
typedef   float  PIXFC1;

//��ͨ�� ����ͼ��
template<class PIXVALUETYPE>
class IMGCH1 {
public:
	IMGCH1(unsigned int HEIGHT_, unsigned int WIDTH_, unsigned char INITVALUE);
	IMGCH1(unsigned int HEIGHT_, unsigned int WIDTH_, PIXVALUETYPE* dataPtr_);
	~IMGCH1();
	PIXVALUETYPE* dataPtr;
	unsigned int rows;
	unsigned int cols;

};


////////////////////////////////////////////////////////////////////////////////////////////////////

template<class PIXVALUETYPE>
IMGCH1<PIXVALUETYPE>::IMGCH1(unsigned int HEIGHT_, unsigned int WIDTH_, unsigned char INITVALUE) :rows(HEIGHT_), cols(WIDTH_)
{
	dataPtr = new PIXVALUETYPE[rows*cols];
	memset(dataPtr, INITVALUE, rows*cols);
}
template<class PIXVALUETYPE>
IMGCH1<PIXVALUETYPE>::IMGCH1(unsigned int HEIGHT_, unsigned int WIDTH_, PIXVALUETYPE* dataPtr_) :rows(HEIGHT_), cols(WIDTH_)
{
	dataPtr = new PIXVALUETYPE[rows*cols];
	long int datalength = rows*cols;
	//��������
	PIXVALUETYPE*pt = dataPtr;
	PIXVALUETYPE*pt_ = dataPtr_;
	for (int i = 0; i<datalength; i++, pt++, pt_++)
		*pt = *pt_;
}
template<class PIXVALUETYPE>
IMGCH1<PIXVALUETYPE>:: ~IMGCH1()
{
	delete[] dataPtr;
}

#endif