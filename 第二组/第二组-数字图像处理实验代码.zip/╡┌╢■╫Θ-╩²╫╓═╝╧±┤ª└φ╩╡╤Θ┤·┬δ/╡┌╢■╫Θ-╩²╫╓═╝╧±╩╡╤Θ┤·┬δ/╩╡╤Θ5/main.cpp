#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>
#include <math.h>
#include <stdio.h>
#include"MyCanny.h"


using namespace std;
using namespace cv;


//������ֵ
Mat IterationThreshold(Mat src)
{
	int width = src.cols;
	int height = src.rows;
	int hisData[256] = { 0 };
	for (int j = 0; j < height; j++)
	{
		uchar* data = src.ptr<uchar>(j);
		for (int i = 0; i < width; i++)
			hisData[data[i]]++;
	}

	int T0 = 0;
	for (int i = 0; i < 256; i++)
	{
		T0 += i*hisData[i];
	}
	T0 /= width*height;

	int T1 = 0, T2 = 0;
	int num1 = 0, num2 = 0;
	int T = 0;
	while (1)
	{
		for (int i = 0; i < T0 + 1; i++)
		{
			T1 += i*hisData[i];
			num1 += hisData[i];
		}
		if (num1 == 0)
			continue;
		for (int i = T0 + 1; i < 256; i++)
		{
			T2 += i*hisData[i];
			num2 += hisData[i];
		}
		if (num2 == 0)
			continue;

		T = (T1 / num1 + T2 / num2) / 2;

		if (T == T0)
			break;
		else
			T0 = T;
	}

	Mat dst;
	threshold(src, dst, T, 255, 0);
	return dst;
}


//sobel����ʵ��

const int fac[9] = { 1, 1, 2, 6, 24, 120, 720, 5040, 40320 };
//Sobelƽ������
Mat getSmmoothKernel(int ksize) 
{
	Mat Smooth = Mat::zeros(Size(ksize, 1), CV_32FC1);
	for (int i = 0; i < ksize; i++) 
	{
		Smooth.at<float>(0, i) = float(fac[ksize - 1] / (fac[i] * fac[ksize - 1 - i]));
	}
	return Smooth;
}
//Sobel�������
Mat getDiffKernel(int ksize) 
{
	Mat Diff = Mat::zeros(Size(ksize, 1), CV_32FC1);
	Mat preDiff = getSmmoothKernel(ksize - 1);
	for (int i = 0; i < ksize; i++) 
	{
		if (i == 0) 
		{
			Diff.at<float>(0, i) = 1;
		}
		else if (i == ksize - 1) 
		{
			Diff.at<float>(0, i) = -1;
		}
		else 
		{
			Diff.at<float>(0, i) = preDiff.at<float>(0, i) - preDiff.at<float>(0, i - 1);
		}
	}
	return Diff;
}
//����filter2Dʵ�־���
void conv2D(InputArray src, InputArray kernel, OutputArray dst, int dep, Point anchor = Point(-1, -1), int borderType = BORDER_DEFAULT) 
{
	Mat kernelFlip;
	flip(kernel, kernelFlip, -1);
	filter2D(src, dst, dep, kernelFlip, anchor, 0.0, borderType);
}
//�Ƚ��д�ֱ����ľ������ٽ���ˮƽ����ľ���
void sepConv2D_Y_X(InputArray src, OutputArray dst, int dep, InputArray kernelY, InputArray kernelX, Point anchor = Point(-1, -1), int borderType = BORDER_DEFAULT) 
{
	Mat Y;
	conv2D(src, kernelY, Y, dep, anchor, borderType);
	conv2D(Y, kernelX, dst, dep, anchor, borderType);
}
//�Ƚ���ˮƽ����ľ������ٽ��д�ֱ����ľ���
void sepConv2D_X_Y(InputArray src, OutputArray dst, int dep, InputArray kernelX, InputArray kernelY, Point anchor = Point(-1, -1), int borderType = BORDER_DEFAULT) 
{
	Mat X;
	conv2D(src, kernelX, X, dep, anchor, borderType);
	conv2D(X, kernelY, dst, dep, anchor, borderType);
}
//Sobel������ȡ��Ե��Ϣ
Mat Sobel(Mat &src, int x_flag, int y_flag, int kSize, int borderType) 
{
	Mat Smooth = getSmmoothKernel(kSize);
	Mat Diff = getDiffKernel(kSize);
	Mat dst;
	if (x_flag) 
	{
		sepConv2D_Y_X(src, dst, CV_32FC1, Smooth.t(), Diff, Point(-1, -1), borderType);
	}
	else if (x_flag == 0 && y_flag) 
	{
		sepConv2D_X_Y(src, dst, CV_32FC1, Smooth, Diff.t(), Point(-1, -1), borderType);
	}
	return dst;
}


//canny���Ӽ���Ե
#include"MyCanny.h"
//////Ϊ����ʾ�����԰������show����ע�͵����Ϳ�����ʵ�ֲ��ֲ�������opencv  
#include"opencv.hpp"
using namespace cv;
void MyCanny::operator()(const IMGCH1<PIXUC1>& srcimg_, IMGCH1<PIXUC1>& CannyImg_, int lowthread, int highthread, int size)
{
	if (srcimg_.cols == 0 && srcimg_.rows == 0)
	{
		cerr << "  imageSource is empty" << endl;
		return;
	}
	if (lowthread>highthread)
	{
		cerr << "Fourth parameter must large than third parameter. " << endl;
		return;
	}
	if (size<1)
	{
		cerr << "size  must be a Positive. " << endl;
		return;
	}
	if (size % 2 != 1)
	{
		cout << "  size is expected a Odd. " << endl;
		size += 1;
	}
	if (lowthread<1) lowthread = 1;
	width = srcimg_.cols;
	height = srcimg_.rows;

	//��˹��
	float **gaus = new float *[size];  //����������  
	for (int i = 0; i<size; i++)
	{
		gaus[i] = new float[size];  //��ά����
	}

	float *gausArray = new float[size*size];
	GetGaussianKernel(gaus, gausArray, size, 1); //����size*size ��С��˹�����ˣ�Sigma=1��
												 //�˲�
	IMGCH1<PIXUC1> imageGaussian_(height, width, PIXUC1(0));
	GaussianFilter(srcimg_, imageGaussian_, gausArray, size);

	//�ݶ�
	IMGCH1<PIXUC1> SobelGradAmpl_(height, width, PIXUC1(0));
	char *pointDirection = new  char[srcimg_.cols*srcimg_.rows];  //�����ݶȷ��������
	SobelGradDirection(imageGaussian_, SobelGradAmpl_, pointDirection);  //����X��Y�����ݶȺͷ����


																		 //�ֲ��Ǽ���ֵ����
	IMGCH1<PIXUC1> imageLocalMax_(height, width, PIXUC1(0));
	LocalMaxValue(SobelGradAmpl_, imageLocalMax_, pointDirection);

	//˫��ֵ����
	DoubleThreshold(imageLocalMax_, lowthread, highthread);

	//˫��ֵ�м���ֵ�˳�������
	DoubleThresholdLink(imageLocalMax_, CannyImg_, lowthread);


	delete[]pointDirection;
	for (int i = 0; i<size; i++)   //ɾ����˹������
		delete[] gaus[i];
	delete[]gausArray;
}
void MyCanny::GetGaussianKernel(float **gaus, float *gausArray, const int size, const float sigma)
{
	const double PI = 4.0*atan(1.0); //Բ���ʦи�ֵ  
	int center = size / 2;
	double sum = 0;
	for (int i = 0; i<size; i++)
	{
		for (int j = 0; j<size; j++)
		{
			gaus[i][j] = (1 / (2 * PI*sigma*sigma))*exp(-((i - center)*(i - center) + (j - center)*(j - center)) / (2 * sigma*sigma));
			sum += gaus[i][j];
		}
	}
	for (int i = 0; i<size; i++)
		for (int j = 0; j<size; j++)
			gaus[i][j] /= sum;

	for (int i = 0; i<size*size; i++)
	{
		gausArray[i] = 0;  //����ֵ���ռ����  
	}
	int array = 0;
	for (int i = 0; i<size; i++)
		for (int j = 0; j<size; j++)
		{
			gausArray[array] = gaus[i][j];//��ά���鵽һά �������  
			array++;
		}

	return;
}




//******************��˹�˲�*************************  

void MyCanny::GaussianFilter(const  IMGCH1<PIXUC1>& imageSource, IMGCH1<PIXUC1> &imageGaussian, float *gausArray, int size)
{


	//�˲�  
	for (int _row = 0; _row<imageSource.rows; _row++)
	{
		for (int _col = 0; _col<imageSource.cols; _col++)
		{
			int k = 0;
			for (int l = -size / 2; l <= size / 2; l++)
			{
				for (int g = -size / 2; g <= size / 2; g++)
				{
					//���´�������˲���ͼ��߽紦����Ϊ�����߽��ֵ��ֵΪ�߽�ֵ  
					int row = _row + l;
					int col = _col + g;
					row = row<0 ? 0 : row;
					row = row >= imageSource.rows ? imageSource.rows - 1 : row;
					col = col<0 ? 0 : col;
					col = col >= imageSource.cols ? imageSource.cols - 1 : col;
					//������  
					imageGaussian.dataPtr[_row*width + _col] += gausArray[k] * imageSource.dataPtr[row*width + col];
					k++;
				}
			}
		}
	}
}
//******************Sobel���Ӽ���X��Y�����ݶȺ��ݶȷ����********************  

void MyCanny::SobelGradDirection(const IMGCH1<PIXUC1>& imageSource, IMGCH1<PIXUC1>&SobelAmpXY, char *pointDrection)
{
	for (int i = 0; i<(imageSource.rows - 1)*(imageSource.cols - 1); i++)
	{
		pointDrection[i] = 0;
	}
	IMGCH1<PIXFC1> imageSobelX(height, width, PIXFC1(0));
	IMGCH1<PIXFC1> imageSobelY(height, width, PIXFC1(0));
	PIXUC1 *P = imageSource.dataPtr;
	PIXFC1 *PX = imageSobelX.dataPtr;
	PIXFC1 *PY = imageSobelY.dataPtr;

	int k = 0;


	for (int row = 1; row<(imageSource.rows - 1); row++)
	{
		for (int col = 1; col<(imageSource.cols - 1); col++)
		{


			pointDrection[k] = -1;

			//ͨ��ָ�����ͼ����ÿһ������   
			int gradY = P[(row - 1)*width + col + 1] + P[row*width + col + 1] * 2 + P[(row + 1)*width + col + 1] - P[(row - 1)*width + col - 1] - P[row*width + col - 1] * 2 - P[(row + 1)*width + col - 1];
			PY[row*width + col] = abs(gradY);

			int gradX = P[(row + 1)*width + col - 1] + P[(row + 1)*width + col] * 2 + P[(row + 1)*width + col + 1] - P[(row - 1)*width + col - 1] - P[(row - 1)*width + col] * 2 - P[(row - 1)*width + col + 1];
			PX[row*width + col] = abs(gradX);

			if (gradX == 0)
			{
				gradX = 0.01;  //��ֹ����Ϊ0�쳣  
			}

			float gradDrection = atan2(gradY, gradX)*57.3;//����ת��Ϊ��  

			if (gradDrection <= -67.5&&gradDrection <= -112.5 || gradDrection >= 67.5&&gradDrection <= -112.5)
				pointDrection[k] = 90;
			else if (gradDrection >= 22.5&&gradDrection<67.5 || gradDrection >= -157.5&&gradDrection<-112.5)
				pointDrection[k] = 45;
			else if (gradDrection >= -67.5&&gradDrection<22.5 || gradDrection >= 112.5&&gradDrection<157.5)
				pointDrection[k] = -45;
			else
				pointDrection[k] = 0;

			k++;

		}
	}
	IMGCH1<PIXFC1> imageSobelXY(height, width, PIXFC1(0));


	for (int row = 0; row<imageSobelXY.rows; row++)
		for (int col = 0; col<imageSobelXY.cols; col++)
			imageSobelXY.dataPtr[row*width + col] = sqrt(imageSobelX.dataPtr[row*width + col] * imageSobelX.dataPtr[row*width + col] + imageSobelY.dataPtr[row*width + col] * imageSobelY.dataPtr[row*width + col]);


	ToUchar(imageSobelXY, SobelAmpXY);
}

//******************�ֲ�����ֵ����*************************  


void MyCanny::LocalMaxValue(const  IMGCH1<PIXUC1> &imageInput, IMGCH1<PIXUC1> &imageOutput, char *pointDrection)
{

	for (int row = 0; row<height; row++)
		for (int col = 0; col<width; col++)
			imageOutput.dataPtr[row*width + col] = imageInput.dataPtr[row*width + col];
	int k = 0;

	for (int row = 1; row<imageInput.rows - 1; row++)
	{
		for (int col = 1; col<imageInput.cols - 1; col++)
		{
			int U = row - 1, D = row + 1, L = col - 1, R = col + 1;
			int value00 = imageInput.dataPtr[U*width + L];
			int value01 = imageInput.dataPtr[U*width + col];
			int value02 = imageInput.dataPtr[U*width + R];
			int value10 = imageInput.dataPtr[row*width + L];
			int value11 = imageInput.dataPtr[row*width + col];
			int value12 = imageInput.dataPtr[row*width + R];
			int value20 = imageInput.dataPtr[D*width + L];
			int value21 = imageInput.dataPtr[D*width + col];
			int value22 = imageInput.dataPtr[D*width + R];
			if (pointDrection[k] == 90)
			{
				if (value11 <= value01 || value11 <= value21)
					imageOutput.dataPtr[row*width + col] = 0;
			}
			else if (pointDrection[k] = 45)

			{
				if (value11 <= value20 || value11<value02)
					imageOutput.dataPtr[row*width + col] = 0;
			}
			else if (pointDrection[k] = -45)
			{
				if (value11 <= value00 || value11 <= value22)
					imageOutput.dataPtr[row*width + col] = 0;
			}
			else
			{
				if (value11 <= value10 || value11 <= value12)
					imageOutput.dataPtr[row*width + col] = 0;
			}
			k++;
		}
	}
}
//******************˫��ֵ����*************************  

void MyCanny::DoubleThreshold(IMGCH1<PIXUC1> &imageIput, int lowThreshold, int highThreshold)
{
	for (int row = 0; row<imageIput.rows; row++)
		for (int col = 0; col<imageIput.cols; col++)
		{
			if (imageIput.dataPtr[row*width + col]>highThreshold)
				imageIput.dataPtr[row*width + col] = 255;

			if (imageIput.dataPtr[row*width + col]<lowThreshold)
				imageIput.dataPtr[row*width + col] = 0;
		}
}
//******************˫��ֵ�м��������Ӵ���*********************  

void MyCanny::DoubleThresholdLink(IMGCH1<PIXUC1> &imageInput, IMGCH1<PIXUC1> &CannyImg, int lowThreshold)
{
	for (int row = 1; row<imageInput.rows - 1; row++)
		for (int col = 1; col<imageInput.cols - 1; col++)
		{
			if (imageInput.dataPtr[row*width + col] == 255)
				LinkEdge(imageInput, col, row, lowThreshold);

		}

	for (int row = 1; row<imageInput.rows; row++)
		for (int col = 1; col<imageInput.cols; col++)
		{
			if (imageInput.dataPtr[row*width + col] == 255)
				CannyImg.dataPtr[row*width + col] = 255;
		}
}

//******************�ݹ����ӱ�Ե*********************  
void MyCanny::LinkEdge(IMGCH1<PIXUC1> &imageInput, int x, int y, int lowThreshold)
{
	int nextpoint_x = -1;
	int nextpoint_y = -1;
	if (x<1 || x>width - 1 || y<1 || y>height - 1) return;
	if (imageInput.dataPtr[(y - 1)*width + x - 1] >= lowThreshold&& imageInput.dataPtr[(y - 1)*width + x - 1] != 255)
	{
		nextpoint_x = x - 1;
		nextpoint_y = y - 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[(y - 1)*width + x] >= lowThreshold&&imageInput.dataPtr[(y - 1)*width + x] != 255)
	{
		nextpoint_x = x;
		nextpoint_y = y - 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[(y - 1)*width + x + 1] >= lowThreshold&&imageInput.dataPtr[(y - 1)*width + x + 1] != 255)
	{
		nextpoint_x = x + 1;
		nextpoint_y = y - 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[y*width + x - 1] >= lowThreshold&&imageInput.dataPtr[y*width + x - 1] != 255)
	{
		nextpoint_x = x - 1;
		nextpoint_y = y;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[y*width + x + 1] >= lowThreshold&&imageInput.dataPtr[y*width + x + 1] != 255)
	{
		nextpoint_x = x + 1;
		nextpoint_y = y;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[(y + 1)*width + x - 1] >= lowThreshold&&imageInput.dataPtr[(y + 1)*width + x - 1] != 255)
	{
		nextpoint_x = x - 1;
		nextpoint_y = y + 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[(y + 1)*width + x] >= lowThreshold&& imageInput.dataPtr[(y + 1)*width + x] != 255)
	{
		nextpoint_x = x;
		nextpoint_y = y + 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
	else if (imageInput.dataPtr[(y + 1)*width + x + 1] >= lowThreshold&&imageInput.dataPtr[(y + 1)*width + x + 1] != 255)
	{
		nextpoint_x = x + 1;
		nextpoint_y = y + 1;
		imageInput.dataPtr[nextpoint_y*width + nextpoint_x] = 255;
		LinkEdge(imageInput, nextpoint_x, nextpoint_y, lowThreshold);
	}
}
void MyCanny::ToUchar(const IMGCH1<float> &floatImage, IMGCH1<PIXUC1> &imageUchar)
{

	for (int row = 0; row<floatImage.rows; row++)
		for (int col = 0; col<floatImage.cols; col++)
			imageUchar.dataPtr[row*width + col] = floatImage.dataPtr[row*width + col]>255 ? 255 : floatImage.dataPtr[row*width + col];
}
void MyCanny::SHOW(const IMGCH1<PIXUC1> &imageInput)
{
	Mat show = Mat::zeros(imageInput.rows, imageInput.cols, CV_8UC1);
	for (int row = 0; row<imageInput.rows; row++)
		for (int col = 0; col<imageInput.cols; col++)
		{

			show.at<uchar>(row, col) = imageInput.dataPtr[row*imageInput.cols + col];
		}
	imshow("canny", show);
	waitKey(0);
}


//hough�任
void hough()
{
	Mat image;
	Mat result;
	Mat img;
	Mat result_image;
	result_image = imread("1.jpg");
	image = imread("1.jpg", 0);
	threshold(image, result, 127, 255, THRESH_BINARY_INV);
	Canny(result, img, 50, 150, 3);
	int height = img.rows;
	int width = img.cols;
	int value;
	int(*p)[10000] = new int[180][10000]();
	//memset(value_list, 0, sizeof(value_list));
	int result_list[100][2] = { 0,0 };
	int a = 0;
	for (int i = 1; i< height; i++)
	{
		uchar* updata = img.ptr<uchar>(i);
		for (int j = 1; j<width; j++)
		{
			if (updata[j] != 0)
			{
				for (int m = 1; m<90; m++)
				{
					value = tan(m) * i + j;
					if (value > 0)
					{
						p[m][value] += 1;
					}
				}
			}
		}
	}
	for (int i = 0; i<180; i++)
	{
		for (int j = 0; j<10000; j++)
		{
			if (p[i][j]>100)
			{
				result_list[a][0] = i;
				result_list[a][1] = j;
				a++;
			}
		}
	}

	for (int i = 0; i<a; i++)
	{
		int theta = result_list[i][0];
		int b = result_list[i][1];
		int y1 = tan(theta) * 1 + b;
		int y2 = tan(theta) * 500 + b;
		Point p0 = Point(1, y1);
		Point p1 = Point(500, y2);
		line(img, p0, p1, cv::Scalar(255), 3, 4);
	}
	imshow("hough",img);
}

//�̶���ֵ
void stable(Mat src, Mat dst, double num)
{
	dst = src;
	int i, j;
	for (i = 0; i < src.rows; i++)
	{
		uchar * prr = src.ptr<uchar>(i);
		uchar * prrt = dst.ptr<uchar>(i);
		for (j = 0; j < src.cols; j++)
		{
			//printf("%d ", prr[j]);
			if (prr[j] < num)
			{
				prrt[j] = 0;
			}
			else
				prrt[j] = 255;
		}
	}
	namedWindow("�̶���ֵ", 0);
	imshow("�̶���ֵ", dst);
	waitKey(0);
}

int main()
{
	Mat image = imread("1.jpg", 0);
	if (image.empty())
	{
		printf("NO PICTURE!");
		return 0;
	}

	//�̶���ֵ
	Mat res;
	stable(image, res, 125.00);

	/*//������ֵ
	Mat result = IterationThreshold(image);
	imshow("������ֵ", result);

	//sobel����
	Mat dst1 = Sobel(image, 1, 0, 3, BORDER_DEFAULT);
	Mat dst2 = Sobel(image, 0, 1, 3, BORDER_DEFAULT);
	//ת8λ�Ҷ�ͼ��ʾ
	convertScaleAbs(dst1, dst1);
	convertScaleAbs(dst2, dst2);
	imshow("ԭͼ", image);
	imshow("sobelresult-X", dst1);
	imshow("sobelresult-Y", dst2);
	

	//canny����
	IMGCH1<PIXUC1> src_(image.rows, image.cols, PIXUC1(0));
	for (int row = 0; row<image.rows; row++)
		for (int col = 0; col<image.cols; col++)
			src_.dataPtr[row*image.cols + col] = image.at<uchar>(row, col);

	Mat Cannyedge = Mat::zeros(image.rows, image.cols, CV_8UC1);
	IMGCH1<PIXUC1> Cannyedge_(image.rows, image.cols, PIXUC1(0));
	MyCanny MyCanny_;
	MyCanny_(src_, Cannyedge_, 10, 100, 3);//���
	//ת����Mat��ʾ	
	for (int row = 0; row<src_.rows; row++)
		for (int col = 0; col<src_.cols; col++)
			Cannyedge.at<uchar>(row, col) = Cannyedge_.dataPtr[row*image.cols + col];
	imshow("Cannyedge ", Cannyedge);

	//hough�任
	hough();
	waitKey(0);*/
	return 0;
}