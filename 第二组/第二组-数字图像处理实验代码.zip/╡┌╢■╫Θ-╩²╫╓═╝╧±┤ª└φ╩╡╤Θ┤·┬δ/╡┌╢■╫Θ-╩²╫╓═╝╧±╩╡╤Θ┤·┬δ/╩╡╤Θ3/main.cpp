#include <iostream>
#include <opencv2/opencv.hpp>
#include <vector>


using namespace std;
using namespace cv;

#define TWO_PI 6.2831853071795864769252866



//ֱ��ͼ����
Mat getHistImage(int *hist)
{
	int num = 256;
	double maxValue = 0;
	double minValue = 0;
	int a = 0;
	Mat histImage(256, 256, CV_8UC3, Scalar(255, 255, 255));
	for (int i = 0; i < num; i++)
	{
		if (maxValue < hist[i])
		{
			maxValue = hist[i];
		}
	}
	int hpt = static_cast<int>(0.9*num);
	int total = 0;
	Scalar color(172, 172, 150);//BGR
	for (int h = 0; h < num; h++)
	{
		float binVal = hist[h];//��ȡ��Ӧ�Ҷȼ������ظ���,һ��1000000��
		total += binVal;
		int intensity = static_cast<int>(binVal*hpt / maxValue);//���������㣬��ǰ��Ŀ*hpt/�����Ŀ,���������ֻ�Ǳ�����ͬ
		line(histImage, Point(h, num), Point(h, num - intensity), color);
	}
	return histImage;
}

//��������
void Stretch(Mat img)
{
	unsigned char Max_Grey = 0, Min_Grey = 255;
	uchar * ptrj;
	float fInter;
	for (int i = 0; i < img.rows; i++)
	{
		ptrj = img.ptr<uchar>(i);
		for (int j = 0; j < img.cols; j++)
		{
				Max_Grey = Max_Grey>ptrj[j] ? Max_Grey : ptrj[j];
				Min_Grey = Min_Grey<ptrj[j] ? Min_Grey : ptrj[j];
		}
	}
	fInter = 255.0 / (float)(Max_Grey - Min_Grey);
	for (int i = 0; i<img.rows; i++)
	{
		ptrj = img.ptr<uchar>(i);
		for (int j = 0; j < img.cols; j++)
		{
			ptrj[j] = fInter * (ptrj[j] - Min_Grey);
		}		
	}
	//ͳ��ֱ��ͼ
	int lashen[256] = { 0 };
	for (int i = 1; i < img.rows; ++i)
	{
		const uchar* ptrr = img.ptr<uchar>(i);
		for (int j = 0; j < img.cols; ++j) 
		{
			lashen[ptrr[j]]++;
		}
	}
	Mat result = getHistImage(lashen);
	imshow("����", result);
}

//ֱ��ͼ����
void junheng(cv::Mat& src, cv::Mat& dst) 
{
	CV_Assert(src.depth() == CV_8U);
	src.copyTo(dst);
	int nr = src.rows;
	int nc = src.cols;
	int pixnum = nr*nc;
	if (src.channels() == 1) 
	{
		//ͳ��ֱ��ͼ
		int gray[256] = { 0 };
		for (int i = 1; i < nr; ++i) 
		{
			const uchar* ptr = src.ptr<uchar>(i);
			for (int j = 0; j < nc; ++j) {
				gray[ptr[j]]++;
			}
		}
		//����ֲ�����
		int LUT[256];
		int sum = 0;
		for (int k = 0; k < 256; k++) 
		{
			sum = sum + gray[k];
			LUT[k] = 255 * sum / pixnum;
		}

		Mat LUT_I;
		LUT_I = getHistImage(gray);
		imshow("ֱ��ͼ", LUT_I);
		//�Ҷȱ任����ֵ��
		for (int i = 1; i < nr; ++i) 
		{
			const uchar* ptr_src = src.ptr<uchar>(i);
			uchar* ptr_dst = dst.ptr<uchar>(i);
			for (int j = 0; j < nc; ++j) 
			{
				ptr_dst[j] = LUT[ptr_src[j]];
			}
		}
		//ͳ��ֱ��ͼ
		int res[256] = { 0 };
		for (int i = 1; i < nr; ++i)
		{
			const uchar* ptrr = dst.ptr<uchar>(i);
			for (int j = 0; j < nc; ++j) {
				res[ptrr[j]]++;
			}
		}
		Mat result = getHistImage(res);
		imshow("�任��", result);
	}
	else 
	{
		//ͳ��ֱ��ͼ
		int B[256] = { 0 };
		int G[256] = { 0 };
		int R[256] = { 0 };
		for (int i = 0; i < nr; ++i) {
			for (int j = 0; j < nc; ++j) {
				B[src.at<cv::Vec3b>(i, j)[0]]++;
				G[src.at<cv::Vec3b>(i, j)[1]]++;
				R[src.at<cv::Vec3b>(i, j)[2]]++;
			}
		}
		//����ֲ�����
		int LUT_B[256], LUT_G[256], LUT_R[256];
		int sum_B = 0, sum_G = 0, sum_R = 0;
		for (int k = 0; k < 256; k++) {
			sum_B = sum_B + B[k];
			sum_G = sum_G + G[k];
			sum_R = sum_R + R[k];
			LUT_B[k] = 255 * sum_B / pixnum;
			LUT_G[k] = 255 * sum_G / pixnum;
			LUT_R[k] = 255 * sum_R / pixnum;
		}
		cv::Mat B_I,G_I,R_I;
		B_I = getHistImage(B);
		imshow("Bͨ��", B_I);
		G_I = getHistImage(G);
		imshow("Gͨ��", G_I);
		R_I = getHistImage(R);
		imshow("Rͨ��", R_I);
		//�Ҷȱ任����ֵ�����������죩
		for (int i = 0; i < nr; ++i) {
			for (int j = 0; j < nc; ++j) {
				dst.at<cv::Vec3b>(i, j)[0] = LUT_B[src.at<cv::Vec3b>(i, j)[0]];
				dst.at<cv::Vec3b>(i, j)[1] = LUT_G[src.at<cv::Vec3b>(i, j)[1]];
				dst.at<cv::Vec3b>(i, j)[2] = LUT_R[src.at<cv::Vec3b>(i, j)[2]];
			}
		}
	}
}




//��ͼ��Ӹ�˹����
double generateGaussianNoise()
{
	static bool hasSpare = false;
	static double rand1, rand2;

	if (hasSpare)
	{
		hasSpare = false;
		return sqrt(rand1) * sin(rand2);
	}

	hasSpare = true;

	rand1 = rand() / ((double)RAND_MAX);
	if (rand1 < 1e-100) rand1 = 1e-100;
	rand1 = -2 * log(rand1);
	rand2 = (rand() / ((double)RAND_MAX)) * TWO_PI;

	return sqrt(rand1) * cos(rand2);
}

static void AddGaussianNoise(Mat& image)
{
	CV_Assert(image.depth() != sizeof(uchar));
	int channels = image.channels();
	int nRows = image.rows;
	int nCols = image.cols * channels;
	if (image.isContinuous()) {
		nCols *= nRows;
		nRows = 1;
	}
	int i, j;
	uchar* p;
	for (i = 0; i < nRows; ++i) {
		p = image.ptr<uchar>(i);
		for (j = 0; j < nCols; ++j) {
			double val = p[j] + generateGaussianNoise() * 128;
			if (val < 0)
				val = 0;
			if (val > 255)
				val = 255;
			p[j] = (uchar)val;
		}
	}
}


//��ͼ��ӽ�������
static void salt(cv::Mat &image, int n)
{
	int i, j;
	for (int k = 0; k < n; k++)   //��������salt noise��
	{
		i = rand() % image.cols;
		j = rand() % image.rows;
		if (image.channels() == 1)
			image.at<uchar>(j, i) = 255;
		else if (image.channels() == 3)
		{
			image.at<cv::Vec3b>(j, i)[0] = 255;
			image.at<cv::Vec3b>(j, i)[1] = 255;
			image.at<cv::Vec3b>(j, i)[2] = 255;
		}
	}
	for (int k = 0; k < n; k++)  //����������pepper noise��
	{
		i = rand() % image.cols;
		j = rand() % image.rows;
		if (image.channels() == 1)
			image.at<uchar>(j, i) = 0;
		else if (image.channels() == 3)
		{
			image.at<cv::Vec3b>(j, i)[0] = 0;
			image.at<cv::Vec3b>(j, i)[1] = 0;
			image.at<cv::Vec3b>(j, i)[2] = 0;
		}
	}
}


//����ȥ�루��ֵ�˲���
//�����㷨-ð������
void bublle_sort(std::vector<int> &arr)
{
	bool flag = true;
	for (int i = 0; i < arr.size() - 1; ++i) 
	{
		while (flag) 
		{
			flag = false;
			for (int j = 0; j < arr.size() - 1 - i; ++j)
			{
				if (arr[j]>arr[j + 1]) 
				{
					int tmp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = tmp;
					flag = true;
				}
			}
		}
	}
}


//��ֵ�˲�
void MedianFilter(cv::Mat& src, cv::Mat& dst, cv::Size wsize) 
{
	//ͼ��߽�����
	if (wsize.width % 2 == 0 || wsize.height % 2 == 0) 
	{
		fprintf(stderr, "Please enter odd size!");
		exit(-1);
	}
	int hh = (wsize.height - 1) / 2;
	int hw = (wsize.width - 1) / 2;
	cv::Mat Newsrc;
	cv::copyMakeBorder(src, Newsrc, hh, hh, hw, hw, cv::BORDER_REFLECT_101);//�Ա�ԵΪ�ᣬ�Գ�
	dst = cv::Mat::zeros(src.rows, src.cols, src.type());

	//��ֵ�˲�
	for (int i = hh; i < src.rows + hh; ++i) 
	{
		uchar* ptrdst = dst.ptr(i - hh);
		for (int j = hw; j < src.cols + hw; ++j) 
		{
			std::vector<int> pix;
			for (int r = i - hh; r <= i + hh; ++r) 
			{
				const uchar* ptrsrc = Newsrc.ptr(r);
				for (int c = j - hw; c <= j + hw; ++c) 
				{
					pix.push_back(ptrsrc[c]);
				}
			}
			bublle_sort(pix);//ð������
			ptrdst[j - hw] = pix[(wsize.area()-1)/2];//����ֵӳ�䵽���ͼ��
		}
	}
}




//�������ʵ�ָ�˹�˲������Ӹ�Ч
//�ҽ�С����ô���ɵ�ģ�������ϵ���ϴ󣬶���Χ��ϵ����С��������ͼ���ƽ��Ч���Ͳ��Ǻ����ԣ�
//��֮���ҽϴ������ɵ�ģ��ĸ���ϵ�����Ͳ��Ǻܴ󣬱Ƚ����ƾ�ֵģ�壬��ͼ���ƽ��Ч���Ƚ����ԡ�
void separateGaussianFilter(cv::Mat& src, cv::Mat& dst, int wsize, double sigma) 
{
	//��ȡһά��˹�˲�ģ��
	cv::Mat window;
	window.create(1, wsize, CV_64F);
	int center = (wsize - 1) / 2;
	double sum = 0.0;
	for (int i = 0; i < wsize; ++i) 
	{
		double g = exp(-(pow(i - center, 2)) / (2 * sigma*sigma));
		window.at<double>(0, i) = g;
		sum += g;
	}
	window = window / sum;
	//std::cout << window << std::endl;

	//�߽����
	int boder = (wsize - 1) / 2;
	dst = cv::Mat::zeros(src.size(), src.type());
	cv::Mat Newsrc;
	cv::copyMakeBorder(src, Newsrc, boder, boder, boder, boder, cv::BORDER_REPLICATE);//�߽縴��

																					  //��˹�˲�--ˮƽ����
	for (int i = boder; i < src.rows + boder; ++i) 
	{
		for (int j = boder; j < src.cols + boder; ++j) 
		{
			double sum[3] = { 0 };

			for (int r = -boder; r <= boder; ++r) 
			{
				if (src.channels() == 1) 
				{
					sum[0] = sum[0] + Newsrc.at<uchar>(i, j + r) * window.at<double>(0, r + boder); //�в����б�
				}
				else if (src.channels() == 3) 
				{
					cv::Vec3b rgb = Newsrc.at<cv::Vec3b>(i, j + r);
					sum[0] = sum[0] + rgb[0] * window.at<double>(0, r + boder);//B
					sum[1] = sum[1] + rgb[1] * window.at<double>(0, r + boder);//G
					sum[2] = sum[2] + rgb[2] * window.at<double>(0, r + boder);//R
				}
			}
			for (int k = 0; k < src.channels(); ++k) 
			{
				if (sum[k] < 0)
					sum[k] = 0;
				else if (sum[k]>255)
					sum[k] = 255;
			}
			if (src.channels() == 1) 
			{
				dst.at<uchar>(i - boder, j - boder) = static_cast<uchar>(sum[0]);
			}
			else if (src.channels() == 3) 
			{
				cv::Vec3b rgb = { static_cast<uchar>(sum[0]), static_cast<uchar>(sum[1]), static_cast<uchar>(sum[2]) };
				dst.at<cv::Vec3b>(i - boder, j - boder) = rgb;
			}
		}
	}

	//��˹�˲�--��ֱ����
	//��ˮƽ���������dst�߽����
	cv::copyMakeBorder(dst, Newsrc, boder, boder, boder, boder, cv::BORDER_REPLICATE);//�߽縴��
	for (int i = boder; i < src.rows + boder; ++i) {
		for (int j = boder; j < src.cols + boder; ++j) {
			double sum[3] = { 0 };

			for (int r = -boder; r <= boder; ++r) {
				if (src.channels() == 1) {
					sum[0] = sum[0] + Newsrc.at<uchar>(i + r, j) * window.at<double>(0, r + boder); //�в����б�
				}
				else if (src.channels() == 3) {
					cv::Vec3b rgb = Newsrc.at<cv::Vec3b>(i + r, j);
					sum[0] = sum[0] + rgb[0] * window.at<double>(0, r + boder);//B
					sum[1] = sum[1] + rgb[1] * window.at<double>(0, r + boder);//G
					sum[2] = sum[2] + rgb[2] * window.at<double>(0, r + boder);//R
				}
			}
			for (int k = 0; k < src.channels(); ++k) {
				if (sum[k] < 0)
					sum[k] = 0;
				else if (sum[k]>255)
					sum[k] = 255;
			}
			if (src.channels() == 1) {
				dst.at<uchar>(i - boder, j - boder) = static_cast<uchar>(sum[0]);
			}
			else if (src.channels() == 3) {
				cv::Vec3b rgb = { static_cast<uchar>(sum[0]), static_cast<uchar>(sum[1]), static_cast<uchar>(sum[2]) };
				dst.at<cv::Vec3b>(i - boder, j - boder) = rgb;
			}
		}
	}
}

int main()
{
	Mat src = imread("1.jpg", 0);
	//IplImage* image = cvLoadImage("D:/timg.jpg");
	int a = src.channels();//a = 3ͨ��
	imshow("ԭͼ", src);
	if (!src.data)
	{
		cout << "no picture!\n";
		exit(1);
	}

	//ֱ��ͼ���ƣ�ֱ��ͼ����
	Mat result;
	junheng(src, result);
	imshow("�����", result);

	//��˹�˲�
	/*AddGaussianNoise(src);
	Mat gauss_result;
	separateGaussianFilter(src, gauss_result, 7, 7);
	imshow("�����˹����", src);
	imshow("ȥ��", gauss_result);*/

	//��ֵ�˲�
	/*cv::Size wsize(3, 3);
	salt(src, 3000);
	imshow("���뽷������", src);
	Mat zhongzhi_result;
	MedianFilter(src, zhongzhi_result, wsize);
	imshow("ȥ��", zhongzhi_result);*/

	Stretch(src);
	imshow("��������", src);

	waitKey(0);
	return 0;
}