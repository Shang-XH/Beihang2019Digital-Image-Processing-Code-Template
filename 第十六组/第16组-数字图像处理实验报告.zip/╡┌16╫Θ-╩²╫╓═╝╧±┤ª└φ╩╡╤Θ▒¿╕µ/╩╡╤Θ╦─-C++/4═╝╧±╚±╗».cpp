﻿#include<iostream>
#include<fstream>
#include<Windows.h>
#include<math.h>

using namespace std;
char fileName[50];
char SaveName[50];
char Save2Name[50];
unsigned char *pBmpBuf; //读入图像指针
unsigned char *pcolorbuf;
int bmpWidth;
int bmpHeight;
RGBQUAD *pColorTable; //灰颜色表指针
int biBitCount; //每像素位数 8灰24彩

#define PI 3.1415926536

bool readBmp(char *bmpName) {
	FILE *fp = fopen(bmpName, "rb");       //二进制读的方式打开文件
	if (fp == 0) {
		cout << "文件未找到！";
		return 0;
	}
	fseek(fp, sizeof(BITMAPFILEHEADER), 0); //跳过头文件
	BITMAPINFOHEADER head;
	fread(&head, sizeof(BITMAPINFOHEADER), 1, fp); //读取宽 高 位数
	bmpWidth = head.biWidth;
	bmpHeight = head.biHeight;
	biBitCount = head.biBitCount;
	int lineByte = (bmpWidth*biBitCount / 8 + 3) / 4 * 4; //补全每一行为4的倍数
	if (biBitCount == 8) {
		pColorTable = new RGBQUAD[256];
		fread(pColorTable, sizeof(RGBQUAD), 256, fp);
	} //8位灰度图有颜色表 申请空间 读颜色表进内存
	int bb = biBitCount / 8;
	pBmpBuf = new unsigned char[lineByte * bmpHeight*bb];
	for (int i = 0; i < bmpHeight; i++)
	{
		fread(pBmpBuf + i * bmpWidth*bb, bmpWidth*bb, 1, fp);
		fseek(fp, lineByte - bmpWidth * bb, 1);
	}
	return 1;
}

bool saveBmp(unsigned char *bmpName) {
	if (!bmpName) {
		return 0;
	} //位图数据指针为0 则无数据传入 使用失败
	int colorTablesize = 0;
	if (biBitCount == 8) {
		colorTablesize = 1024;
	} //判断是否为8位灰
	for (int i = 0; i < bmpHeight*bmpWidth; i++)
		*(bmpName + i) = *(pBmpBuf + i);
	cout << "width=" << bmpWidth << " height=" << bmpHeight;
	cout << "请输入要存入文件的路径：(如：e:\\\\1.bmp)";
	cin >> SaveName;
	int lineByte = (bmpWidth*biBitCount / 8 + 3) / 4 * 4;
	FILE *fp = NULL;
	fp = fopen(SaveName, "wb");//二进制写的方式打开
	if (fp == 0) {
		cout << "路径错误！";
		return 0;
	} //打开失败 退出
	BITMAPFILEHEADER fileHead; //申请位图文件头结构变量 填写文件头信息
	fileHead.bfType = 0x4D42; //bmp类型
	fileHead.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + colorTablesize + lineByte * bmpHeight;
	fileHead.bfReserved1 = 0;
	fileHead.bfReserved2 = 0;
	fileHead.bfOffBits = 54 + colorTablesize;
	fwrite(&fileHead, sizeof(BITMAPFILEHEADER), 1, fp); //写入头文件
	BITMAPINFOHEADER head;
	head.biBitCount = 8;
	head.biClrImportant = 0;
	head.biClrUsed = 0;
	head.biCompression = 0;
	head.biHeight = bmpHeight;
	head.biPlanes = 1;
	head.biSize = 40;
	head.biSizeImage = lineByte * bmpHeight;
	head.biWidth = bmpWidth;
	head.biXPelsPerMeter = 0;
	head.biYPelsPerMeter = 0;
	fwrite(&head, sizeof(BITMAPINFOHEADER), 1, fp);//写入头文件
	if (biBitCount == 8) {
		fwrite(pColorTable, sizeof(RGBQUAD), 256, fp);
	} //灰 颜色表写入
	unsigned char *buf = new unsigned char[bmpHeight*lineByte];
	int b = biBitCount / 8;
	for (int i = 0; i < bmpHeight; i++)
	{
		for (int j = 0; j < bmpWidth*b; j++)
			*(buf + i * lineByte + j) = *(bmpName + i * bmpWidth*b + j);
	}
	fwrite(buf, bmpHeight*lineByte, 1, fp);
	delete[]buf;//写位图数据
	fclose(fp);
	return 1; //写入成功
}

bool saveg2cBmp(unsigned char *bmpName) {
	if (!bmpName) {
		return 0;
	} //位图数据指针为0 则无数据传入 使用失败
	int colorTablesize = 0;
	for (int i = 0; i < bmpHeight*bmpWidth * 3; i++)
		*(bmpName + i) = *(pcolorbuf + i);
	cout << "width=" << bmpWidth << " height=" << bmpHeight;
	cout << "请输入要存入文件的路径：(如：e:\\\\1.bmp)";
	cin >> SaveName;
	int lineByte = (bmpWidth * 3 + 3) / 4 * 4;
	FILE *fp = NULL;
	fp = fopen(SaveName, "wb");//二进制写的方式打开
	if (fp == 0) {
		cout << "路径错误！";
		return 0;
	} //打开失败 退出
	BITMAPFILEHEADER fileHead; //申请位图文件头结构变量 填写文件头信息
	fileHead.bfType = 0x4D42; //bmp类型
	fileHead.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + colorTablesize + lineByte * bmpHeight;
	fileHead.bfReserved1 = 0;
	fileHead.bfReserved2 = 0;
	fileHead.bfOffBits = 54 + colorTablesize;
	fwrite(&fileHead, sizeof(BITMAPFILEHEADER), 1, fp); //写入头文件
	BITMAPINFOHEADER head;
	head.biBitCount = 24;
	head.biClrImportant = 0;
	head.biClrUsed = 0;
	head.biCompression = 0;
	head.biHeight = bmpHeight;
	head.biPlanes = 1;
	head.biSize = 40;
	head.biSizeImage = lineByte * bmpHeight;
	head.biWidth = bmpWidth;
	head.biXPelsPerMeter = 0;
	head.biYPelsPerMeter = 0;
	fwrite(&head, sizeof(BITMAPINFOHEADER), 1, fp);//写入头文件
	unsigned char *buf = new unsigned char[bmpHeight*lineByte];
	for (int i = 0; i < bmpHeight; i++)
	{
		for (int j = 0; j < bmpWidth * 3; j++)
			*(buf + i * lineByte + j) = *(bmpName + i * bmpWidth * 3 + j);
	}
	fwrite(buf, bmpHeight*lineByte, 1, fp);
	delete[]buf;//写位图数据
	fclose(fp);
	return 1; //写入成功
}

//拉普拉斯算子锐化

void HPFSharpen() {
	int H1[3][3] = { {0,-1,0},{-1,5,-1},{0,-1,0} };
	int H2[3][3] = { {-1,-1,-1},{-1,9,-1},{-1,-1,-1} };
	int H3[3][3] = { {1,-2,1},{-2,5,-2},{1,-2,1} };
	int H47[3][3] = { {-1,-2,-1},{-2,19,-2},{-1,-2,-1} };//使用除7
	int H52[3][3] = { {-2,1,-2},{1,6,1},{-2,1,-2} };//使用除2
	cout << "确定使用的模板 (12345)" << endl;
	int r; cin >> r;
	for (int i = 0; i < bmpHeight; i++) {
		for (int j = 0; j < bmpWidth; j++) {
			float temp = 0;//用来计算新的中心像素点值
			//高通卷积模板
			for (int k = 0; k < 3; k++) {
				for (int l = 0; l < 3; l++) {
					//当算子位于边缘区域时，排除图像中不存在的点
					if ((i - 1 + k < 0) || (j - 1 + l < 0) || (i - 1 + k >= bmpHeight) || (j - 1 + l >= bmpWidth))
						continue;
					if (r == 1)  temp += H1[k][l] * pBmpBuf[(i - 1 + k)*bmpWidth + j - l + 1];
					else if (r == 2)  temp += H2[k][l] * pBmpBuf[(i - 1 + k)*bmpWidth + j - l + 1];
					else if (r == 3)  temp += H3[k][l] * pBmpBuf[(i - 1 + k)*bmpWidth + j - l + 1];
					else if (r == 4)  temp += H47[k][l] * pBmpBuf[(i - 1 + k)*bmpWidth + j - l + 1] * (float)1 / 7;
					else if (r == 5)  temp += H52[k][l] * pBmpBuf[(i - 1 + k)*bmpWidth + j - l + 1] * (float)1 / 2;
				}
			}
			//当计算结果超出255，就把它置为255
			if (temp > 255) {
				temp = 255;
			}
			//当计算结果小于0，就把它置为0
			if (temp < 0) {
				temp = 0;
			}
			pBmpBuf[i*bmpWidth + j] = (int)temp;
		}
	}
}

void HSI() {
	int Hvalue, Svalue, Ivalue;
	double H, S, I;
	int lineByte = bmpWidth * 3;
	pcolorbuf = new unsigned char[bmpHeight*bmpWidth * 3];
	for (int i = 0; i < bmpHeight; i++) {
		for (int j = 0; j < bmpWidth; j++)
		{
			int Bvalue = pBmpBuf[i*lineByte + 3 * j];
			int Gvalue = pBmpBuf[i*lineByte + 3 * j + 1];
			int Rvalue = pBmpBuf[i*lineByte + 3 * j + 2];
			//求Theta =acos((((Rvalue - Gvalue) + (Rvalue - Bvalue)) / 2) / sqrt(pow((Rvalue - Gvalue), 2) + (Rvalue - Bvalue)*                           //(Gvalue - Bvalue)));
			double numerator = ((Rvalue - Gvalue) + (Rvalue - Bvalue)) / 2;
			double denominator = sqrt(pow((Rvalue - Gvalue), 2) + (Rvalue - Bvalue)*(Gvalue - Bvalue));
			if (denominator == 0) {
				H = 0;
			}
			else {
				double Theta = acos(numerator / denominator) * 180 / 3.14;
				if (Bvalue <= Gvalue)
					H = Theta;
				else {
					H = 360 - Theta;
				}
			}
			Hvalue = (int)(H * 255 / 360); //为了显示将[0~360]映射到[0~255]

			//求S = 1-3*min(Bvalue,Gvalue,Rvalue)/(Rvalue+Gvalue+Bvalue);
			int minvalue = Bvalue;
			if (minvalue > Gvalue) minvalue = Gvalue;
			if (minvalue > Rvalue) minvalue = Rvalue;
			numerator = 3 * minvalue;
			denominator = Rvalue + Gvalue + Bvalue;
			if (denominator == 0) {
				S = 0;
			}
			else {
				S = 1 - numerator / denominator;
			}
			Svalue = (int)(S * 255);//为了显示将[0~1]映射到[0~255]

			I = (Rvalue + Gvalue + Bvalue) / 3;
			Ivalue = (int)(I);
			*(pcolorbuf + i * lineByte + 3 * j) = Hvalue;
			*(pcolorbuf + i * lineByte + 3 * j + 1) = Svalue;
			*(pcolorbuf + i * lineByte + 3 * j + 2) = Ivalue;
		}
	}
}

void color() {
	if (biBitCount == 24) {
		cout << "不需转化，886" << endl;
	}
	int lineByte = bmpWidth * 3;
	pcolorbuf = new unsigned char[bmpHeight*lineByte];
	int R, G, B;
	for (int i = 0; i < bmpHeight; i++)
	{
		for (int j = 0; j < bmpWidth; j++)
		{
			int current = pBmpBuf[i*bmpWidth + j];
			if (0 < current && current <= 64)
			{
				R = 0;
				G = 4 * current;
				B = 255;
			}
			else if (64 < current && current <= 128)
			{
				R = 0;
				G = 255;
				B = (-4)*(current - 128);
			}
			else if (128 < current && current <= 192)
			{
				R = 4 * (current - 128);
				G = 255;
				B = 0;
			}
			else
			{
				R = 255;
				G = (-4)*(current - 255);
				B = 0;
			}
			*(pcolorbuf + i * lineByte + 3 * j) = R;
			*(pcolorbuf + i * lineByte + 3 * j + 1) = G;
			*(pcolorbuf + i * lineByte + 3 * j + 2) = B;
		}
	}
}

int main() {
	cout << "请输入要打开文件的路径：(如：D:\\\\1.bmp）" << endl;
	cin >> fileName;
	readBmp(fileName);
	char c;
	cout << "选择锐化方式 F(HPF) H(转hsi) W(伪彩色)" << endl;
	cin >> c;
	if (c == 'F') {
		HPFSharpen();
		unsigned char *wBmpBuf;
		wBmpBuf = new unsigned char[bmpHeight * bmpWidth];
		saveBmp(wBmpBuf);
		delete[]wBmpBuf;
	}
	else if (c == 'H') {
		HSI();
		unsigned char *wBmpBuf;
		wBmpBuf = new unsigned char[bmpHeight * bmpWidth * 3];
		saveg2cBmp(wBmpBuf);
		delete[]wBmpBuf;
	}
	else if (c == 'W') {
		color();
		unsigned char *wBmpBuf;
		wBmpBuf = new unsigned char[bmpHeight * bmpWidth * 3];
		saveg2cBmp(wBmpBuf);
		delete[]wBmpBuf;
	}
	system("pause");
	return 0;

}