#include<iostream>
#include<Windows.h>
#include<fstream>
#include<math.h>


using namespace std;

#define intsize sizeof(int)
#define complexsize sizeof(complex)
#define PI 3.1415926
char fileName[50];
char SaveName[50];
unsigned char *pBmpBuf; //����ͼ��ָ��
int bmpWidth;
int bmpHeight;
RGBQUAD *pColorTable; //����ɫ��ָ��
int biBitCount; //ÿ����λ�� 8��24��
int *a, *b;
int nlen;
int mlen;
FILE *dataFile;

//����ṹ�� ����
typedef struct {
	float real;
	float image;
}complex;
complex *A, *A_In, *B_In, *C_In, *D_In, *W, *T;

bool readBmp(char *bmpName) {
	FILE *fp = fopen(bmpName, "rb");       //�����ƶ��ķ�ʽ���ļ�
	if (fp == 0) {
		cout << "�ļ�δ�ҵ���";
		return 0;
	}
	fseek(fp, sizeof(BITMAPFILEHEADER), 0); //����ͷ�ļ�
	BITMAPINFOHEADER head;
	fread(&head, sizeof(BITMAPINFOHEADER), 1, fp); //��ȡ�� �� 
	bmpWidth = head.biWidth;
	bmpHeight = head.biHeight;
	pColorTable = new RGBQUAD[256];
	fread(pColorTable, sizeof(RGBQUAD), 256, fp);
	pBmpBuf = new unsigned char[bmpWidth * bmpHeight];
	for (int i = 0; i < bmpHeight; i++)
		fread(pBmpBuf + i * bmpWidth, bmpWidth, 1, fp);   //����λͼ��������ռ� �����ڴ�  ���� pbmpbuf
	fclose(fp);
	return 1;
}

bool saveBmp(unsigned char *bmpName) {
	cout << "width=" << bmpWidth << " height=" << bmpHeight;
	cout << "������Ҫ�����ļ���·����(�磺e:\\\\1.bmp)";
	cin >> SaveName;
	int colorTablesize = 0;
	colorTablesize = 1024;
	int lineByte = (bmpWidth + 3) / 4 * 4;
	FILE *fp = NULL;
	fp = fopen(SaveName, "wb");//������д�ķ�ʽ��
	if (fp == 0) {
		cout << "·������";
		return 0;
	} //��ʧ�� �˳�
	BITMAPFILEHEADER fileHead; //����λͼ�ļ�ͷ�ṹ���� ��д�ļ�ͷ��Ϣ
	fileHead.bfType = 0x4D42; //bmp����
	fileHead.bfSize = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) + colorTablesize + lineByte * bmpHeight;
	fileHead.bfReserved1 = 0;
	fileHead.bfReserved2 = 0;
	fileHead.bfOffBits = 54 + colorTablesize;
	fwrite(&fileHead, sizeof(BITMAPFILEHEADER), 1, fp); //д��ͷ�ļ�
	BITMAPINFOHEADER head;
	head.biBitCount = 8;
	head.biClrImportant = 0;
	head.biClrUsed = 0;
	head.biCompression = 0;
	head.biHeight = bmpHeight;
	head.biPlanes = 1;
	head.biSize = 40;
	head.biSizeImage = lineByte * bmpHeight;
	head.biWidth = bmpWidth;
	head.biXPelsPerMeter = 0;
	head.biYPelsPerMeter = 0;
	fwrite(&head, sizeof(BITMAPINFOHEADER), 1, fp);//д��ͷ�ļ�
	fwrite(pColorTable, sizeof(RGBQUAD), 256, fp);
	unsigned char *buf = new unsigned char[bmpHeight*lineByte];
	for (int i = 0; i < bmpHeight; i++)
	{
		for (int j = 0; j < bmpWidth; j++)
			*(buf + i * lineByte + j) = *(bmpName + i * nlen + j);
	}
	fwrite(buf, bmpHeight*lineByte, 1, fp);
	delete[]buf;//дλͼ����
	fclose(fp);
	return 1; //д��ɹ�
}
//��ȡͼ������ ����ƽ��/��ת�Ĵ���
void readData()
{
	int i, j;
	int mlen = bmpHeight;
	int nlen = bmpWidth;
	A_In = (complex *)malloc(complexsize*mlen*nlen);
	char a;
	cout << "ƽ�ƣ���ת�򲻴�����p x or n��" << endl;
	cin >> a;
	if (a == 'n') { //����
		for (i = 0; i < mlen; i++)
		{
			for (j = 0; j < nlen; j++)
			{
				A_In[i*nlen + j].real = pBmpBuf[i*nlen + j];
				A_In[i*nlen + j].image = 0.0;
			}
		}
	}
	else if (a == 'p') {  //ƽ��
		int H, W;
		cout << "������� " << endl;
		cout << "���£���Ϊ����" << endl;
		cin >> H;
		cout << "���ң���Ϊ����" << endl;
		cin >> W;
		for (i = 0; i < mlen; i++)
		{
			for (j = 0; j < nlen; j++)
			{
				if (((j + W) >= 0) && ((j + W) <= mlen) && ((i + H) >= 0) && ((i + H) <= nlen)) {
					A_In[i*nlen + j].real = pBmpBuf[(i + H)*nlen + j + W];
				}
				else {
					A_In[i*nlen + j].real = 0;
				}
				A_In[i*nlen + j].image = 0.0;
			}
		}
	}
	else if (a == 'x') {  //��ת
		cout << "��ת�Ƕ�(���� ��45 ��˳ʱ����ת45��)" << endl;
		float e;
		cin >> e;
		double rx0 = nlen * 0.5;  //(rx0,ry0)Ϊ��ת���� 
		double ry0 = mlen * 0.5;
		double ZoomX = 1.0, ZoomY = 1.0; //����ϵ��
		for (i = 0; i < mlen; i++)
		{
			for (j = 0; j < nlen; j++)
			{
				int srcj = (float)(j - rx0) / ZoomX * cos(e*PI / 180) - (float)(i - ry0) / ZoomY * sin(e*PI / 180) + rx0;
				int srci = (float)(j - rx0) / ZoomX * sin(e*PI / 180) + (float)(i - ry0) / ZoomY * cos(e*PI / 180) + ry0;
				if ((srcj >= 0) && (srcj <= mlen) && (srci >= 0) && (srci <= nlen)) {
					A_In[i*nlen + j].real = pBmpBuf[srci*nlen + srcj];
				}
				else {
					A_In[i*nlen + j].real = 0;
				}
			}
			A_In[i*nlen + j].image = 0.0;
		}
	}
}



bool getF(unsigned char *imgbuf)  //�õ���ֵ
{
	nlen = bmpWidth;
	mlen = bmpHeight;
	C_In = (complex *)malloc(complexsize*nlen*mlen);
	for (int i = 0; i < mlen; i++)
	{
		for (int j = 0; j < nlen; j++)
		{
			C_In[i*nlen + j].real = sqrt(pow(B_In[i*nlen + j].real, 2) + pow(B_In[i*nlen + j].image, 2));
		}
	}
	double min = C_In[0].real;
	for (int i = 0; i < mlen*nlen; i++)
	{
		if (C_In[i].real < min)
			min = C_In[i].real;
	}
	double maxqueue[20] = { 0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0.,0. }, max;
	for (int i = 0; i < mlen*nlen; i++)
	{
		if (C_In[i].real > maxqueue[0])
			maxqueue[0] = C_In[i].real;
	}
	for (int j = 1; j < 20; j++) {
		for (int i = 0; i < mlen*nlen; i++) {
			if (C_In[i].real > maxqueue[j] && C_In[i].real < maxqueue[j - 1])
				maxqueue[j] = C_In[i].real;
		}
	}
	max = maxqueue[19];
	unsigned char *normalized_data = new unsigned char[mlen*nlen];
	for (int i = 0; i < mlen; i++)
		for (int j = 0; j < nlen; j++)
		{
			unsigned char t = (unsigned char)((C_In[i*nlen + j].real - min) / (max - min) * 255);
			if (t > 255)
				t = 255;
			normalized_data[i*nlen + j] = t;
		}
	unsigned char* center_data = new unsigned char[mlen*nlen];
	for (int u = 0; u < mlen; u++)
	{
		for (int v = 0; v < nlen; v++) {
			if ((u < (mlen / 2)) && (v < (nlen / 2))) {
				center_data[v + u * nlen] = normalized_data[nlen / 2 + v + (mlen / 2 + u)*nlen];
			}
			else if ((u < (mlen / 2)) && (v >= (nlen / 2))) {
				center_data[v + u * nlen] = normalized_data[(v - nlen / 2) + (mlen / 2 + u)*nlen];
			}
			else if ((u >= (mlen / 2)) && (v < (nlen / 2))) {
				center_data[v + u * nlen] = normalized_data[(nlen / 2 + v) + (u - mlen / 2)*nlen];
			}
			else if ((u >= (mlen / 2)) && (v >= (nlen / 2))) {
				center_data[v + u * nlen] = normalized_data[(v - nlen / 2) + (u - mlen / 2)*nlen];
			}
		}
	}
	for (int i = 0; i < mlen*nlen; i++)
		*(imgbuf + i) = *(center_data + i);
	return 1;
}

void Fft() {
	nlen = bmpWidth;
	mlen = bmpHeight;
	B_In = (complex *)malloc(complexsize*mlen*nlen);
	W = (complex *)malloc(complexsize);
	T = (complex *)malloc(complexsize);
	int mi = 0;
	int w = 0, w2;
	for (mi = 0; w < nlen; mi++) {
		w = pow(2, mi + 1);
	}
	//�� ���ٸ���Ҷ
	for (int m = 0; m < mlen; m++) {
		for (int j = 0; j < nlen; j++)
		{
			w = 0;
			for (int i = 0; i < mi; i++)
			{
				if (j&(1 << i))//�жϵ�iλ�Ƿ�Ϊ1 &�������Ϊ��ĵĲ������ 1&1 = 0 1%0 = 0
				{
					w += 1 << (mi - i - 1); //����ȥ
				}
			}
			B_In[m*mlen + j] = A_In[m*mlen + w];
		}

	}
	for (int m = 0; m < mlen; m++) {
		for (int i = 0; i < mi; i++)//��һ��ѭ��k=log2N��������N = 8������k = 2
		{
			int step = 1 << (i + 1);
			int factor_step = nlen >> (i + 1);//��ת�����仯�ٶ�
			//��ʼ����ת����
			W[0].real = 1.0;
			W[0].image = 0.0;
			for (int j = 0; j < step / 2; j++)
			{
				for (w = j; w < nlen; w += step)
				{
					w2 = w + step / 2;//�����������������
					T[0].real = B_In[m*mlen + w2].real * W[0].real - B_In[m*mlen + w2].image * W[0].image;
					T[0].image = B_In[m*mlen + w2].real * W[0].image + B_In[m*mlen + w2].image *  W[0].real;
					B_In[m*mlen + w2].real = B_In[m*mlen + w].real - T[0].real;
					B_In[m*mlen + w2].image = B_In[m*mlen + w].image - T[0].image;
					B_In[m*mlen + w].real = B_In[m*mlen + w].real + T[0].real;
					B_In[m*mlen + w].image = B_In[m*mlen + w].image + T[0].image;
				}
				W[0].real = cos(-2 * PI* (j + 1)*factor_step / nlen);
				W[0].image = sin(-2 * PI* (j + 1)*factor_step / nlen);
			}
		}
	}
	for (int i = 0; i < mlen*nlen; i++) {
		A_In[i] = B_In[i];
	}
	//�� ���ٸ���Ҷ
	for (int m = 0; m < mlen; m++) {
		for (int j = 0; j < nlen; j++)
		{
			w = 0;
			for (int i = 0; i < mi; i++)
			{
				if (j&(1 << i))//�жϵ�iλ�Ƿ�Ϊ1 &�������Ϊ��ĵĲ������ 1&1 = 0 1%0 = 0
				{
					w += 1 << (mi - i - 1); //����ȥ
				}
			}
			B_In[j*mlen + m] = A_In[w*mlen + m];
		}
	}
	for (int m = 0; m < mlen; m++) {
		for (int i = 0; i < mi; i++)//��һ��ѭ��k=log2N��������N = 8������k = 2
		{
			int step = 1 << (i + 1);
			int factor_step = nlen >> (i + 1);//��ת�����仯�ٶ�
			//��ʼ����ת����
			W[0].real = 1.0;
			W[0].image = 0.0;
			for (int j = 0; j < step / 2; j++)
			{
				for (w = j; w < nlen; w += step)
				{
					w2 = w + step / 2;//�����������������
					T[0].real = B_In[w2*mlen + m].real * W[0].real - B_In[w2*mlen + m].image * W[0].image;
					T[0].image = B_In[w2*mlen + m].real * W[0].image + B_In[w2*mlen + m].image *  W[0].real;
					B_In[w2*mlen + m].real = B_In[w*mlen + m].real - T[0].real;
					B_In[w2*mlen + m].image = B_In[w*mlen + m].image - T[0].image;
					B_In[w*mlen + m].real = B_In[w*mlen + m].real + T[0].real;
					B_In[w*mlen + m].image = B_In[w*mlen + m].image + T[0].image;
				}
				W[0].real = cos(-2 * PI*(j + 1)*factor_step / nlen);
				W[0].image = sin(-2 * PI*(j + 1)*factor_step / nlen);
			}
		}
	}
}

void IFft() {
	nlen = bmpWidth;
	mlen = bmpHeight;
	for (int i = 0; i < mlen*nlen; i++)
	{
		A_In[i].real = B_In[i].real;
		A_In[i].image = -B_In[i].image;
	}
	Fft();

	//Idft���
}

int main()
{
	cout << "������Ҫ���ļ���·����(�磺D:\\\\1.bmp��" << endl;
	cin >> fileName;
	readBmp(fileName);
	int i, j;
	readData(); //��ȡԭ���ľ��� �����鲿
	cout << "����DFT" << endl;
	Fft(); //dft����
	unsigned char  *wBmpBuf;
	wBmpBuf = new unsigned char[mlen * nlen];
	getF(wBmpBuf);   //Ϊ����ʾ�õ���ֵ�����г�������
	saveBmp(wBmpBuf);
	delete[]wBmpBuf;
	cout << "IFFT Y or N" << endl;
	char c;
	cin >> c;
	if (c == 'Y') {
		IFft();
		unsigned char  *bwBmpBuf;
		bwBmpBuf = new unsigned char[mlen * nlen];
		for (int i = 0; i < mlen; i++)
			for (int j = 0; j < nlen; j++)
			{
				float t = B_In[i*nlen + j].real / (nlen*mlen);
				bwBmpBuf[i*nlen + j] = t;
			}
		saveBmp(bwBmpBuf);
		delete[]bwBmpBuf;
	}
	else {
		cout << "������ˮ" << endl;
	}
	delete[]pBmpBuf;
	delete[]pColorTable;
	system("pause");
	return 0;
}